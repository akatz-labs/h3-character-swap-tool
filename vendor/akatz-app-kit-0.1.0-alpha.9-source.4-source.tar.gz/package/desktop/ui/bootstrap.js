const invoke=window.__TAURI__.core.invoke;
const status=document.querySelector('#status'),data=document.querySelector('#data');let plan;
async function action(work){document.querySelectorAll('button').forEach(b=>b.disabled=true);status.textContent='Working…';try{await work();status.textContent='';}catch(error){status.textContent=String(error);}finally{document.querySelectorAll('button').forEach(b=>b.disabled=false);}}
document.querySelector('#choose').onclick=()=>action(async()=>{const path=await invoke('choose_data_folder');if(path){data.value=path;document.querySelector('#plan').hidden=true;plan=null;}});
document.querySelector('#review').onclick=()=>action(async()=>{plan=await invoke('desktop_request',{request:{action:'plan',dataRoot:data.value}});document.querySelector('#description').textContent=plan.description;document.querySelector('#location').textContent='Data folder: '+plan.launchSettings.dataRoot;document.querySelector('#plan').hidden=false;});
document.querySelector('#confirm').onclick=()=>action(async()=>{if(!plan)throw Error('Review setup first');await invoke('desktop_request',{request:{action:'confirm',plan,digest:plan.digest}});});
action(async()=>{const current=await invoke('desktop_request',{request:{action:'inspect'}});document.querySelector('#title').textContent=current.title;data.value=current.saved?.launchSettings?.dataRoot||current.defaultDataRoot;
if(current.saved?.available){try{await invoke('desktop_request',{request:{action:'open'}});}catch(error){status.textContent=String(error);}}});
