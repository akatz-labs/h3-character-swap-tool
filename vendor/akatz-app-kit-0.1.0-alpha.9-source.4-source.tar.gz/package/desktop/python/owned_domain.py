"""Linux domain host: one data lease, a verified parent and bounded readiness.

The supervisor owns this CPU service. Worker-owned accepted jobs are independent.
This helper is deliberately platform-qualified rather than guessing PID semantics.
"""
import argparse
import asyncio
import fcntl
import importlib
import json
import os
from pathlib import Path
import signal
import socket
import sys
import threading


def identity(pid):
    try:
        fields = (Path('/proc') / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()
        if fields[0] == 'Z':
            return None
        return {'platform': 'linux', 'pid': pid, 'start': fields[19],
                'boot': Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
    except (FileNotFoundError, ProcessLookupError):
        return None


def refuse_legacy_owner(root, module, state_env, legacy_default):
    """Recognize pre-lease domain launches without touching their process or DB."""
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit() or int(entry.name) == os.getpid():
            continue
        try:
            args = (entry / 'cmdline').read_bytes().split(b'\0')
            if not any(module.encode() in arg for arg in args):
                continue
            # Lease-aware hosts are fenced by acquire_data's filesystem lock.
            # Their visible paths can coincide across container mount namespaces.
            if any(Path(os.fsdecode(arg)).name == 'owned_domain.py' for arg in args if arg):
                continue
            environ = dict(item.split(b'=', 1) for item in (entry / 'environ').read_bytes().split(b'\0') if b'=' in item)
            configured = environ.get(state_env.encode())
            if configured:
                path = Path(os.fsdecode(configured))
                other_root = entry / 'root' / str(path).lstrip('/') if path.is_absolute() else entry / 'cwd' / path
            else:
                other_root = entry / 'cwd' / legacy_default
            if root.samefile(other_root) and identity(int(entry.name)):
                raise RuntimeError('A running legacy domain owns this data folder; close that app before adoption')
        except (FileNotFoundError, ProcessLookupError):
            continue


def acquire_data(root, app_id):
    """Keep the open handle for the entire domain lifetime; never steal a lease."""
    if sys.platform != 'linux':
        raise RuntimeError('This packaged domain host is qualified on Linux only')
    root = root.resolve()
    root.mkdir(parents=True, exist_ok=True)
    lease = (root / '.akatz-domain.lock').open('a+')
    try:
        fcntl.flock(lease.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        lease.close()
        raise RuntimeError('Another application process owns this data folder') from None
    metadata = root / '.akatz-data.json'
    if metadata.exists():
        saved = json.loads(metadata.read_text())
        if saved != {'schemaVersion': 1, 'appId': app_id}:
            lease.close()
            raise RuntimeError('The data folder belongs to a different app or schema')
    else:
        # Exclusive creation also refuses racing adoption from a different app.
        try:
            with metadata.open('x') as out:
                json.dump({'schemaVersion': 1, 'appId': app_id}, out)
        except FileExistsError:
            if json.loads(metadata.read_text()) != {'schemaVersion': 1, 'appId': app_id}:
                lease.close()
                raise RuntimeError('The data folder changed during adoption') from None
    lease.seek(0)
    lease.truncate()
    json.dump({'appId': app_id, 'process': identity(os.getpid())}, lease)
    lease.flush()
    return lease


def watch_parent(parent):
    if parent != identity(os.getppid()):
        raise RuntimeError('The declared supervisor is not this domain process parent')
    def watch():
        while identity(parent['pid']) == parent:
            threading.Event().wait(.25)
        os.kill(os.getpid(), signal.SIGTERM)
    threading.Thread(target=watch, daemon=True, name='supervisor-watch').start()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--module', required=True)
    parser.add_argument('--app-id', required=True)
    parser.add_argument('--data-root', required=True, type=Path)
    parser.add_argument('--state-env', required=True)
    parser.add_argument('--legacy-default', default='.data')
    args = parser.parse_args()
    parent = json.loads(os.environ['AKATZ_APP_PARENT'])
    watch_parent(parent)
    refuse_legacy_owner(args.data_root, args.module.split(':', 1)[0], args.state_env, args.legacy_default)
    lease = acquire_data(args.data_root, args.app_id)
    try:
        module, attribute = args.module.split(':', 1)
        application = getattr(importlib.import_module(module), attribute)
        import uvicorn
        server = uvicorn.Server(uvicorn.Config(application, host='127.0.0.1', port=0, log_level='warning'))
        sock = socket.socket()
        sock.bind(('127.0.0.1', 0))
        async def run():
            async def ready():
                while not server.started:
                    await asyncio.sleep(.02)
                    if server.should_exit:
                        return
                print('AKATZ_APP_READY ' + json.dumps({'url': 'http://127.0.0.1:' + str(sock.getsockname()[1]) + '/'}), flush=True)
            announce = asyncio.create_task(ready())
            try:
                await server.serve(sockets=[sock])
            finally:
                announce.cancel()
        asyncio.run(run())
    finally:
        lease.close()


if __name__ == '__main__':
    main()
