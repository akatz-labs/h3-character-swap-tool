/** Browser transport for the shared setup host; domain APIs remain app-owned. */
import {z} from 'zod';
import {JsonClient,RequestFailure} from './http.js';
import {registrySchema,snapshotSchema,progressSchema,resourceResultSchema,type ResourceAdapter} from './contracts.js';
import {attemptSchema} from './setup.js';

export function createSetupResourceAdapter(http=new JsonClient()):ResourceAdapter {
  return {
    registry:signal=>http.request('/kit-api/registry',registrySchema,{signal}),
    snapshot:(id,signal)=>http.request('/kit-api/resources/'+encodeURIComponent(id),snapshotSchema,{signal},120000),
    jobs:(id,signal)=>http.request('/kit-api/progress/'+encodeURIComponent(id),progressSchema,{signal}),
    action:(executorId,action,attemptId)=>{
      const {kind,...fields}=action;
      const body=action.kind==='uninstall-confirm'
        ?{executorId,kind:'uninstall',attemptId,planId:action.review.plan.id,digest:action.review.plan.digest,confirm:action.review.removal?.resourceId}
        :action.kind==='setup-confirm'
        ?{executorId,kind,attemptId,planId:action.review.plan.id,digest:action.review.plan.digest,resourceIds:action.review.resourceIds}
        :{executorId,kind,attemptId,...fields};
      return http.request('/kit-api/resource',resourceResultSchema,{method:'POST',body:JSON.stringify(body),headers:{'x-akatz-kit':'1'}},180000);
    },
    unresolved:async(workerId,signal)=>{
      const attempts=await http.request('/kit-api/attempts',z.array(attemptSchema),{signal});
      return attempts.find(a=>a.workerId===workerId)?.id??null;
    },
    reconcile:async(id,workerId)=>{
      const receipt=await http.request('/kit-api/attempts/'+encodeURIComponent(id),attemptSchema);
      if(receipt.workerId!==workerId)throw new Error('Receipt belongs to another worker');
      if(receipt.status==='rejected')throw new RequestFailure(receipt.error??'Original request rejected',false);
      return receipt.status==='completed'?resourceResultSchema.parse(receipt.result):null;
    },
  };
}
