import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,writeFile,readFile,rm} from 'node:fs/promises';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {createHash} from 'node:crypto';
import {createExecutorServer} from '../src/executor-server.mjs';
const h='a'.repeat(64),hash=v=>createHash('sha256').update(v).digest('hex');
async function until(fn){const end=Date.now()+5000;while(Date.now()<end){const value=fn();if(value)return value;await new Promise(done=>setTimeout(done,20));}throw Error('Fixture deadline');}
test('verified absent preparation cancels without claiming non-submission or retrying generation',async t=>{
  const root=await mkdtemp(join(tmpdir(),'preparation-cancel-'));let busy=false,inspections=0;
  const adapter=join(root,'adapter.mjs'),marker=join(root,'must-not-run');
  const code=`import{writeFile}from'node:fs/promises';export async function prepareRuntime(){throw Error('Injected preparation failure before runner creation');}
    export async function inspectRuntime({session}){return {version:1,id:session.id,owner:session.owner,installationId:session.installationId,recipeRevision:'${h}',generation:1,phase:'needs_inspection',processIdentity:null,compatibility:null,activeAttempt:null,idleSeconds:0,unloadSeconds:300,stopSeconds:900,modelEntries:0,cacheHits:0,observedAt:new Date().toISOString()};}
    export async function releaseRuntime(){throw Error('Normal release has no owner receipt');}export async function run(){await writeFile(${JSON.stringify(marker)},'unexpected');}`;
  await writeFile(adapter,code);const revision=hash(code);
  const service=createExecutorServer({root:join(root,'worker'),preparationInspector:async(session,owner)=>{
    inspections++;if(busy)throw Error('GPU remains active');return {version:1,owner,sessionId:session.id,descriptorRevision:session.descriptor.driverRevision,specSha256:h,
      controllerProcessesAbsent:true,runtimePortClosed:true,gpuComputeEmpty:true,runtimeInboxEmpty:true,submission:'unknown',observedAt:new Date().toISOString()};
  }});
  t.after(async()=>{await service.close();await rm(root,{recursive:true,force:true});});await service.resources.ready;
  const e=service.executor,descriptor={version:1,driver:adapter,driverRevision:revision,recipeRevision:h,environmentId:'fixture',idlePolicy:{unloadSeconds:300,stopSeconds:900},configuration:{}};
  const installation={id:'fixture',appId:'fixture',adapter,revision,features:['generate'],capabilities:['accepted-attempt-v1'],probes:[{kind:'file',path:adapter}],runtime:{comfyUrls:[],managed:descriptor}};
  const plan=e.plan(installation);await e.install(plan.id,plan.digest);
  const job=await e.submit({appId:'fixture',instanceId:'one',sourceJobId:'one',installationId:'fixture',feature:'generate',files:[],inputs:{runtimeCompatibility:{recipeRevision:h,adapterRevision:revision,modelDigest:h,modelConfigurationDigest:h,precision:'fixture',residency:'full',allocator:'default'}}});
  await until(()=>e.getJob(job.id)?.phase==='uncertain');clearInterval(e.timer);await until(()=>!e.ticking);
  await e.tick();
  assert.match(e.getJob(job.id).error,/Injected preparation failure/);
  // An asynchronous controller stop must not prevent reviewed cancellation.
  const session=e.sessions.records()[0];
  session.status={...session.status,phase:'stopped',activeAttempt:null,releaseProof:{stopped:true,gpuReleased:true}};
  delete session.error;
  e.sessions.store.save(session);
  const reviewed=await e.planPreparationCancellation(job.id,e.identity);assert.equal(reviewed.submission,'unknown');assert.equal(reviewed.action,'cancel-absent-preparation');
  busy=true;await assert.rejects(e.cancelPreparation(job.id,{executorId:e.identity,planId:reviewed.id,planDigest:reviewed.digest}),/GPU remains active/);assert.equal(e.getJob(job.id).phase,'uncertain');
  busy=false;
  await assert.rejects(e.cancelPreparation(job.id,{executorId:e.identity,planId:'changed-review',planDigest:reviewed.digest}),/review changed or expired/);
  const runnable=join(e.root,'jobs',job.id,'request.json');await writeFile(runnable,'{}');
  await assert.rejects(e.cancelPreparation(job.id,{executorId:e.identity,planId:reviewed.id,planDigest:reviewed.digest}),/runnable or observed attempt exists/);
  assert.equal(e.getJob(job.id).phase,'uncertain');await rm(runnable);
  const result=await e.cancelPreparation(job.id,{executorId:e.identity,planId:reviewed.id,planDigest:reviewed.digest});
  assert.equal(result.phase,'cancelled');assert.equal(result.preparationCancellation.submission,'unknown');assert.equal(result.preparationCancellation.generationRetried,false);assert(inspections>=3);
  assert.equal(e.sessions.records().find(s=>s.installationId==='fixture').status.phase,'stopped');
  await assert.rejects(readFile(marker),{code:'ENOENT'});assert.equal(e.jobs().filter(j=>j.kind!=='installation').length,1);
});
