/** Node-only setup host. Wraps existing services; does not implement a worker or scheduler. */
import { mkdir, readFile, writeFile, rename, readdir } from 'node:fs/promises';
import { join } from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { z } from 'zod';
import {
  connectionInputSchema,
  connectionPlanSchema,
  setupPreferencesSchema,
  type SetupPreferences,
} from './setup.js';
import {
  resourceResultSchema,
  reviewSchema,
  snapshotSchema,
  progressSchema,
  registrySchema,
} from './contracts.js';
export * from './managed-runtime.js';
export * from './app-host.js';
export { libraryMiddleware } from './library-server.js';

const idSchema = z.string().uuid();
export class RejectedSetupAction extends Error {}
const recordSchema = z.object({
  id: idSchema,
  workerId: z.string(),
  fingerprint: z.string(),
  status: z.enum(['running', 'completed', 'rejected', 'uncertain']),
  result: z.unknown().optional(),
  error: z.string().optional(),
});
const empty: SetupPreferences = {
  workerId: null,
  completed: false,
  modelPath: null,
  storageJobId: null,
};

export class SetupStore {
  constructor(readonly directory: string) {}
  async read(name: string): Promise<unknown> {
    try {
      return JSON.parse(await readFile(join(this.directory, name + '.json'), 'utf8'));
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return null;
      throw error;
    }
  }
  async write(name: string, value: unknown) {
    await mkdir(this.directory, { recursive: true, mode: 0o700 });
    const target = join(this.directory, name + '.json'),
      temp = target + '.' + randomUUID();
    await writeFile(temp, JSON.stringify(value), { mode: 0o600, flag: 'wx' });
    await rename(temp, target);
  }
  async preferences() {
    const value = await this.read('setup');
    return value === null ? { ...empty } : setupPreferencesSchema.parse(value);
  }
}

/** A saved receipt permits read-only recovery. Unknown dispatch is NEVER replayed. */
export class AttemptJournal {
  private active = new Set<string>();
  private locked = false;
  constructor(private readonly store: SetupStore) {}
  async inspect(id: string) {
    idSchema.parse(id);
    const value = recordSchema.parse(await this.store.read('attempt-' + id));
    return value.status === 'running' && !this.active.has(id)
      ? { ...value, status: 'uncertain' as const }
      : value;
  }
  async unresolved() {
    let names: string[];
    try {
      names = await readdir(this.store.directory);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return [];
      throw error;
    }
    const records = await Promise.all(
      names
        .filter((name) => /^attempt-[\da-f-]+\.json$/.test(name))
        .map((name) => this.inspect(name.slice(8, -5))),
    );
    return records.filter((value) => value.status === 'running' || value.status === 'uncertain');
  }
  async run(id: string, workerId: string, input: unknown, dispatch: () => Promise<unknown>) {
    idSchema.parse(id);
    const fingerprint = createHash('sha256')
      .update(JSON.stringify({ workerId, input }))
      .digest('hex');
    // Serial admission protects duplicate requests in this app host. One host owns this directory.
    if (this.locked)
      throw new RejectedSetupAction('Another setup action is pending. No new action was sent.');
    this.locked = true;
    try {
      const prior = await this.store.read('attempt-' + id);
      if (prior !== null) {
        const record = recordSchema.parse(prior);
        if (record.fingerprint !== fingerprint)
          throw new Error('Attempt identity conflicts with the original request.');
        if (record.status === 'completed') return record.result;
        if (record.status === 'rejected')
          throw new RejectedSetupAction(record.error ?? 'Original action was rejected');
        throw new Error('Attempt has an unresolved outcome. No action was repeated.');
      }
      if ((await this.unresolved()).some((record) => record.workerId === workerId))
        throw new Error('This worker has an unresolved setup attempt. No action was sent.');
      const record = { id, workerId, fingerprint, status: 'running' as const };
      await this.store.write('attempt-' + id, record);
      this.active.add(id);
      try {
        const result = await dispatch();
        await this.store.write('attempt-' + id, { ...record, status: 'completed', result });
        return result;
      } catch (error) {
        await this.store.write('attempt-' + id, {
          ...record,
          status: error instanceof RejectedSetupAction ? 'rejected' : 'uncertain',
          error: error instanceof Error ? error.message : 'Action outcome unknown',
        });
        throw error;
      } finally {
        this.active.delete(id);
      }
    } finally {
      this.locked = false;
    }
  }
}

export interface SetupBackend {
  bootstrap?(): Promise<void>;
  registry(): Promise<unknown>;
  snapshot(workerId: string): Promise<unknown>;
  jobs(workerId: string): Promise<unknown>;
  resource(workerId: string, kind: string, fields: Record<string, unknown>): Promise<unknown>;
  connectionPlan(input: z.infer<typeof connectionInputSchema>): Promise<unknown>;
  connect(id: string, digest: string, workerId: string): Promise<void>;
}
const resourceInput = z
  .object({
    attemptId: idSchema,
    executorId: z.string().min(1),
    kind: z.enum([
      'storage',
      'scan',
      'setup-required',
      'setup-runtime',
      'runtime-start',
      'runtime-repair',
      'download',
      'setup-confirm',
      'settings',
      'uninstall-plan',
      'uninstall',
    ]),
    resourceId: z.string().min(1).optional(),
    confirm: z.string().min(1).optional(),
    path: z.string().trim().min(1).optional(),
    resourceIds: z.array(z.string()).max(256).optional(),
    planId: z.string().optional(),
    digest: z.string().optional(),
    settings: z.record(z.string(), z.string()).optional(),
  })
  .strict();

export function createSetupService(backend: SetupBackend, store: SetupStore) {
  const journal = new AttemptJournal(store);
  let saving = false;
  return async (method: string, path: string, body: unknown = {}) => {
    if (method === 'GET' && path === '/registry') {
      const registry = registrySchema.parse(await backend.registry());
      const preferences = await store.preferences();
      return {
        ...registry,
        selectedExecutorId: preferences.workerId ?? registry.selectedExecutorId,
      };
    }
    if (method === 'GET' && path.startsWith('/resources/'))
      return snapshotSchema.parse(await backend.snapshot(decodeURIComponent(path.slice(11))));
    if (method === 'GET' && path.startsWith('/progress/'))
      return progressSchema.parse(await backend.jobs(decodeURIComponent(path.slice(10))));
    if (method === 'GET' && path.startsWith('/attempts/')) return journal.inspect(path.slice(10));
    if (method === 'GET' && path === '/attempts') return journal.unresolved();
    if (method === 'GET' && path === '/setup') return store.preferences();
    if (method === 'POST' && path === '/bootstrap') {
      const input = z.object({ attemptId: idSchema }).strict().parse(body);
      if (!backend.bootstrap) throw new Error('Local worker bootstrap is unavailable.');
      return journal.run(input.attemptId, 'local', { kind: 'bootstrap' }, async () => {
        await backend.bootstrap!();
        return { complete: true, workerId: 'local' };
      });
    }
    if (method === 'POST' && path === '/setup') {
      const input = z
        .object({
          workerId: z.string().optional(),
          modelPath: z.string().optional(),
          complete: z.boolean().optional(),
        })
        .strict()
        .parse(body);
      if (saving) throw new Error('Setup preferences are being saved. Refresh to inspect.');
      saving = true;
      try {
        const previous = await store.preferences();
        const workerId = input.workerId ?? previous.workerId;
        const registry = registrySchema.parse(await backend.registry());
        if (!workerId || !registry.executors.some((worker) => worker.id === workerId))
          throw new Error('Choose a registered worker.');
        const changed = workerId !== previous.workerId;
        const next = {
          ...previous,
          workerId,
          ...(changed ? { completed: false, modelPath: null, storageJobId: null } : {}),
          ...(input.modelPath !== undefined
            ? { modelPath: input.modelPath, completed: false }
            : {}),
        };
        if (input.complete) {
          const snapshot = snapshotSchema.parse(await backend.snapshot(workerId));
          const progress = progressSchema.parse(await backend.jobs(workerId));
          if (snapshot.executorId !== workerId || progress.executorId !== workerId)
            throw new Error('Worker identity changed.');
          if ((await journal.unresolved()).some((item) => item.workerId === workerId))
            throw new Error('Reconcile the previous setup action first.');
          if (
            snapshot.inventory.refreshing ||
            progress.jobs.some((job) => ['queued', 'running'].includes(job.status))
          )
            throw new Error('Wait for worker setup and indexing to finish.');
          if (
            next.storageJobId &&
            !progress.jobs.some((job) => job.id === next.storageJobId && job.status === 'succeeded')
          )
            throw new Error('The storage job has not succeeded. Inspect its original receipt.');
          if (next.modelPath && next.modelPath.trim() !== snapshot.inventory.storage.path)
            throw new Error('Apply the model storage location before continuing.');
          next.modelPath = snapshot.inventory.storage.path;
          next.completed = true;
          next.storageJobId = null;
        }
        await store.write('setup', next);
        return next;
      } finally {
        saving = false;
      }
    }
    if (method === 'POST' && path === '/connection/plan')
      return connectionPlanSchema.parse(
        await backend.connectionPlan(connectionInputSchema.parse(body)),
      );
    if (method === 'POST' && path === '/connection/confirm') {
      const input = z
        .object({ attemptId: idSchema, id: z.string(), digest: z.string(), workerId: z.string() })
        .strict()
        .parse(body);
      return journal.run(input.attemptId, input.workerId, input, async () => {
        await backend.connect(input.id, input.digest, input.workerId);
        // Receipt is committed before the client attempts to refresh discovery.
        return { complete: true, workerId: input.workerId };
      });
    }
    if (method === 'POST' && path === '/resource') {
      const { attemptId, executorId, kind, ...fields } = resourceInput.parse(body);
      return journal.run(attemptId, executorId, { kind, ...fields }, async () => {
        const raw = await backend.resource(executorId, kind, fields);
        const removal = kind === 'uninstall-plan'
          ? reviewSchema.shape.removal.unwrap().extend({id:z.string(),digest:z.string()}).parse(raw)
          : null;
        const result = resourceResultSchema.parse(removal ? {
          reviewRequired:true,executorId,executorName:executorId,resourceIds:[removal.resourceId],removal,
          plan:{id:removal.id,digest:removal.digest,writes:['Delete '+removal.path],downloads:[]},
        } : raw);
        if ('reviewRequired' in result && result.executorId !== executorId)
          throw new Error('Review identity mismatch.');
        if (kind === 'storage' && 'id' in result) {
          const prefs = await store.preferences();
          if (prefs.workerId === executorId)
            await store.write('setup', {
              ...prefs,
              modelPath: fields.path,
              storageJobId: result.id,
              completed: false,
            });
        }
        return result;
      });
    }
    throw new Error('Unknown setup route');
  };
}

/** Same-origin JSON through loopback or an explicitly named loopback reverse proxy.
 * Never expose executor credentials/SSH to an arbitrary browser host.
 */
export function setupMiddleware(
  service: ReturnType<typeof createSetupService>,
  options: { trustedHosts?: readonly string[]; trustedOrigins?: readonly string[] } = {},
) {
  return async (request: IncomingMessage, response: ServerResponse, next: () => void) => {
    if (!request.url?.startsWith('/kit-api/')) {
      next();
      return;
    }
    response.setHeader('content-type', 'application/json');
    response.setHeader('cache-control', 'no-store');
    try {
      const host = request.headers.host;
      if (!['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(request.socket.remoteAddress ?? ''))
        throw new Error('Setup API requires a loopback connection.');
      if (
        !host ||
        (!/^(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/.test(host) &&
          !options.trustedHosts?.includes(host) && !options.trustedOrigins?.some(o => new URL(o).host === host))
      )
        throw new Error('Setup API requires a loopback host.');
      const origin = request.headers.origin;
      if (origin && origin !== 'http://' + host && !options.trustedOrigins?.some(o => o === origin && new URL(o).host === host))
        throw new Error('Setup API requires same-origin requests.');
      if (
        request.method === 'POST' &&
        (request.headers['x-akatz-kit'] !== '1' ||
          !request.headers['content-type']?.startsWith('application/json'))
      )
        throw new Error('Expected a same-origin setup request.');
      let text = '';
      for await (const chunk of request) {
        text += String(chunk);
        if (Buffer.byteLength(text) > 32768) throw new Error('Setup request is too large.');
      }
      const result = await service(
        request.method ?? 'GET',
        request.url.slice(8),
        text ? JSON.parse(text) : {},
      );
      response.end(JSON.stringify(result));
    } catch (error) {
      // Schema failure may occur AFTER dispatch while parsing a receipt; never
      // turn it into a definitive rejection that clears the browser fence.
      response.statusCode = error instanceof RejectedSetupAction ? 400 : 503;
      response.end(
        JSON.stringify({ message: error instanceof Error ? error.message : 'Setup unavailable' }),
      );
    }
  };
}
