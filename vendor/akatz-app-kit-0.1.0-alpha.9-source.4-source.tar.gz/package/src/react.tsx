import { useEffect, useState, useSyncExternalStore, type ReactNode } from 'react';
import type { AppDefinition, AppLocation, ProjectSummary } from './navigation.js';
import { pagesFor } from './navigation.js';
import { ResourceController, activeJob, type ResourceState } from './resources.js';
import { Dialog, Icon, SelectMenu } from './ui.js';
export { WorkerSetup } from './setup-react.js';
export { Dialog, Icon, SelectMenu } from './ui.js';
export {
  SegmentedControl,
  VirtualGrid,
  ThumbnailCard,
  AssetList,
  MediaDetailDialog,
  MediaDropZone,
  SavedMediaTray,
  ReorderableItem,
} from './gallery-react.js';
export type { AssetListItem, CardAction, SavedMediaItem } from './gallery-react.js';
export { ProjectsPage } from './projects-react.js';
export { SharedLibraryBrowser, SharedLibraryPicker } from './library-react.js';
export type { LibrarySelection } from './library-react.js';

export function useResources(controller: ResourceController) {
  const state = useSyncExternalStore(
    controller.subscribe,
    controller.getSnapshot,
    controller.getSnapshot,
  );
  useEffect(() => {
    void controller.refresh();
    const refreshVisible = () => {
      if (!document.hidden) void controller.refresh();
    };
    window.addEventListener('focus', refreshVisible);
    document.addEventListener('visibilitychange', refreshVisible);
    const timer = setInterval(() => {
      if (!document.hidden) void controller.refresh();
    }, 4000);
    return () => {
      clearInterval(timer);
      window.removeEventListener('focus', refreshVisible);
      document.removeEventListener('visibilitychange', refreshVisible);
      controller.stop();
    };
  }, [controller]);
  return state;
}
export function bytes(value: number | null | undefined) {
  return value == null ? 'Unknown' : `${(value / 1024 ** 3).toFixed(1)} GiB`;
}
export function Notice({ children }: { children: ReactNode }) {
  return (
    <div className="ak-notice" role="status">
      {children}
    </div>
  );
}
export function WorkerStatusIcon({ status }: { status: string }) {
  const className =
    status === 'Connected' ? 'ak-good' : status === 'Offline' ? 'ak-muted' : 'ak-warning';
  return (
    <svg
      className={`ak-worker-icon ${className}`}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      role="img"
      aria-label={`Worker status: ${status}`}
    >
      <title>{status}</title>
      <rect x="3" y="3" width="18" height="7" rx="2" />
      <rect x="3" y="14" width="18" height="7" rx="2" />
      <path d="M7 6.5h.01M7 17.5h.01" strokeLinecap="round" />
      {status === 'Offline' && <path d="m2 2 20 20" />}
    </svg>
  );
}
export function FileUpload({
  label,
  accept,
  disabled = false,
  onUpload,
}: {
  label: string;
  accept: string;
  disabled?: boolean;
  onUpload: (file: File) => Promise<void>;
}) {
  const [pending, setPending] = useState(false),
    [error, setError] = useState('');
  return (
    <div className="ak-upload">
      <label>
        {label}
        <input
          type="file"
          accept={accept}
          disabled={disabled || pending}
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (!file || pending) return;
            const input = event.target;
            setPending(true);
            setError('');
            void onUpload(file)
              .then(() => {
                input.value = '';
              })
              .catch((error) => setError(error instanceof Error ? error.message : 'Upload failed'))
              .finally(() => setPending(false));
          }}
        />
      </label>
      {pending && (
        <div role="status">
          <p>Uploading and processing…</p>
          <progress aria-label="Upload and processing" />
        </div>
      )}
      {error && (
        <p className="ak-notice" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
export function AppShell({
  definition,
  location,
  projects,
  onNavigate,
  resources,
  controller,
  brandMark,
  children,
}: {
  definition: AppDefinition;
  location: AppLocation;
  projects: readonly ProjectSummary[];
  onNavigate: (location: AppLocation) => void;
  resources: ResourceState;
  controller: ResourceController;
  brandMark?: ReactNode;
  children: ReactNode;
}) {
  const worker = resources.registry?.executors.find((item) => item.id === resources.workerId);
  const workerStatus = !worker
    ? 'Connecting'
    : !worker.online
      ? 'Offline'
      : resources.error
        ? 'Needs attention'
        : !resources.snapshot
          ? 'Checking'
          : !worker.ready || !resources.snapshot.inventory.summary.ready
            ? 'Needs setup'
            : 'Connected';
  const selectedProjectName =
    location.scope === 'project'
      ? (projects.find((project) => project.id === location.projectId)?.name ?? 'Choose a project')
      : 'Choose a project';
  const projectNameTruncated = selectedProjectName.length > 50;
  const selectedProjectLabel = projectNameTruncated
    ? `${selectedProjectName.slice(0, 50).trimEnd()}…`
    : selectedProjectName;
  return (
    <div className="ak-shell">
      <a
        className="ak-skip"
        href="#main"
        onClick={(event) => {
          event.preventDefault();
          const focusMain = () => document.getElementById('main')?.focus({ preventScroll: false });
          focusMain();
          // A control closed immediately before skip navigation may still have
          // browser focus restoration queued for this frame. The activated
          // skip link wins that race and leaves focus at its announced target.
          requestAnimationFrame(focusMain);
        }}
      >
        Skip to content
      </a>
      <header className="ak-header">
        <button
          className="ak-brand"
          onClick={() => onNavigate({ scope: 'home', page: 'projects' })}
          aria-label={`${definition.title} home`}
        >
          <span className="ak-brand-mark" aria-hidden="true">
            {brandMark ?? '◈'}
          </span>
          <span className="ak-brand-copy">
            <strong>{definition.title}</strong>
            {definition.subtitle && <small>{definition.subtitle}</small>}
          </span>
        </button>
        <div
          className="ak-project-switch"
          data-project-scope={location.scope === 'project' ? 'true' : 'false'}
        >
          {location.scope === 'project' && (
            <>
              <button
                className="ak-link"
                onClick={() => onNavigate({ scope: 'home', page: 'projects' })}
              >
                Projects
              </button>
              <span className="ak-project-separator" aria-hidden="true">
                /
              </span>
            </>
          )}
          <SelectMenu
            className="ak-project-picker"
            label="Current project"
            value={location.scope === 'project' ? location.projectId : ''}
            placeholder="Choose a project"
            displayValue={selectedProjectLabel}
            {...(projectNameTruncated ? { title: selectedProjectName } : {})}
            options={projects.map((project) => ({ value: project.id, label: project.name }))}
            onChange={(projectId) =>
              onNavigate({
                scope: 'project',
                projectId,
                page: definition.projectPages[0]?.id ?? '',
              })
            }
          />
        </div>
        <div className="ak-worker">
          <div
            className="ak-worker-control"
            title={`${worker?.name ?? 'Worker'} · ${workerStatus}`}
          >
            <WorkerStatusIcon status={workerStatus} />
            <SelectMenu
              className="ak-worker-picker"
              label="Generation worker"
              value={resources.workerId ?? ''}
              placeholder="Select worker"
              displayValue={worker?.name ?? 'Select worker'}
              disabled={resources.pending || !resources.registry?.executors.length}
              options={(resources.registry?.executors ?? []).map((item) => ({
                value: item.id,
                label: `${item.name} · ${!item.online ? 'Offline' : !item.ready || item.setupRequired ? 'Needs setup' : 'Connected'}`,
              }))}
              onChange={(workerId) => controller.select(workerId)}
            />
          </div>
          <button
            className="ak-link"
            aria-label="Manage workers"
            title="Manage workers"
            onClick={() => onNavigate({ scope: 'home', page: 'settings' })}
          >
            <Icon name="plus" />
          </button>
        </div>
      </header>
      <aside className="ak-sidebar">
        <p className="ak-eyebrow">{location.scope === 'home' ? 'Workspace' : 'Project'}</p>
        <nav aria-label={location.scope === 'home' ? 'Home navigation' : 'Project navigation'}>
          {pagesFor(definition, location).map((page) => (
            <button
              key={page.id}
              aria-current={location.page === page.id ? 'page' : undefined}
              onClick={() =>
                onNavigate(
                  location.scope === 'project'
                    ? { ...location, page: page.id }
                    : { scope: 'home', page: page.id as 'projects' | 'resources' | 'settings' },
                )
              }
            >
              {page.step !== undefined ? (
                <span className="ak-step">{page.step}</span>
              ) : page.icon ? (
                <Icon name={page.icon} />
              ) : null}
              {page.label}
            </button>
          ))}
        </nav>
        <p className="ak-sidebar-note">
          {location.scope === 'home'
            ? 'Resources belong to the selected worker.'
            : 'Your projects stay here. Jobs run on the selected worker.'}
        </p>
      </aside>
      <main id="main" className="ak-main" tabIndex={-1}>
        <div className="ak-main-content">{children}</div>
      </main>
    </div>
  );
}

export function ResourcesPage({
  state,
  controller,
}: {
  state: ResourceState;
  controller: ResourceController;
}) {
  const inventory = state.snapshot?.inventory;
  const [path, setPath] = useState<string | null>(null),
    [query, setQuery] = useState(''),
    [filter, setFilter] = useState('all');
  const [settings, setSettings] = useState<Record<string, string> | null>(null);
  const active = state.snapshot?.jobs.filter(activeJob) ?? [];
  const blocked =
    state.pending || state.uncertain || Boolean(state.error) || !inventory || active.length > 0;
  const effectivePath = path ?? inventory?.storage.path ?? '';
  const storageJob = active.find((job) => job.kind === 'storage');
  const runtimeState = inventory?.runtimeState ?? 'unknown';
  const runtimeAction =
    runtimeState === 'stopped' ? 'start' : runtimeState === 'needs-repair' ? 'repair' : 'install';
  const runtimeLabels = {
    start: 'Start runtime',
    repair: 'Review runtime repair',
    install: 'Install runtime',
  };
  const runtimeAllowed = inventory?.runtimeActions?.includes(runtimeAction) ?? false;
  const visibleModels =
    inventory?.models.filter(
      (model) =>
        (model.name + ' ' + (model.relativePath ?? ''))
          .toLowerCase()
          .includes(query.toLowerCase()) &&
        (filter === 'all' ||
          filter === model.requirement ||
          (filter === 'attention' && model.state !== 'installed')),
    ) ?? [];
  const action = (value: Parameters<ResourceController['act']>[0]) => {
    void controller.act(value);
  };
  const setupReview = state.review && !state.review.removal && state.review.runtimeAction !== 'start' && (
    <section className="ak-panel ak-review" aria-label="Review setup">
      <h2>Review setup for {state.review.executorName}</h2>
      <p>{state.review.plan.description}</p>
      <h3>Changes on this worker</h3>
      <ul>
        {state.review.plan.writes.map((write) => (
          <li key={write}>{write}</li>
        ))}
      </ul>
      <h3>Downloads</h3>
      <ul>
        {state.review.plan.downloads.map((download, i) => (
          <li key={i}>
            {download.name} · {bytes(download.bytes)}
          </li>
        ))}
        {state.review.resourceIds.map((id) => (
          <li key={id}>{inventory?.models.find((model) => model.id === id)?.name ?? id}</li>
        ))}
      </ul>
      <div className="ak-inline">
        <button disabled={state.pending} onClick={() => controller.dismissReview()}>
          Cancel
        </button>
        <button
          className="ak-primary"
          disabled={blocked}
          onClick={() => state.review && action({ kind: 'setup-confirm', review: state.review })}
        >
          Confirm installation
        </button>
      </div>
    </section>
  );
  return (
    <section className="ak-resources">
      {state.review?.removal && <Dialog title={`Uninstall ${state.review.removal.name}?`} busy={state.pending} onClose={()=>controller.dismissReview()}>
        <p>This deletes the installed model files. You can install them again later.</p>
        <p className="ak-removal-path"><strong>Location:</strong> {state.review.removal.path}</p>
        <p><strong>Disk space recovered:</strong> {bytes(state.review.removal.reclaimBytes)}</p>
        <p><strong>Used by:</strong> {state.review.removal.usedByApps.join(', ') || 'This application'}</p>
        {state.review.removal.environments.length>0 && <p><strong>Environments:</strong> {state.review.removal.environments.join(', ')}. These will need the model reinstalled before generation.</p>}
        {state.review.removal.blockers.map(reason=><p key={reason} role="alert">{reason}</p>)}
        {state.actionError&&<p role="alert">{state.actionError}</p>}
        <div className="ak-inline"><button disabled={state.pending} onClick={()=>controller.dismissReview()}>Cancel</button><button className="ak-danger" disabled={blocked||!state.review.removal.canUninstall} onClick={()=>state.review&&action({kind:'uninstall-confirm',review:state.review})}>Uninstall model</button></div>
      </Dialog>}
      <div className="ak-heading">
        <div>
          <p className="ak-eyebrow">Worker · {state.snapshot?.executorName ?? 'Selected worker'}</p>
          <h1>Resources</h1>
        </div>
        <div className="ak-inline">
          <button disabled={state.loading} onClick={() => void controller.refresh()}>
            {state.loading ? 'Refreshing…' : 'Refresh'}
          </button>
          <button disabled={blocked} onClick={() => action({ kind: 'scan' })}>
            Scan
          </button>
          <button
            className="ak-primary"
            disabled={blocked || inventory?.summary.ready || runtimeState === 'stopped'}
            onClick={() => action({ kind: 'setup-required' })}
          >
            {inventory?.summary.ready
              ? 'Required setup complete'
              : state.pendingKind === 'setup-required'
                ? 'Preparing setup…'
                : 'Install required'}
          </button>
        </div>
      </div>
      {state.error && (
        <Notice>
          {inventory ? 'Showing the last inventory. ' : ''}
          {state.error}
        </Notice>
      )}
      {state.actionError && (
        <p className="ak-notice" role="alert">
          {state.actionError}
        </p>
      )}
      {state.uncertain && !state.actionError && (
        <Notice>
          A previous action on this worker has no reconciled receipt. Further changes are blocked.
          Check the original receipt; reloading does not clear this safety block.
        </Notice>
      )}
      {state.uncertain && (
        <button disabled={state.pending} onClick={() => void controller.reconcile()}>
          Check saved action receipt
        </button>
      )}
      {!inventory ? (
        <p role="status">
          {state.loading ? 'Reading worker resources…' : 'Resource inventory is unavailable.'}
        </p>
      ) : (
        <>
          <div className="ak-metrics">
            <div>
              <span>Required</span>
              <strong>
                {inventory.summary.requiredInstalled} / {inventory.summary.requiredTotal}
              </strong>
              <small>
                {inventory.summary.ready
                  ? 'Ready'
                  : inventory.summary.requiredInstalled === inventory.summary.requiredTotal
                    ? 'Models ready · Runtime needs attention'
                    : 'Required models missing'}
              </small>
            </div>
            <div>
              <span>Shared models</span>
              <strong>{bytes(inventory.storage.managedBytes)}</strong>
              <small>{inventory.models.length} model resources</small>
            </div>
            <div>
              <span>Free space</span>
              <strong>{bytes(inventory.storage.freeBytes)}</strong>
              <small>
                {inventory.storage.totalBytes === null
                  ? 'Worker did not report disk space'
                  : 'of ' + bytes(inventory.storage.totalBytes)}
              </small>
            </div>
          </div>
          <section className="ak-panel">
            <h2>Model storage</h2>
            <form
              className="ak-inline"
              onSubmit={(event) => {
                event.preventDefault();
                action({ kind: 'storage', path: effectivePath.trim() });
              }}
            >
              <label className="ak-grow">
                <span className="ak-sr">Shared model storage path</span>
                <input
                  disabled={blocked}
                  value={effectivePath}
                  onChange={(event) => setPath(event.target.value)}
                />
              </label>
              <button
                className="ak-primary"
                disabled={
                  blocked ||
                  !effectivePath.trim() ||
                  effectivePath.trim() === inventory.storage.path
                }
              >
                Use location
              </button>
            </form>
            <p className="ak-muted">
              Changing location reindexes the selected folder on this worker. Existing files are not
              moved.
            </p>
            {(state.pendingKind === 'storage' || storageJob) && (
              <div role="status">
                <p>{storageJob?.message ?? 'Waiting for worker receipt…'}</p>
                <progress
                  aria-label="Storage or resource action progress"
                  max={1}
                  {...(storageJob?.progress != null ? { value: storageJob.progress } : {})}
                />
              </div>
            )}
          </section>
          <section className="ak-panel" aria-label="Runtime">
            <div className="ak-heading">
              <div>
                <h2>Runtime</h2>
                <p className="ak-muted">
                  {runtimeState === 'unknown'
                    ? 'Checking runtime capabilities'
                    : runtimeState.replace('-', ' ')}{' '}
                  · {inventory.runtimes.filter((item) => item.installed).length}/
                  {inventory.runtimes.length} components ready
                </p>
              </div>
              <button
                className={runtimeState === 'ready' ? '' : 'ak-primary'}
                disabled={blocked || !runtimeAllowed}
                onClick={() =>
                  action({
                    kind:
                      runtimeAction === 'start'
                        ? 'runtime-start'
                        : runtimeAction === 'repair'
                          ? 'runtime-repair'
                          : 'setup-runtime',
                  })
                }
              >
                {runtimeState === 'ready'
                  ? 'Runtime ready'
                  : runtimeState === 'starting'
                    ? 'Starting runtime…'
                    : state.pendingKind?.startsWith('runtime') ||
                        state.pendingKind === 'setup-runtime'
                      ? 'Preparing runtime…'
                      : runtimeLabels[runtimeAction]}
              </button>
            </div>
            <div className="ak-runtime-grid">
              {inventory.runtimes.map((runtime) => (
                <div className="ak-runtime" key={runtime.id}>
                  <strong>{runtime.name}</strong>
                  <span className={runtime.installed ? 'ak-good' : 'ak-warning'}>
                    {runtime.installed
                      ? (runtime.version ?? 'Ready')
                      : runtimeState === 'stopped'
                        ? 'Stopped'
                        : runtimeState === 'starting'
                          ? 'Starting'
                          : 'Needs attention'}
                  </span>
                  <p>{runtime.detail}</p>
                </div>
              ))}
            </div>
            {inventory.issues.map((issue, i) => (
              <p className="ak-warning" key={i}>
                {issue}
              </p>
            ))}
            {runtimeState === 'stopped' && !runtimeAllowed && (
              <p className="ak-warning">
                No matching saved environment or executable configuration. Review Advanced worker
                setup; existing services are preserved.
              </p>
            )}
            {setupReview}
            {active
              .filter((job) => job.kind === 'setup' || job.kind === 'runtime')
              .map((job) => (
                <div key={job.id} role="status" aria-label="Runtime setup progress">
                  <strong>
                    {job.kind} · {job.status}
                  </strong>
                  <p>{job.message}</p>
                  <progress
                    aria-label={`${job.kind} progress`}
                    max={1}
                    {...(job.progress === null ? {} : { value: job.progress })}
                  />
                </div>
              ))}
          </section>
          <section className="ak-panel">
            <div className="ak-heading">
              <h2>Models</h2>
              <div className="ak-inline">
                <label>
                  <span className="ak-sr">Search models</span>
                  <input
                    placeholder="Search models"
                    value={query}
                    onChange={(event) => setQuery(event.target.value)}
                  />
                </label>
                <div className="ak-filters" aria-label="Filter models">
                  {['all', 'required', 'optional', 'attention'].map((value) => (
                    <button
                      key={value}
                      aria-pressed={filter === value}
                      onClick={() => setFilter(value)}
                    >
                      {value === 'attention' ? 'Needs attention' : value}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="ak-table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>Model</th>
                    <th>Size</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {visibleModels.map((model) => (
                    <tr key={model.id}>
                      <td>
                        {model.name}
                        <small>
                          {model.requirement === 'optional' ? 'Optional · ' : ''}
                          {model.locationLabel ?? model.relativePath ?? model.requirement}
                        </small>
                        {model.sourceNote&&<small>{model.sourceNote}</small>}
                      </td>
                      <td>{bytes(model.sizeBytes)}</td>
                      <td className={model.state === 'installed' ? 'ak-good' : 'ak-warning'}>
                        <span className="ak-state-badge">
                          {model.state === 'missing' ? 'Not installed' : model.state}
                        </span>
                      </td>
                      <td>
                        {model.state === 'missing' && model.acquisition === 'manual' ? (
                          <span className="ak-muted" title={model.sourceNote}>Import model, then scan</span>
                        ) : model.state === 'missing' ? (
                          <button
                            className="ak-install"
                            disabled={blocked}
                            onClick={() => action({ kind: 'download', resourceIds: [model.id] })}
                          >
                            Install
                          </button>
                        ) : model.state !== 'installed' ? (
                          <button disabled={blocked} onClick={() => action({ kind: 'scan' })}>
                            Scan
                          </button>
                        ) : (model.removable ?? inventory.capabilities?.includes('uninstall-model-v1')) ? (
                          <button className="ak-uninstall" disabled={blocked} aria-label={`Uninstall ${model.name}`} onClick={()=>action({kind:'uninstall-plan',resourceId:model.id})}><Icon name="trash"/>Uninstall</button>
                        ) : null}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {!visibleModels.length && <p className="ak-empty">No matching resources</p>}
          </section>
          {active
            .filter((job) => !['storage', 'setup', 'runtime'].includes(job.kind))
            .map((job) => (
              <div className="ak-panel" key={job.id} role="status">
                <strong>
                  {job.kind} · {job.status}
                </strong>
                <p>{job.message}</p>
                <progress
                  aria-label={`${job.kind} progress`}
                  max={1}
                  {...(job.progress === null ? {} : { value: job.progress })}
                />
              </div>
            ))}
          <details className="ak-panel">
            <summary>Advanced worker setup</summary>
            <p className="ak-muted">
              Paths and endpoints are on this worker. Saving settings does not start, install, or
              repair a runtime.
            </p>
            <form
              onSubmit={(event) => {
                event.preventDefault();
                if (settings) action({ kind: 'settings', settings });
              }}
            >
              <div className="ak-setup-columns">
                {[
                  'workspace',
                  'environment',
                  'cgExecutable',
                  'pythonExecutable',
                  'comfyUrl',
                  'serveUrl',
                ].map((key) => (
                  <label key={key}>
                    {
                      {
                        workspace: 'ComfyGit workspace',
                        environment: 'Saved environment',
                        cgExecutable: 'ComfyGit executable',
                        pythonExecutable: 'Python interpreter',
                        comfyUrl: 'ComfyUI URL',
                        serveUrl: 'Workflow service URL',
                      }[key]
                    }
                    <input
                      disabled={blocked}
                      value={(settings ?? inventory.settings ?? {})[key] ?? ''}
                      onChange={(event) =>
                        setSettings({
                          ...(settings ?? inventory.settings ?? {}),
                          [key]: event.target.value,
                        })
                      }
                    />
                  </label>
                ))}
              </div>
              <button disabled={blocked || !settings}>Save runtime settings</button>
            </form>
          </details>
          <details className="ak-panel">
            <summary>Recent resource jobs</summary>
            {state.snapshot?.jobs.map((job) => (
              <p key={job.id}>
                {job.kind} · {job.status} · {job.error ?? job.message}
              </p>
            ))}
          </details>
        </>
      )}
      {!inventory && setupReview}
    </section>
  );
}
