import {
  forwardRef,
  useEffect,
  useId,
  useRef,
  useState,
  type HTMLAttributes,
  type DragEvent,
  type ReactNode,
} from 'react';
import { VirtuosoGrid } from 'react-virtuoso';
import { Dialog, Icon, type IconName } from './ui.js';

const reorderMime = 'application/x-akatz-reorder';
/** Existing media moves never enter a file-upload target. */
function internalMediaDrag(event: DragEvent) {
  return [reorderMime, 'text/uri-list', 'text/html'].some((type) =>
    event.dataTransfer.types.includes(type),
  );
}

export function ReorderableItem({
  id,
  label,
  disabled = false,
  onMove,
  children,
}: {
  id: string;
  label: string;
  disabled?: boolean;
  onMove: (from: string, to: string) => void;
  children: ReactNode;
}) {
  const root = useRef<HTMLDivElement>(null);
  const [over, setOver] = useState(false);
  return (
    <div
      ref={root}
      className="ak-reorder-item"
      data-reorder-id={id}
      data-drag-over={over || undefined}
      draggable={!disabled}
      onDragStart={(event) => {
        if (disabled) return event.preventDefault();
        event.dataTransfer.setData(reorderMime, id);
        event.dataTransfer.effectAllowed = 'move';
      }}
      onDragOver={(event) => {
        if (!disabled && event.dataTransfer.types.includes(reorderMime)) {
          event.preventDefault();
          event.dataTransfer.dropEffect = 'move';
          setOver(true);
        }
      }}
      onDragLeave={() => setOver(false)}
      onDrop={(event) => {
        event.preventDefault();
        event.stopPropagation();
        setOver(false);
        const from = event.dataTransfer.getData(reorderMime);
        if (!disabled && from) onMove(from, id);
      }}
    >
      {children}
      <button
        type="button"
        className="ak-reorder-handle"
        aria-label={`Reorder ${label}`}
        title="Drag to reorder, or use Left and Right arrow keys"
        disabled={disabled}
        onKeyDown={(event) => {
          if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
          event.preventDefault();
          const sibling =
            event.key === 'ArrowLeft'
              ? root.current?.previousElementSibling
              : root.current?.nextElementSibling;
          const to = sibling?.getAttribute('data-reorder-id');
          if (to) onMove(id, to);
        }}
        onPointerDown={(event) => {
          if (event.pointerType === 'mouse') return;
          event.preventDefault();
          event.currentTarget.setPointerCapture(event.pointerId);
        }}
        onPointerUp={(event) => {
          if (!event.currentTarget.hasPointerCapture(event.pointerId)) return;
          event.currentTarget.releasePointerCapture(event.pointerId);
          const target = document
            .elementFromPoint(event.clientX, event.clientY)
            ?.closest('[data-reorder-id]');
          if (target?.parentElement === root.current?.parentElement) {
            const to = target?.getAttribute('data-reorder-id');
            if (to) onMove(id, to);
          }
        }}
      >
        ↔
      </button>
    </div>
  );
}

/** Controlled native radio group, styled as a compact segmented pill. */
export function SegmentedControl<T extends string>({
  label,
  value,
  options,
  onChange,
  disabled = false,
}: {
  label: string;
  value: T;
  options: readonly { value: T; label: string; disabled?: boolean }[];
  onChange: (value: T) => void;
  disabled?: boolean;
}) {
  const name = useId();
  return (
    <fieldset className="ak-segmented" disabled={disabled}>
      <legend className="ak-sr">{label}</legend>
      {options.map((option) => (
        <label className="ak-segment" key={option.value}>
          <input
            type="radio"
            name={name}
            value={option.value}
            checked={value === option.value}
            disabled={option.disabled}
            onChange={() => onChange(option.value)}
          />
          <span>{option.label}</span>
        </label>
      ))}
    </fieldset>
  );
}

async function deliverFiles(
  files: File[],
  onFiles: (files: File[]) => Promise<void>,
  setPending: (pending: boolean) => void,
  setError: (error: string) => void,
) {
  if (!files.length) return;
  setPending(true);
  setError('');
  try {
    await onFiles(files);
  } catch (error) {
    setError(error instanceof Error ? error.message : 'Upload failed.');
  } finally {
    setPending(false);
  }
}

/** Clickable and keyboard-accessible file target with an equivalent drag/drop shortcut. */
export function MediaDropZone({
  title,
  hint,
  accept,
  multiple = false,
  disabled = false,
  preview,
  onFiles,
}: {
  title: string;
  hint: string;
  accept: string;
  multiple?: boolean;
  disabled?: boolean;
  preview?: ReactNode;
  onFiles: (files: File[]) => Promise<void>;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false),
    [pending, setPending] = useState(false),
    [error, setError] = useState('');
  const blocked = disabled || pending;
  const submit = (files: File[]) => deliverFiles(files, onFiles, setPending, setError);
  const allowDrop = (event: DragEvent<HTMLDivElement>) => {
    if (internalMediaDrag(event)) {
      event.preventDefault();
      event.dataTransfer.dropEffect = 'none';
      return;
    }
    if (blocked || !event.dataTransfer.types.includes('Files')) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
    setDragActive(true);
  };
  return (
    <div
      className="ak-media-drop-zone"
      data-drag-active={dragActive || undefined}
      data-has-preview={preview ? 'true' : undefined}
      onDragEnter={allowDrop}
      onDragOver={allowDrop}
      onDragLeave={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setDragActive(false);
      }}
      onDrop={(event) => {
        event.preventDefault();
        setDragActive(false);
        if (!blocked && !internalMediaDrag(event))
          void submit(Array.from(event.dataTransfer.files));
      }}
    >
      <input
        ref={input}
        className="ak-sr"
        type="file"
        accept={accept}
        multiple={multiple}
        disabled={blocked}
        onChange={(event) => {
          const files = Array.from(event.target.files ?? []);
          event.target.value = '';
          void submit(files);
        }}
      />
      <button
        type="button"
        className="ak-media-drop-button"
        aria-label={title}
        disabled={blocked}
        onClick={() => input.current?.click()}
      >
        {preview ?? <Icon name="upload" />}
        <span className="ak-media-drop-copy">
          <strong>{title}</strong>
          <small>{pending ? 'Saving and preparing…' : hint}</small>
        </span>
      </button>
      {error && (
        <p className="ak-media-error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

export interface SavedMediaItem {
  id: string;
  kind: 'image' | 'video' | 'audio';
  thumbnailUrl?: string | null | undefined;
  durationSeconds?: number | undefined;
  label?: string | undefined;
}

/** Compact recent-upload browser; product adapters own storage, validation and selection policy. */
export function SavedMediaTray<T extends SavedMediaItem>({
  items,
  selectedIds = [],
  loading = false,
  hasMore = false,
  disabled = false,
  accept,
  multiple = true,
  description = 'Previous uploads · click to add',
  targetControl,
  onSelect,
  onFiles,
  onOpenLibrary,
  onLoadMore,
}: {
  items: readonly T[];
  selectedIds?: readonly string[];
  loading?: boolean;
  hasMore?: boolean;
  disabled?: boolean;
  accept: string;
  multiple?: boolean;
  description?: string;
  targetControl?: ReactNode;
  onSelect: (item: T) => void;
  onFiles: (files: File[]) => Promise<void>;
  onOpenLibrary?: () => void;
  onLoadMore?: () => void;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [pending, setPending] = useState(false),
    [error, setError] = useState('');
  const blocked = disabled || pending;
  return (
    <section className="ak-saved-media" aria-label="Saved uploads">
      <header>
        <strong>Saved uploads</strong>
        <div>
          {onOpenLibrary && (
            <button type="button" disabled={blocked} onClick={onOpenLibrary}>
              Add from shared library
            </button>
          )}
          <input
            ref={input}
            className="ak-sr"
            type="file"
            accept={accept}
            multiple={multiple}
            disabled={blocked}
            onChange={(event) => {
              const files = Array.from(event.target.files ?? []);
              event.target.value = '';
              void deliverFiles(files, onFiles, setPending, setError);
            }}
          />
          <button type="button" disabled={blocked} onClick={() => input.current?.click()}>
            <Icon name="upload" /> Upload
          </button>
        </div>
      </header>
      {targetControl}
      <p>{description}</p>
      {error && (
        <p className="ak-media-error" role="alert">
          {error}
        </p>
      )}
      <div
        className="ak-saved-media-scroll"
        tabIndex={0}
        aria-label="Browse previous uploads"
        onScroll={(event) => {
          const element = event.currentTarget;
          if (
            hasMore &&
            !loading &&
            element.scrollHeight - element.scrollTop - element.clientHeight < 80
          )
            onLoadMore?.();
        }}
      >
        <div className="ak-saved-media-grid">
          {items.map((item, index) => {
            const selected = selectedIds.includes(item.id);
            const label = item.label ?? `Saved ${item.kind} ${index + 1}`;
            return (
              <button
                type="button"
                key={item.id}
                className="ak-saved-media-item"
                aria-label={`Add ${label}`}
                aria-pressed={selected}
                disabled={blocked}
                onClick={() => onSelect(item)}
              >
                {item.thumbnailUrl ? (
                  <img src={item.thumbnailUrl} alt="" loading="lazy" decoding="async" />
                ) : (
                  <Icon
                    name={
                      item.kind === 'audio' ? 'music' : item.kind === 'video' ? 'film' : 'image'
                    }
                  />
                )}
                {item.kind !== 'image' && (
                  <small>
                    <Icon name={item.kind === 'video' ? 'film' : 'music'} />
                    {item.durationSeconds !== undefined
                      ? `${item.durationSeconds.toFixed(1)}s`
                      : item.kind}
                  </small>
                )}
                {selected && <span aria-hidden="true">✓</span>}
              </button>
            );
          })}
        </div>
        {loading && <p role="status">Loading uploads…</p>}
        {!loading && !items.length && <p>No uploads yet. Upload or drop media to begin.</p>}
        {hasMore && onLoadMore && (
          <button type="button" disabled={loading} onClick={onLoadMore}>
            Load more
          </button>
        )}
      </div>
    </section>
  );
}

const GridList = forwardRef<HTMLDivElement, HTMLAttributes<HTMLDivElement>>(function GridList(
  { className = '', ...props },
  ref,
) {
  return <div {...props} ref={ref} className={`ak-thumbnail-grid ${className}`} />;
});
const gridComponents = { List: GridList };

/** Scroll-parent virtualization bounds mounted cards/images, independent of the app's data model. */
export function VirtualGrid<T extends { id: string }>({
  items,
  renderItem,
  onEndReached,
}: {
  items: readonly T[];
  renderItem: (item: T, index: number) => ReactNode;
  onEndReached?: () => void;
}) {
  const host = useRef<HTMLDivElement>(null);
  const [scrollParent, setScrollParent] = useState<HTMLElement | null>(null);
  useEffect(() => {
    setScrollParent(host.current?.closest<HTMLElement>('.ak-main') ?? null);
  }, []);
  return (
    <div className="ak-virtual-grid-host" ref={host}>
      <VirtuosoGrid
        data={items}
        {...(scrollParent ? { customScrollParent: scrollParent } : { useWindowScroll: true })}
        components={gridComponents}
        computeItemKey={(_index, item) => item.id}
        increaseViewportBy={{ top: 200, bottom: 400 }}
        {...(onEndReached ? { endReached: onEndReached } : {})}
        itemContent={(index, item) => renderItem(item, index)}
      />
    </div>
  );
}

export function ThumbnailCard({
  title,
  subtitle,
  thumbnailUrl,
  status,
  statusLabel,
  kindLabel,
  durationLabel,
  onOpen,
  favorite = false,
  onToggleFavorite,
  actions = [],
  progress,
}: {
  title: string;
  subtitle?: string;
  thumbnailUrl?: string | null;
  status: 'ready' | 'failed' | 'queued' | 'running';
  statusLabel: string;
  kindLabel: string;
  durationLabel?: string;
  onOpen: () => void;
  favorite?: boolean;
  onToggleFavorite?: () => void;
  actions?: readonly CardAction[];
  progress?: ReactNode;
}) {
  const [failedImage, setFailedImage] = useState<string | null>(null);
  const [imageRetry, setImageRetry] = useState(0);
  useEffect(() => {
    setFailedImage(null);
    setImageRetry(0);
  }, [thumbnailUrl]);
  useEffect(() => {
    if (!failedImage || imageRetry >= 3) return;
    const timer = setTimeout(() => {
      setImageRetry((value) => value + 1);
      setFailedImage(null);
    }, 3000);
    return () => clearTimeout(timer);
  }, [failedImage, imageRetry]);
  const showImage = status === 'ready' && thumbnailUrl && failedImage !== thumbnailUrl;
  const pending = status === 'queued' || status === 'running';
  return (
    <article
      className="ak-thumbnail-card"
      data-status={status}
      data-single-line={!subtitle || undefined}
    >
      <button
        type="button"
        className="ak-thumbnail-stage-button"
        aria-label={`Inspect ${title}`}
        onClick={onOpen}
      >
        <div className="ak-thumbnail-stage">
          {showImage ? (
            <img
              src={
                imageRetry
                  ? thumbnailUrl + (thumbnailUrl.includes('?') ? '&' : '?') + 'retry=' + imageRetry
                  : thumbnailUrl
              }
              alt=""
              loading="lazy"
              decoding="async"
              onError={() => setFailedImage(thumbnailUrl)}
            />
          ) : (
            <div
              className="ak-thumbnail-placeholder"
              data-pending={pending || undefined}
              aria-busy={pending}
              role="status"
            >
              {pending ? (
                <span className="ak-generation-spinner" aria-hidden="true" />
              ) : (
                <Icon name={status === 'failed' ? 'alert' : 'film'} />
              )}
              {pending&&progress ? progress : <span>
                {status === 'ready' && failedImage && imageRetry >= 3
                  ? 'Preview unavailable'
                  : statusLabel}
              </span>}
              {pending && !progress && (
                <span className="ak-generation-track" aria-hidden="true">
                  <i />
                </span>
              )}
            </div>
          )}
          <span className="ak-thumbnail-badges">
            <span>{kindLabel}</span>
            {durationLabel && <span>{durationLabel}</span>}
          </span>
          {showImage && (
            <span className="ak-thumbnail-play">
              <Icon name="play" />
            </span>
          )}
        </div>
      </button>
      <div className="ak-thumbnail-body">
        <button type="button" className="ak-thumbnail-copy" onClick={onOpen}>
          <strong>{title}</strong>
          {subtitle && <span>{subtitle}</span>}
        </button>
        {(onToggleFavorite || actions.length > 0) && (
          <div className="ak-thumbnail-actions">
            {onToggleFavorite && (
              <button
                type="button"
                className="ak-card-icon-action"
                data-active={favorite || undefined}
                aria-label={favorite ? 'Remove from favorites' : 'Add to favorites'}
                aria-pressed={favorite}
                onClick={onToggleFavorite}
              >
                <Icon name="heart" />
              </button>
            )}
            {actions.length > 0 && <CardActionMenu title={title} actions={actions} />}
          </div>
        )}
      </div>
    </article>
  );
}

export interface CardAction {
  id: string;
  label: string;
  icon: IconName;
  onSelect?: () => void;
  href?: string;
  download?: boolean;
  disabled?: boolean;
  destructive?: boolean;
  separatorBefore?: boolean;
}

function CardActionMenu({ title, actions }: { title: string; actions: readonly CardAction[] }) {
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null),
    trigger = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (!open) return;
    const closeOutside = (event: PointerEvent) => {
      if (!root.current?.contains(event.target as Node)) setOpen(false);
    };
    const closeEscape = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      event.preventDefault();
      setOpen(false);
      trigger.current?.focus();
    };
    document.addEventListener('pointerdown', closeOutside);
    document.addEventListener('keydown', closeEscape);
    return () => {
      document.removeEventListener('pointerdown', closeOutside);
      document.removeEventListener('keydown', closeEscape);
    };
  }, [open]);
  return (
    <div className="ak-card-menu" ref={root}>
      <button
        ref={trigger}
        type="button"
        className="ak-card-icon-action"
        aria-label={`More actions for ${title}`}
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((value) => !value)}
      >
        <Icon name="more" />
      </button>
      {open && (
        <div className="ak-card-menu-popup" role="menu">
          {actions.map((action) => {
            const content = (
              <>
                <Icon name={action.icon} />
                <span>{action.label}</span>
              </>
            );
            return (
              <div
                key={action.id}
                className={action.separatorBefore ? 'ak-card-menu-separator' : ''}
              >
                {action.href && !action.disabled ? (
                  <a
                    role="menuitem"
                    href={action.href}
                    download={action.download || undefined}
                    onClick={() => setOpen(false)}
                  >
                    {content}
                  </a>
                ) : (
                  <button
                    type="button"
                    role="menuitem"
                    data-destructive={action.destructive || undefined}
                    disabled={action.disabled}
                    onClick={() => {
                      setOpen(false);
                      action.onSelect?.();
                    }}
                  >
                    {content}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export interface AssetListItem {
  id: string;
  label: string;
  detail: string;
  kind: 'image' | 'video' | 'audio';
  thumbnailUrl?: string | null;
}

/** Compact, media-neutral asset provenance rows for inspectors and pipeline outputs. */
export function AssetList({ items }: { items: readonly AssetListItem[] }) {
  return (
    <div className="ak-asset-list">
      {items.map((item) => (
        <div className="ak-asset-row" key={item.id}>
          <span className="ak-asset-thumb">
            {item.thumbnailUrl ? (
              <img src={item.thumbnailUrl} alt="" loading="lazy" decoding="async" />
            ) : (
              <Icon
                name={item.kind === 'audio' ? 'music' : item.kind === 'video' ? 'film' : 'image'}
              />
            )}
          </span>
          <span>
            <strong>{item.label}</strong>
            <small>{item.detail}</small>
          </span>
        </div>
      ))}
    </div>
  );
}

/** Generic preview + independently scrolling inspector; consumers own media and actions. */
export function MediaDetailDialog({
  title,
  preview,
  children,
  navigation,
  itemKey,
  busy = false,
  onClose,
}: {
  title: string;
  preview: ReactNode;
  children: ReactNode;
  navigation?: ReactNode;
  /** Reset inspector scroll when switching results without remounting the modal/focus boundary. */
  itemKey?: string;
  busy?: boolean;
  onClose: () => void;
}) {
  return (
    <Dialog title={title} variant="media" busy={busy} onClose={onClose}>
      <div className="ak-detail-preview">
        {preview}
        {navigation && (
          <nav aria-label="Preview navigation" className="ak-detail-navigation">
            {navigation}
          </nav>
        )}
      </div>
      <div
        key={itemKey}
        className="ak-detail-inspector"
        tabIndex={0}
        role="region"
        aria-label="Media details"
      >
        {children}
      </div>
    </Dialog>
  );
}
