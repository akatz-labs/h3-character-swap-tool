export type AppLocation =
  | { scope: 'home'; page: 'projects' | 'shared-library' | 'resources' | 'settings' }
  | { scope: 'project'; projectId: string; page: string };
export interface PageDefinition {
  id: string;
  label: string;
  step?: number;
  icon?: 'grid' | 'sparkles' | 'library' | 'boxes' | 'download' | 'settings';
}
export interface AppDefinition {
  id: string;
  title: string;
  subtitle?: string;
  projectPages: readonly PageDefinition[];
  sharedLibrary?: boolean;
}
export interface ProjectSummary {
  id: string;
  name: string;
  thumbnailUrl?: string | null | undefined;
  generationCount?: number | undefined;
  activeCount?: number | undefined;
  updatedAt?: string | undefined;
}
export const homePages: readonly PageDefinition[] = [
  { id: 'projects', label: 'Projects', icon: 'grid' },
  { id: 'shared-library', label: 'Shared Library', icon: 'library' },
  { id: 'resources', label: 'Resources', icon: 'download' },
  { id: 'settings', label: 'Settings', icon: 'settings' },
];
export function pagesFor(definition: AppDefinition, location: AppLocation) {
  return location.scope === 'home'
    ? homePages.filter((page) => page.id !== 'shared-library' || definition.sharedLibrary)
    : definition.projectPages;
}
export function locationHash(location: AppLocation): string {
  return location.scope === 'home'
    ? `#/${location.page}`
    : `#/project/${encodeURIComponent(location.projectId)}/${encodeURIComponent(location.page)}`;
}
export function parseLocation(hash: string, definition: AppDefinition): AppLocation {
  try {
    const parts = hash.replace(/^#\//, '').split('/').map(decodeURIComponent);
    if (
      parts[0] === 'project' &&
      parts[1] &&
      definition.projectPages.some((page) => page.id === parts[2])
    )
      return { scope: 'project', projectId: parts[1], page: parts[2]! };
    if (
      parts.length === 1 &&
      (parts[0] === 'resources' ||
        parts[0] === 'settings' ||
        (parts[0] === 'shared-library' && definition.sharedLibrary))
    )
      return { scope: 'home', page: parts[0] };
  } catch {
    /* Malformed URL returns home, never invents a project. */
  }
  return { scope: 'home', page: 'projects' };
}
