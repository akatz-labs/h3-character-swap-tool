import { z } from 'zod';
import { JsonClient } from './http.js';

export const libraryAssociationSchema = z.object({
  appId: z.string().min(1),
  instanceId: z.string().min(1),
  projectId: z.string().min(1),
});
export const libraryAppSchema = libraryAssociationSchema
  .omit({ projectId: true })
  .extend({ name: z.string() });
export const libraryProjectSchema = libraryAssociationSchema.extend({ name: z.string() });
export const libraryItemSchema = libraryAssociationSchema.extend({
  id: z.string().uuid(),
  libraryId: z.string().uuid(),
  name: z.string(),
  mime: z.string(),
  size: z.number().int().nonnegative(),
  createdAt: z.string(),
  available: z.boolean(),
  trashedAt: z.string().nullable(),
  links: z.array(libraryAssociationSchema).default([]),
});
export const libraryRegistrySchema = z.object({
  apps: z.array(libraryAppSchema),
  projects: z.array(libraryProjectSchema),
});
export const libraryPageSchema = z.object({
  items: z.array(libraryItemSchema),
  nextOffset: z.number().int().nonnegative().nullable(),
});
export const libraryQuerySchema = z.object({
  appId: z.string().min(1).max(160).optional(),
  instanceId: z.string().min(1).max(160).optional(),
  projectId: z.string().min(1).max(160).optional(),
  q: z.string().max(200).default(''),
  kind: z.enum(['all', 'image', 'video', 'audio', 'model']).default('all'),
  offset: z.coerce.number().int().min(0).max(1_000_000).default(0),
});
export type LibraryItem = z.infer<typeof libraryItemSchema>;
export type LibraryRegistry = z.infer<typeof libraryRegistrySchema>;
export type LibraryQuery = z.infer<typeof libraryQuerySchema>;
export interface LibraryAdapter {
  registry(signal: AbortSignal): Promise<LibraryRegistry>;
  page(query: LibraryQuery, signal: AbortSignal): Promise<z.infer<typeof libraryPageSchema>>;
  mediaUrl(item: LibraryItem): string;
  thumbnailUrl(item: LibraryItem): string | null;
}
export function libraryKind(item: LibraryItem) {
  return item.mime.startsWith('image/')
    ? 'image'
    : item.mime.startsWith('video/')
      ? 'video'
      : item.mime.startsWith('audio/')
        ? 'audio'
        : 'model';
}
export function matchesLibraryScope(item: LibraryItem, query: LibraryQuery) {
  return (
    [item, ...item.links].some(
      (a) =>
        (!query.appId || a.appId === query.appId) &&
        (!query.instanceId || a.instanceId === query.instanceId) &&
        (!query.projectId || a.projectId === query.projectId),
    ) &&
    (query.kind === 'all' || libraryKind(item) === query.kind)
  );
}
/** The same adapter supports a read-only page and a consumer-controlled picker. */
export function createLibraryAdapter(http = new JsonClient(), base = '/kit-media'): LibraryAdapter {
  const mediaUrl = (item: LibraryItem) => `${base}/items/${encodeURIComponent(item.id)}/file`;
  return {
    registry: (signal) => http.request(`${base}/registry`, libraryRegistrySchema, { signal }),
    page: (query, signal) =>
      http.request(
        `${base}/items?${new URLSearchParams(
          Object.entries(query)
            .filter(([, value]) => value !== undefined)
            .map(([key, value]) => [key, String(value)]),
        )}`,
        libraryPageSchema,
        { signal },
      ),
    mediaUrl,
    thumbnailUrl: (item) =>
      ['image', 'video'].includes(libraryKind(item)) && item.available
        ? `${base}/items/${encodeURIComponent(item.id)}/thumbnail`
        : null,
  };
}
