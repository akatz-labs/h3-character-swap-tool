import { useId, useRef, useState } from 'react';
import type { ProjectSummary } from './navigation.js';
import { Dialog, Icon } from './ui.js';

function ProjectNameDialog({
  project,
  onSave,
  onClose,
  disabled,
}: {
  project: ProjectSummary | 'new';
  onSave: (name: string) => Promise<void>;
  onClose: () => void;
  disabled: boolean;
}) {
  const [name, setName] = useState(project === 'new' ? '' : project.name);
  const [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const id = useId();
  const input = useRef<HTMLInputElement>(null);
  return (
    <Dialog
      title={project === 'new' ? 'New project' : 'Rename project'}
      description={
        project === 'new'
          ? 'Create a workspace to organize your work. You can choose a generation worker separately.'
          : 'Change the project name. Its contents and accepted jobs are unchanged.'
      }
      busy={busy}
      onClose={onClose}
      initialFocus={input}
    >
      <form
        onSubmit={(event) => {
          event.preventDefault();
          if (busy || disabled || !name.trim()) return;
          setBusy(true);
          setError('');
          void onSave(name.trim())
            .then(onClose)
            .catch((failure: unknown) =>
              setError(failure instanceof Error ? failure.message : 'Could not save project.'),
            )
            .finally(() => setBusy(false));
        }}
      >
        <label htmlFor={id}>Project name</label>
        <input
          ref={input}
          id={id}
          required
          maxLength={80}
          value={name}
          disabled={busy || disabled}
          placeholder="Name your project"
          onChange={(event) => setName(event.target.value)}
        />
        {error && (
          <p role="alert" className="ak-notice">
            {error}
          </p>
        )}
        <div className="ak-dialog-actions">
          <button type="button" disabled={busy} onClick={onClose}>
            Cancel
          </button>
          <button
            className="ak-primary"
            disabled={
              busy ||
              disabled ||
              !name.trim() ||
              (project !== 'new' && name.trim() === project.name)
            }
          >
            {busy ? 'Saving…' : project === 'new' ? 'Create project' : 'Save name'}
          </button>
        </div>
      </form>
    </Dialog>
  );
}

export function ProjectsPage({
  projects,
  onOpen,
  onCreate,
  onRename,
  error,
  loading,
  writesDisabled = false,
  countLabel = { singular: 'creation', plural: 'creations' },
}: {
  projects: readonly ProjectSummary[];
  onOpen: (id: string) => void;
  onCreate: (name: string) => Promise<void>;
  onRename?: (id: string, name: string) => Promise<void>;
  error: string;
  loading: boolean;
  writesDisabled?: boolean;
  countLabel?: { singular: string; plural: string };
}) {
  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState<ProjectSummary | 'new' | null>(null);
  const disabled = loading || Boolean(error) || writesDisabled;
  const timestamp = (project: ProjectSummary) => {
    const value = Date.parse(project.updatedAt ?? '');
    return Number.isFinite(value) ? value : 0;
  };
  const visible = projects
    .filter((project) => project.name.toLowerCase().includes(query.trim().toLowerCase()))
    .sort((a, b) => timestamp(b) - timestamp(a));
  return (
    <section className="ak-projects">
      <div className="ak-heading">
        <div>
          <h1>Projects</h1>
          <p className="ak-muted">Pick up where you left off, or start something new.</p>
        </div>
        <button
          className="ak-primary ak-button-icon"
          disabled={disabled}
          onClick={() => setEditing('new')}
        >
          <Icon name="plus" />
          New project
        </button>
      </div>
      <div className="ak-project-toolbar">
        <label className="ak-search">
          <Icon name="search" />
          <input
            type="search"
            aria-label="Search projects"
            placeholder="Search projects"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
          />
        </label>
        {projects.some((project) => timestamp(project) > 0) && (
          <span className="ak-muted">Recently active first</span>
        )}
      </div>
      {error && (
        <p role="alert" className="ak-notice">
          {error} Saved projects have not been removed.
        </p>
      )}
      {loading && !projects.length && <p role="status">Loading projects…</p>}
      <div className="ak-grid ak-project-grid">
        {visible.map((project) => (
          <article className="ak-project-card" key={project.id}>
            <button
              className="ak-project-open"
              onClick={() => onOpen(project.id)}
              aria-label={`Open ${project.name}`}
            >
              {project.thumbnailUrl ? (
                <img src={project.thumbnailUrl} alt="" loading="lazy" />
              ) : (
                <div className="ak-card-placeholder">
                  <Icon name="folder" />
                </div>
              )}
              <div className="ak-project-copy">
                <h2>
                  <Icon name="folder" />
                  {project.name}
                </h2>
                {project.generationCount !== undefined && (
                  <p>
                    {project.generationCount}{' '}
                    {project.generationCount === 1 ? countLabel.singular : countLabel.plural}
                    {project.activeCount ? ` · ${project.activeCount} active` : ''}
                  </p>
                )}
                {timestamp(project) > 0 && (
                  <small>
                    <time dateTime={project.updatedAt}>
                      Updated{' '}
                      {new Date(timestamp(project)).toISOString().slice(0, 16).replace('T', ' ')}{' '}
                      UTC
                    </time>
                  </small>
                )}
              </div>
            </button>
            {onRename && (
              <button
                className="ak-project-rename ak-icon-button"
                aria-label={`Rename ${project.name}`}
                title="Rename project"
                disabled={disabled}
                onClick={() => setEditing(project)}
              >
                <Icon name="pencil" />
              </button>
            )}
          </article>
        ))}
      </div>
      {!loading && !error && !visible.length && (
        <div className="ak-empty" role="status">
          <Icon name={query.trim() ? 'search' : 'folder'} />
          <h2>{query.trim() ? 'No matching projects' : 'Your workspace starts here'}</h2>
          <p>
            {query.trim()
              ? 'Try another name or clear your search.'
              : 'Create a project to organize your work.'}
          </p>
          {query.trim() && <button onClick={() => setQuery('')}>Clear search</button>}
        </div>
      )}
      {editing && (
        <ProjectNameDialog
          project={editing}
          disabled={disabled}
          onClose={() => setEditing(null)}
          onSave={(name) => (editing === 'new' ? onCreate(name) : onRename!(editing.id, name))}
        />
      )}
    </section>
  );
}
