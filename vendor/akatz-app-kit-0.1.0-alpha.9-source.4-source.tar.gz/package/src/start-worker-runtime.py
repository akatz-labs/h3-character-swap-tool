"""Adapted from Splat Smith scripts/start-worker-runtime.py (2026-09-16).
Start a saved environment without syncing or installing. Preserve foreign listeners.
"""
import json
import hashlib
import uuid
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import urllib.request
from urllib.parse import urlsplit


def endpoint(origin):
    value = urlsplit(origin)
    if value.scheme != 'http' or value.hostname not in ('127.0.0.1', 'localhost') or not value.port or value.username or value.password or value.path not in ('', '/') or value.query or value.fragment:
        raise RuntimeError('Runtime endpoint must be a worker-local HTTP port')
    return value


def health(url):
    try:
        with urllib.request.urlopen(url, timeout=2) as response:
            return json.load(response)
    except (OSError, ValueError):
        return None


def start(workspace, name, cg, comfy, serve, policy_path=None):
    from comfygit_core import Workspace
    env = Workspace.open(Path(workspace)).get_environment(name, auto_sync=False)
    base = Path(env.comfyui_path).resolve()
    if not (base / 'main.py').is_file():
        raise RuntimeError('Saved environment is incomplete. Repair its installation; nothing was replaced.')
    endpoints = [endpoint(comfy), endpoint(serve)]
    policy = None
    residency_flags = ['--highvram']
    if policy_path:
        policy = json.loads(Path(policy_path).read_text())
        if set(policy) != {'version', 'residency', 'capacityEvidence', 'capacityEvidenceSha256'} or policy['version'] != 1 or policy['residency'] != 'offload':
            raise RuntimeError('Unsupported explicit runtime policy')
        evidence = Path(policy['capacityEvidence']).read_bytes()
        if hashlib.sha256(evidence).hexdigest() != policy['capacityEvidenceSha256']:
            raise RuntimeError('Capacity evidence changed')
        measured = json.loads(evidence)
        if measured.get('fullResourcesVerified') is not True or measured.get('exceptionType') != 'torch.OutOfMemoryError' or not measured.get('jobId'):
            raise RuntimeError('Offload requires the retained measured full-resource failure')
        residency_flags = []  # ComfyUI's normal residency, with no memory cap.
    commands = [
        [cg, '-e', name, 'run', '--no-sync', '--', '--listen', '127.0.0.1', '--port', str(endpoints[0].port), '--base-directory', str(base), '--disable-auto-launch', *residency_flags, '--reserve-vram', '0'],
        [cg, '-e', name, 'serve', '--host', '127.0.0.1', '--port', str(endpoints[1].port), '--comfy-url', comfy, '--state', 'local'],
    ]
    urls = [comfy + '/system_stats', serve + '/health']
    def matches(url, value):
        if url == urls[0]:
            args = (value or {}).get('system', {}).get('argv', [])
            declared = args[args.index('--base-directory') + 1] if '--base-directory' in args else None
            return bool(declared and Path(declared).resolve() == base)
        return (value or {}).get('environment') == name and (value or {}).get('comfy_url', '').rstrip('/') == comfy.rstrip('/')
    missing = []
    for address, url in zip(endpoints, urls):
        if health(url) is not None:
            missing.append(False)
            continue
        with socket.socket() as probe:
            probe.settimeout(2)
            if probe.connect_ex((address.hostname, address.port)) == 0:
                raise RuntimeError(f'Port {address.port} is occupied but not healthy. Existing process preserved.')
        missing.append(True)
    # Never reuse a ComfyUI listener merely because an arbitrary health URL works.
    if not missing[0]:
        stats = health(urls[0])
        args = (stats or {}).get('system', {}).get('argv', [])
        declared = args[args.index('--base-directory') + 1] if '--base-directory' in args else None
        if not declared or Path(declared).resolve() != base:
            raise RuntimeError('ComfyUI identity could not be matched to the saved environment. Existing service preserved.')
        if ('--highvram' in args) != (policy is None) or '--disable-smart-memory' in args or '--reserve-vram' not in args or args[args.index('--reserve-vram') + 1] != '0':
            raise RuntimeError('Saved runtime residency/resource policy differs. Existing service preserved.')
    if not missing[1]:
        workflow = health(urls[1]) or {}
        if workflow.get('environment') != name or workflow.get('comfy_url', '').rstrip('/') != comfy.rstrip('/'):
            raise RuntimeError('Workflow service identity does not match the saved environment. Existing service preserved.')
    owned = []
    evidence = Path(workspace) / '.metadata/start-receipts' / uuid.uuid4().hex
    evidence.mkdir(parents=True)
    receipt = {'version': 1, 'environment': name, 'workspace': workspace,
               'comfy_url': comfy, 'serve_url': serve, 'owned': [], 'reused': [], 'phase': 'starting', 'explicitPolicy': policy}
    commands[1].extend(['--state-db', str(evidence / 'serve.sqlite')])
    def save():
        temporary = evidence / 'receipt.pending'
        temporary.write_text(json.dumps(receipt, indent=2)); temporary.replace(evidence / 'receipt.json')
    def identity(pid):
        if sys.platform != 'linux' or not isinstance(pid, int): return None
        try:
            stat = (Path('/proc') / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()
            return {'platform': 'linux', 'pid': pid, 'start': stat[19],
                    'boot': Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
        except (OSError, IndexError): return None
    save()
    try:
        for needed, command, url in zip(missing, commands, urls):
            if not needed:
                receipt['reused'].append(url); save()
                print('Service already running: ' + url, flush=True)
                continue
            print('Starting saved runtime service: ' + url, flush=True)
            options = {'start_new_session': True} if os.name != 'nt' else {'creationflags': subprocess.CREATE_NEW_PROCESS_GROUP}
            # Persistent grandchildren must not inherit the setup runner's pipe.
            # Otherwise command completion waits forever for that pipe's EOF.
            log = evidence / ('service-' + str(len(owned)) + '.log')
            with log.open('ab') as output:
                child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT,
                    env={**os.environ, 'COMFYGIT_HOME': workspace}, **options)
            owned.append(child)
            receipt['owned'].append({'identity': identity(child.pid), 'command': command, 'log': str(log)}); save()
            deadline = time.monotonic() + 120
            while not matches(url, health(url)):
                if child.poll() is not None:
                    raise RuntimeError(f'Runtime exited with code {child.returncode}; see startup log')
                if time.monotonic() >= deadline:
                    raise RuntimeError('Runtime startup timed out; see startup log')
                time.sleep(1)
            if child.poll() is not None:
                raise RuntimeError('Runtime child exited before its matching service was verified')
        print('Saved runtime services are ready', flush=True)
        # A healthy front door can precede its first manifest read. Warm that
        # read before short readiness probes; it never submits a contract.
        deadline = time.monotonic() + 120
        while True:
            contracts = health(serve + '/contracts')
            if isinstance(contracts, dict) and contracts.get('environment') == name and isinstance(contracts.get('contracts'), list):
                break
            if time.monotonic() >= deadline:
                raise RuntimeError('Saved workflow contracts did not become ready; no generation was submitted')
            time.sleep(.5)
        receipt['phase'] = 'ready'; save()
        print(json.dumps({'runtimeStartReceipt': str(evidence / 'receipt.json')}), flush=True)
    except BaseException:
        receipt['phase'] = 'failed'; save()
        for child in owned:
            if os.name == 'nt':
                subprocess.run(['taskkill', '/PID', str(child.pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                try:
                    os.killpg(child.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
        raise


if __name__ == '__main__':
    start(*sys.argv[1:])
