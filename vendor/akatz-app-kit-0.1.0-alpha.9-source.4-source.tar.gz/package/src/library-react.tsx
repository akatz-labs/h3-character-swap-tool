import { useEffect, useRef, useState } from 'react';
import {
  libraryKind,
  type LibraryAdapter,
  type LibraryItem,
  type LibraryRegistry,
  type LibraryQuery,
} from './library.js';
import { Dialog, Icon, SelectMenu } from './ui.js';
import { MediaDetailDialog } from './gallery-react.js';

export interface LibrarySelection {
  destination: string;
  maxItems: number;
  /** Null means eligible; a string explains why this input cannot accept the item. */
  rejection: (item: LibraryItem) => string | null;
  /** Resolve only once the app has a validated import receipt and has applied it. */
  onUse: (item: LibraryItem) => Promise<void>;
  onDone: () => void;
  onBusyChange: (busy: boolean) => void;
}

function Thumbnail({ item, adapter }: { item: LibraryItem; adapter: LibraryAdapter }) {
  const [failed, setFailed] = useState(false);
  const src = adapter.thumbnailUrl(item),
    kind = libraryKind(item);
  return src && !failed ? (
    <img src={src} loading="lazy" decoding="async" alt="" onError={() => setFailed(true)} />
  ) : (
    <span className="ak-library-placeholder">
      <Icon
        name={
          kind === 'image'
            ? 'image'
            : kind === 'video'
              ? 'film'
              : kind === 'audio'
                ? 'music'
                : 'boxes'
        }
      />
      {item.available ? (kind === 'model' ? '3D asset' : kind) : 'Unavailable'}
    </span>
  );
}

/** One browser: browsing has no selection controls; consumers explicitly opt into picking. */
export function SharedLibraryBrowser({
  adapter,
  selection,
}: {
  adapter: LibraryAdapter;
  selection?: LibrarySelection;
}) {
  const [registry, setRegistry] = useState<LibraryRegistry>({ apps: [], projects: [] });
  const [registryError, setRegistryError] = useState('');
  const [registryLoading, setRegistryLoading] = useState(true);
  const [revision, setRevision] = useState(0);
  const [scope, setScope] = useState<Pick<LibraryQuery, 'appId' | 'instanceId' | 'projectId'>>({});
  const [query, setQuery] = useState(''),
    [search, setSearch] = useState('');
  const [kind, setKind] = useState<LibraryQuery['kind']>('all');
  const [items, setItems] = useState<LibraryItem[]>([]),
    [nextOffset, setNextOffset] = useState<number | null>(null);
  const [loading, setLoading] = useState(true),
    [error, setError] = useState('');
  const [picked, setPicked] = useState<LibraryItem[]>([]),
    [busy, setBusy] = useState(false),
    [useError, setUseError] = useState('');
  const [preview, setPreview] = useState<LibraryItem | null>(null);
  const [pageNumber, setPageNumber] = useState(0);
  const request = useRef<AbortController | null>(null),
    inFlight = useRef(false),
    useLock = useRef(false);
  useEffect(() => {
    const timer = setTimeout(() => setSearch(query), 250);
    return () => clearTimeout(timer);
  }, [query]);
  useEffect(() => {
    const controller = new AbortController();
    setRegistryLoading(true);
    setRegistryError('');
    void adapter
      .registry(controller.signal)
      .then((value) => {
        if (!controller.signal.aborted) setRegistry(value);
      })
      .catch((reason) => {
        if (!controller.signal.aborted) setRegistryError(String(reason));
      })
      .finally(() => {
        if (!controller.signal.aborted) setRegistryLoading(false);
      });
    return () => controller.abort();
  }, [adapter, revision]);
  useEffect(() => {
    const controller = new AbortController();
    request.current?.abort();
    request.current = controller;
    inFlight.current = true;
    setLoading(true);
    setError('');
    setItems([]);
    setNextOffset(null);
    setPageNumber(0);
    void adapter
      .page({ ...scope, kind, q: search, offset: 0 }, controller.signal)
      .then((page) => {
        if (controller.signal.aborted) return;
        setItems(page.items);
        setNextOffset(page.nextOffset);
      })
      .catch((reason) => {
        if (!controller.signal.aborted) setError(String(reason));
      })
      .finally(() => {
        if (!controller.signal.aborted) {
          inFlight.current = false;
          setLoading(false);
        }
      });
    return () => controller.abort();
  }, [adapter, scope, kind, search, revision]);
  async function more() {
    const controller = request.current;
    if (!controller || controller.signal.aborted || inFlight.current || nextOffset === null) return;
    const offset = nextOffset;
    inFlight.current = true;
    setLoading(true);
    setError('');
    try {
      const page = await adapter.page({ ...scope, kind, q: search, offset }, controller.signal);
      if (controller.signal.aborted) return;
      setItems(page.items);
      setNextOffset(page.nextOffset);
      setPageNumber((n) => n + 1);
    } catch (reason) {
      if (!controller.signal.aborted) setError(String(reason));
    } finally {
      if (!controller.signal.aborted) {
        inFlight.current = false;
        setLoading(false);
      }
    }
  }
  const appName = (appId: string) =>
    registry.apps.find((app) => app.appId === appId)?.name ?? appId;
  const projectName = (item: Pick<LibraryItem, 'appId' | 'instanceId' | 'projectId'>) =>
    registry.projects.find(
      (project) =>
        project.appId === item.appId &&
        project.instanceId === item.instanceId &&
        project.projectId === item.projectId,
    )?.name ?? item.projectId;
  const reject = (item: LibraryItem) =>
    !item.available
      ? 'Original media is unavailable.'
      : item.trashedAt
        ? 'Media is in trash.'
        : (selection?.rejection(item) ?? null);
  function toggle(item: LibraryItem) {
    if (!selection || busy || reject(item)) return;
    setUseError('');
    setPicked((current) =>
      current.some((row) => row.id === item.id)
        ? current.filter((row) => row.id !== item.id)
        : current.length < selection.maxItems
          ? [...current, item]
          : current,
    );
  }
  async function useSelected() {
    if (!selection || useLock.current || !picked.length) return;
    useLock.current = true;
    setBusy(true);
    selection.onBusyChange(true);
    setUseError('');
    try {
      for (const item of picked) {
        const issue = reject(item);
        if (issue) throw new Error(issue);
        await selection.onUse(item);
        setPicked((current) => current.filter((row) => row.id !== item.id));
      }
      selection.onDone();
    } catch (reason) {
      setUseError(reason instanceof Error ? reason.message : 'Could not add the selected media.');
    } finally {
      useLock.current = false;
      setBusy(false);
      selection.onBusyChange(false);
    }
  }
  const groupIds = [...new Set(registry.apps.map((app) => app.appId))];
  return (
    <section className="ak-library-browser" aria-label="Shared Library browser" aria-busy={busy}>
      <div className="ak-library-layout">
        <nav className="ak-library-tree" aria-label="Library apps and projects">
          <button
            type="button"
            data-active={!scope.appId}
            disabled={busy}
            onClick={() => setScope({})}
          >
            <Icon name="grid" />
            All media
          </button>
          <p className="ak-eyebrow">Apps on this machine</p>
          {registryLoading && <p role="status">Loading apps…</p>}
          {registryError && <p role="alert">{registryError}</p>}
          {!registryLoading && !registryError && !groupIds.length && (
            <p className="ak-muted">No apps have published media yet.</p>
          )}
          {groupIds.map((appId) => (
            <details key={appId} open>
              <summary>{appName(appId)}</summary>
              <button
                type="button"
                disabled={busy}
                data-active={scope.appId === appId && !scope.instanceId}
                onClick={() => setScope({ appId })}
              >
                All outputs
              </button>
              {registry.apps
                .filter((app) => app.appId === appId)
                .map((app) => (
                  <div className="ak-library-instance" key={app.instanceId}>
                    {registry.apps.filter((row) => row.appId === appId).length > 1 && (
                      <small className="ak-muted">Instance · {app.instanceId.slice(-8)}</small>
                    )}
                    {registry.projects
                      .filter(
                        (project) =>
                          project.appId === appId && project.instanceId === app.instanceId,
                      )
                      .map((project) => (
                        <button
                          type="button"
                          key={project.projectId}
                          disabled={busy}
                          data-active={
                            scope.appId === appId &&
                            scope.instanceId === project.instanceId &&
                            scope.projectId === project.projectId
                          }
                          onClick={() =>
                            setScope({
                              appId,
                              instanceId: project.instanceId,
                              projectId: project.projectId,
                            })
                          }
                        >
                          <Icon name="folder" />
                          <span>{project.name}</span>
                        </button>
                      ))}
                  </div>
                ))}
            </details>
          ))}
        </nav>
        <div className="ak-library-results">
          <p className="ak-library-breadcrumb">
            Shared Library / {scope.appId ? appName(scope.appId) : 'All media'}
            {scope.projectId && scope.instanceId && scope.appId
              ? ' / ' +
                projectName({
                  appId: scope.appId,
                  instanceId: scope.instanceId,
                  projectId: scope.projectId,
                })
              : ''}
          </p>
          <div className="ak-library-toolbar">
            <label className="ak-library-search">
              <Icon name="search" />
              <input
                type="search"
                aria-label="Search shared media"
                placeholder="Search this location"
                value={query}
                disabled={busy}
                onChange={(event) => setQuery(event.target.value)}
              />
            </label>
            <SelectMenu
              label="Media type"
              value={kind}
              placeholder="All media"
              disabled={busy}
              options={[
                { value: 'all', label: 'All media' },
                { value: 'image', label: 'Images' },
                { value: 'video', label: 'Video' },
                { value: 'audio', label: 'Audio' },
                { value: 'model', label: '3D' },
              ]}
              onChange={(value) => setKind(value as LibraryQuery['kind'])}
            />
            <button
              type="button"
              disabled={busy || loading}
              onClick={() => setRevision((n) => n + 1)}
            >
              <Icon name="refresh" />
              Refresh
            </button>
          </div>
          <p className="ak-muted">
            {items.length} items on this page · Newest first
            {selection ? ' · ' + selection.destination : ''}
          </p>
          {selection && (
            <p className="ak-muted">
              Choose up to {selection.maxItems} {selection.maxItems === 1 ? 'item' : 'items'}.
              Unsupported media can be previewed but cannot be selected.
            </p>
          )}
          {loading && <p role="status">Loading shared media…</p>}
          {error && (
            <p role="alert">
              {error}{' '}
              <button
                disabled={loading}
                onClick={() => (nextOffset === null ? setRevision((n) => n + 1) : void more())}
              >
                Retry loading
              </button>
            </p>
          )}
          <div className="ak-library-grid">
            {items.map((item) => {
              const issue = reject(item),
                selected = picked.some((row) => row.id === item.id);
              return (
                <article className="ak-library-card" key={item.id} data-selected={selected}>
                  <button
                    type="button"
                    className="ak-library-open"
                    aria-label={`Preview ${item.name}`}
                    onClick={() => setPreview(item)}
                    disabled={busy}
                  >
                    <div className="ak-library-thumb">
                      <Thumbnail item={item} adapter={adapter} />
                      <span className="ak-library-kind">
                        {libraryKind(item) === 'model' ? '3D' : libraryKind(item)}
                      </span>
                    </div>
                    <div className="ak-library-card-title">
                      <strong title={item.name}>{item.name}</strong>
                      <small>
                        {appName(item.appId)} · {projectName(item)}
                      </small>
                    </div>
                  </button>
                  {selection && (
                    <label className="ak-library-select" title={issue ?? 'Select media'}>
                      <input
                        type="checkbox"
                        aria-label={`Select ${item.name}`}
                        checked={selected}
                        disabled={
                          busy ||
                          Boolean(issue) ||
                          (!selected && picked.length >= selection.maxItems)
                        }
                        onChange={() => toggle(item)}
                      />
                      <span>{issue ?? 'Select'}</span>
                    </label>
                  )}
                </article>
              );
            })}
          </div>
          {!loading && !error && !items.length && (
            <p>
              No matching media in this page.
              {nextOffset !== null
                ? ' Continue to the next page to browse older results.'
                : ' Try another app, project, or search.'}
            </p>
          )}
          <div className="ak-library-pagination">
            {pageNumber > 0 && (
              <button
                type="button"
                disabled={busy || loading}
                onClick={() => setRevision((n) => n + 1)}
              >
                Back to newest
              </button>
            )}
            {nextOffset !== null && (
              <button type="button" disabled={busy || loading} onClick={() => void more()}>
                Next page
              </button>
            )}
          </div>
        </div>
      </div>
      {selection && (
        <footer className="ak-library-footer">
          <div>
            <span role="status">{busy ? 'Adding media…' : `${picked.length} selected`}</span>
            <small>Originals stay in their source library.</small>
          </div>
          <button type="button" disabled={busy || !picked.length} onClick={() => setPicked([])}>
            Clear selection
          </button>
          <button
            type="button"
            className="ak-primary"
            disabled={busy || !picked.length}
            onClick={() => void useSelected()}
          >
            Add to project
          </button>
          {useError && (
            <p role="alert">
              {useError} Completed imports have already been added to the composer.
            </p>
          )}
        </footer>
      )}
      {preview && (
        <MediaDetailDialog
          title={preview.name}
          itemKey={preview.id}
          onClose={() => setPreview(null)}
          preview={
            !preview.available ? (
              <p>Original media is unavailable.</p>
            ) : libraryKind(preview) === 'image' ? (
              <img src={adapter.mediaUrl(preview)} alt={preview.name} />
            ) : libraryKind(preview) === 'video' ? (
              <video src={adapter.mediaUrl(preview)} controls autoPlay playsInline />
            ) : libraryKind(preview) === 'audio' ? (
              <audio src={adapter.mediaUrl(preview)} controls autoPlay />
            ) : (
              <p>3D preview is not available yet.</p>
            )
          }
        >
          <p>
            {appName(preview.appId)} / {projectName(preview)}
          </p>
          <p>
            {preview.mime} · {(preview.size / 1024 ** 2).toFixed(1)} MiB
          </p>
          <p className="ak-muted">{preview.createdAt}</p>
          {selection && (
            <button
              type="button"
              disabled={
                Boolean(reject(preview)) ||
                (!picked.some((row) => row.id === preview.id) &&
                  picked.length >= selection.maxItems)
              }
              onClick={() => {
                toggle(preview);
                setPreview(null);
              }}
            >
              {picked.some((row) => row.id === preview.id)
                ? 'Remove selection'
                : 'Select this item'}
            </button>
          )}
        </MediaDetailDialog>
      )}
    </section>
  );
}

export function SharedLibraryPicker({
  adapter,
  onClose,
  ...selection
}: LibrarySelection & { adapter: LibraryAdapter; onClose: () => void }) {
  const [busy, setBusy] = useState(false);
  return (
    <Dialog
      title="Choose from Shared Library"
      description={selection.destination}
      variant="library"
      busy={busy}
      onClose={onClose}
    >
      <SharedLibraryBrowser
        adapter={adapter}
        selection={{
          ...selection,
          onBusyChange: (value) => {
            setBusy(value);
            selection.onBusyChange(value);
          },
        }}
      />
    </Dialog>
  );
}
