import { createHash, timingSafeEqual } from 'node:crypto';
import { constants, openSync, fstatSync, readFileSync, closeSync } from 'node:fs';
import { isAbsolute } from 'node:path';
import { hash, identifier, record } from './session-contracts.js';

interface Grant {
  appId: string;
  instanceId: string;
  installationId: string;
  installationDigest: string;
  features: string[];
  collectionRoots: string[];
}
interface Installation { id: string; appId: string }
interface Job {
  appId: string; instanceId: string; installationId: string; feature: string;
  installation: Installation;
}
const denied = () => Object.assign(new Error('Execution access denied'), { status: 403 });
function canonical(value: unknown): string {
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value !== null && typeof value === 'object') {
    const v = record(value);
    return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + canonical(v[k])).join(',') + '}';
  }
  return JSON.stringify(value);
}
export function contentDigest(value: unknown): string {
  return createHash('sha256').update(canonical(value)).digest('hex');
}
export function installationDigest(value: unknown): string {
  // Readiness observations are executor-owned metadata, not executable policy.
  const {observations, ...definition} = record(value);
  return contentDigest(definition);
}

/** Service credentials never enter job documents or HTTP error messages. */
export function readExecutionToken(path: string): string {
  if (!isAbsolute(path)) throw new Error('Execution token requires an absolute path');
  const fd = openSync(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const stat = fstatSync(fd);
    if (!stat.isFile() || (stat.mode & 0o077) !== 0 || stat.size > 512 ||
        (stat.uid !== 0 && stat.uid !== process.getuid?.()))
      throw new Error('Execution token must be a private, owned regular file');
    const token = readFileSync(fd, 'utf8').trim();
    if (!/^[A-Za-z0-9_-]{43,128}$/.test(token)) throw new Error('Invalid execution token file');
    return token;
  } finally { closeSync(fd); }
}

/** Optional hosted boundary. The operator/local server retains its existing API. */
export class ExecutionAccess {
  readonly grants: Grant[];
  readonly maxInputBytes: number;
  private readonly tokenDigest: Buffer;
  constructor(value: unknown, token: string) {
    const v = record(value);
    if (Object.keys(v).some(k => !['version', 'grants', 'maxInputBytes'].includes(k)) || v.version !== 1 ||
        !Array.isArray(v.grants) || !v.grants.length || v.grants.length > 16)
      throw new Error('Invalid execution policy');
    if (!Number.isSafeInteger(v.maxInputBytes) || Number(v.maxInputBytes) < 1 || Number(v.maxInputBytes) > 1024 ** 3)
      throw new Error('Execution input limit must be between 1 byte and 1 GiB');
    this.maxInputBytes = Number(v.maxInputBytes);
    this.grants = v.grants.map(value => {
      const g = record(value);
      if (Object.keys(g).some(k => !['appId', 'instanceId', 'installationId', 'installationDigest', 'features', 'collectionRoots'].includes(k)) ||
          !Array.isArray(g.features) || !g.features.length) throw new Error('Invalid execution grant');
      const roots = g.collectionRoots ?? [];
      if (!Array.isArray(roots) || roots.length > 4 || roots.some(r => typeof r !== 'string' || !isAbsolute(r)))
        throw new Error('Invalid collection roots');
      return { appId: identifier(g.appId), instanceId: identifier(g.instanceId), installationId: identifier(g.installationId),
        installationDigest: hash(g.installationDigest), features: g.features.map(identifier), collectionRoots: roots as string[] };
    });
    if (!/^[A-Za-z0-9_-]{43,128}$/.test(token)) throw new Error('Invalid execution credential');
    this.tokenDigest = createHash('sha256').update('Bearer ' + token).digest();
  }
  authenticate(authorization: string | undefined): void {
    if (!authorization || !timingSafeEqual(this.tokenDigest, createHash('sha256').update(authorization).digest()))
      throw Object.assign(new Error('Executor authentication required'), { status: 401 });
  }
  permitsRoute(method: string, path: string): boolean {
    if (method === 'GET' && ['/v1/health', '/v1/status', '/v1/installations', '/v1/jobs'].includes(path)) return true;
    if (method === 'POST' && ['/v1/jobs', '/v1/jobs/cancel-admission'].includes(path)) return true;
    if (method === 'PUT' && /^\/v1\/inputs\/[a-f0-9]{64}$/.test(path)) return true;
    if (method === 'GET' && /^\/v1\/jobs\/[a-zA-Z0-9._-]+(?:\/files\/[^/]+)?$/.test(path)) return true;
    return method === 'POST' && /^\/v1\/jobs\/[a-zA-Z0-9._-]+\/(cancel|reconcile|collected)$/.test(path);
  }
  permitsInstallation(installation: Installation): boolean {
    return this.grants.some(g => g.installationId === installation.id && g.appId === installation.appId &&
      g.installationDigest === installationDigest(installation));
  }
  submission(value: unknown, installations: Installation[]): void {
    const v = record(value);
    const installation = installations.find(i => i.id === v.installationId && i.appId === v.appId);
    if (!installation || !this.grants.some(g => g.appId === v.appId && g.instanceId === v.instanceId &&
      g.installationId === v.installationId && g.features.includes(String(v.feature)) &&
      g.installationDigest === installationDigest(installation))) throw denied();
  }
  permitsJob(job: Job): boolean {
    return this.grants.some(g => g.appId === job.appId && g.instanceId === job.instanceId &&
      g.installationId === job.installationId && g.features.includes(job.feature) &&
      g.installationDigest === installationDigest(job.installation));
  }
  collectionRoots(job: Job): string[] {
    if (!this.permitsJob(job)) throw denied();
    return this.grants.filter(g => g.installationId === job.installationId && g.instanceId === job.instanceId)
      .flatMap(g => g.collectionRoots);
  }
}
