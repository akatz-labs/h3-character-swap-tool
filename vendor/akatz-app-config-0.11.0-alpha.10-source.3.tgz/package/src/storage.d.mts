import type { DatabaseSync } from 'node:sqlite';
import type { ConfigOptions } from './index.mjs';
export interface StoragePaths { dataRoot: string; root: string; database: string; objects: string; staging: string; cache: string; backups: string }
export interface AppIdentity { schemaVersion: 1; appId: string; instanceId: string; createdAt: string }
export interface StoredObject { key: string; hash: string; size: number; mime: string; createdAt: string; path: string }
export interface AppDatabase {
  db: DatabaseSync; paths: StoragePaths; identity: AppIdentity;
  transaction<T>(fn: () => T): T;
  object(key: string): StoredObject;
  objects(): StoredObject[];
  putObject(key: string, source: string | Uint8Array | AsyncIterable<Uint8Array>, options?: {mime?: string; expectedHash?: string; createdAt?: string; maxBytes?: number; allowEmpty?: boolean}): Promise<StoredObject>;
  readObject(key: string): Promise<Buffer>;
  materializeObject(key: string, relativePath: string): Promise<string>;
  verifyObjects(): Promise<{objects: number}>;
  backup(destination: string): Promise<string>;
  close(): void;
}
export function storagePaths(appId: string, options?: ConfigOptions & {root?: string}): StoragePaths;
export function ensureAppIdentity(appId: string, root: string, options?: {legacyInstanceId?: string}): AppIdentity;
export function hashFile(file: string): Promise<{hash: string; size: number}>;
export function syncDirectory(directory: string): Promise<void>;
export function openAppDatabase(options: ConfigOptions & {appId: string; root?: string; filename?: string; migrations?: Array<{version: number; sql: string; up?: (db: DatabaseSync) => void}>; legacyInstanceId?: string}): AppDatabase;
