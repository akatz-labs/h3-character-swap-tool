import type { DesktopApp } from './desktop-apps.mjs';
export interface DesktopLaunch {
  schemaVersion: 1;
  appId: string;
  defaultPort: number;
  module: { path: string; sha256: string };
  files: Array<{ path: string; sha256: string }>;
  modulePath: string;
  digest: string;
}
export interface DesktopHealth {
  appId?: string;
  identity?: string;
  pid?: number;
  attemptId?: string;
  phase: 'starting' | 'ready' | 'failed' | 'conflict';
  error?: string;
}
export const DESKTOP_HEALTH_PATH: string;
export function desktopRunRoot(): string;
export function localDesktopUrl(value: string): URL;
export function readDesktopLaunch(root: string, options?: { verify?: boolean }): Promise<DesktopLaunch | null>;
export function buildDesktopLaunch(options: { root: string; appId: string; defaultPort: number; files: string[] }): Promise<Omit<DesktopLaunch, 'modulePath' | 'digest'>>;
export function desktopIdentity(app: DesktopApp): string;
export function desktopHealth(app: DesktopApp): Promise<DesktopHealth | null>;
export function stopDesktopApp(app: DesktopApp): Promise<boolean>;
export function readDesktopLog(appId: string, attemptId: string): Promise<string>;
export function startDesktopApp(appId: string, options?: { timeoutMs?: number }): Promise<{ url: string; reused: boolean }>;
export interface DesktopService {
  name:string;args:string[];cwd?:string;env?:Record<string,string>;healthPath:string;
  verifyHealth?:(value:unknown)=>boolean;
}
export interface DesktopSupervisor {
  startNode(value:DesktopService):Promise<string>;
  startProcess(value:DesktopService&{executable:string;readyPrefix?:string}):Promise<string>;
}
