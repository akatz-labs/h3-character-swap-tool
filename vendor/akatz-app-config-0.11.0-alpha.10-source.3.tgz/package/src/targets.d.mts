export interface ExecutionTarget {
  id: string;
  name: string;
  kind: "local" | "ssh";
  host?: string;
  port?: number;
  workspace: string;
  modelsRoot?: string;
  libraryRoot: string;
  pythonExecutable: string;
}
export interface TargetRecipe {
  id: string;
  manifest: string;
  sha256: string;
}
export interface ModelReuse {
  hash: string;
  filename: string;
  relativePath: string;
  sizeBytes: number | null;
  action: "reuse" | "verify" | "download" | "missing-source";
  locations: { root: string; path: string }[];
  identityEvidence: string | null;
}
export interface AppReusePlan {
  id: string;
  recipeSha256: string;
  nodeCount: number;
  workflowCount: number;
  models: ModelReuse[];
  reuseCount: number;
  reuseBytes: number;
  downloadCount: number;
  downloadBytes: number;
  unknownDownloadSizes: number;
  verificationCount: number;
  blockedCount: number;
}
export interface TargetReusePlan {
  schemaVersion: 1;
  planId: string;
  observedAt: string;
  coreVersion: string;
  targetId: string;
  workspace: string;
  modelsRoot: string;
  indexedModelCount: number;
  indexedModelBytes: number;
  environments: { name: string; complete: boolean; manifestSha256: string }[];
  apps: AppReusePlan[];
  warnings: string[];
  runtimeDownloadBytes: null;
}
export function validateTarget(target: ExecutionTarget): ExecutionTarget;
export function targetInvocation(target: ExecutionTarget): { command: string; args: string[] };
export function executeTarget(
  target: ExecutionTarget,
  request: unknown,
  options?: { signal?: AbortSignal; timeout?: number },
): Promise<unknown>;
export function buildReusePlan(target: ExecutionTarget, snapshot: unknown): TargetReusePlan;
export function inspectTarget(
  target: ExecutionTarget,
  recipes: TargetRecipe[],
  options?: { signal?: AbortSignal; timeout?: number },
): Promise<TargetReusePlan>;
