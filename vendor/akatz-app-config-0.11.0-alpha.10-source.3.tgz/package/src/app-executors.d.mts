import {ExecutorClient,type ExecutorTarget,type ExecutorRegistry} from './executor-client.mjs';
export interface ExecutorBinding {target:ExecutorTarget;executorId:string;installationId:string;revision:string;feature:string;placement?:import('../dist/auto-placement.js').PlacementDecision}
export interface PlacementOptions {installationRevision?:string;permittedTargetIds?:string[];compatibility?:import('../dist/session-contracts.js').RuntimeCompatibility}
export class AppExecutors {
  constructor(appId:string,options?:{localClient?:ExecutorClient;autoBootstrap?:boolean;installationPlan?:(client:ExecutorClient,target:ExecutorTarget,settings:Record<string,unknown>)=>Promise<{id:string;digest:string;[key:string]:unknown}>});
  local:ExecutorClient;
  ready():Promise<void>;
  list():Promise<ExecutorRegistry>;
  bind(feature:string,requestedId?:string,options?:PlacementOptions):Promise<ExecutorBinding>;
  client(binding:ExecutorBinding):Promise<ExecutorClient>;
  operation(action:string,input?:Record<string,unknown>):Promise<unknown>;
}
