export class ComfyGitClient {
  constructor(origin: string, sessionId: string, options?: { fetch?: typeof fetch });
  request(path: string, init?: RequestInit): Promise<Response>;
  upload(bytes: BodyInit, metadata: { filename: string; mime: string }): Promise<string>;
  run(workflow: string, inputs: Record<string, unknown>): Promise<{ run_id: string; status?: string }>;
  runs(): Promise<{ runs: Record<string, unknown>[] }>;
}
