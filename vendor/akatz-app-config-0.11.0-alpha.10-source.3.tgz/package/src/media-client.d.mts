export interface MediaAssociation { appId: string; instanceId: string; projectId: string }
export interface MediaImport extends MediaAssociation { sourceKey: string; name: string; parents?: string[]; origin?: string | null; createdAt?: string }
export interface MediaRecord extends MediaImport { id: string; libraryId: string; hash: string; size: number; mime: string; createdAt: string; available: boolean; trashedAt: string | null; parents: string[]; links: MediaAssociation[] }
export interface MediaPage { items: MediaRecord[]; nextOffset: number | null }
export interface AppRegistration { appId: string; instanceId: string; name: string; dataRoot: string }
export interface ProjectRegistration extends MediaAssociation { name: string; createdAt?: string }
export class MediaClient {
  constructor(baseUrl: string, options?: { fetch?: typeof fetch });
  baseUrl: string;
  health(): Promise<{ ok: boolean; apiVersion: number; schemaVersion: number; libraryId: string; capabilities: string[] }>;
  list(filters?: { appId?: string; mime?: string; kind?: 'image'|'video'|'model'; q?: string; limit?: number; offset?: number; includeTrashed?: boolean }): Promise<MediaPage>;
  registerApp(value: AppRegistration): Promise<{ok: boolean}>;
  registerProject(value: ProjectRegistration): Promise<{ok: boolean}>;
  apps(filters?: {appId?: string; instanceId?: string}): Promise<{items: Array<AppRegistration & {updatedAt: string}>}>;
  projects(filters?: {appId?: string; instanceId?: string}): Promise<{items: Array<ProjectRegistration & {updatedAt: string}>}>;
  get(id: string): Promise<MediaRecord>;
  import(bytes: BodyInit | AsyncIterable<Uint8Array>, metadata: MediaImport): Promise<MediaRecord>;
  link(id: string, association: MediaAssociation, method?: 'POST' | 'DELETE'): Promise<MediaRecord>;
  trash(id: string): Promise<MediaRecord>;
  restore(id: string): Promise<MediaRecord>;
  fileUrl(id: string): string;
  file(id: string, init?: RequestInit): Promise<Response>;
}
