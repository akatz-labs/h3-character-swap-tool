import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile, rm, symlink } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { collectExecutionOutputs } from '../dist/execution-collection.js';
import { contentDigest } from '../dist/execution-access.js';

async function fixture(t) {
  const root=await mkdtemp(join(tmpdir(),'collection-'));
  t.after(()=>rm(root,{recursive:true,force:true}));
  const base=join(root,'jobs','job','outputs'), stage=join(root,'media','job');
  await mkdir(base,{recursive:true});await mkdir(stage,{recursive:true});
  const bytes=Buffer.from('verified result');
  for(const dir of [base,stage]){await writeFile(join(dir,'video.mp4'),bytes);await writeFile(join(dir,'receipt.json'),'retain');}
  const files=[{name:'video.mp4',hash:createHash('sha256').update(bytes).digest('hex'),size:bytes.length}];
  const job={id:'job',sourceJobId:'source',phase:'completed',result:{files}};
  const ack={sourceJobId:'source',manifestDigest:contentDigest(files)};
  return {root,base,stage,job,ack,collect:()=>collectExecutionOutputs(root,job,ack,[join(root,'media')])};
}
test('collection removes only manifest media, preserves receipts and is replayable',async t=>{
  const f=await fixture(t);
  assert.equal((await f.collect()).removedFiles,2);
  assert.equal((await f.collect()).removedFiles,0);
  assert.equal(await readFile(join(f.base,'receipt.json'),'utf8'),'retain');
  assert.equal(JSON.parse(await readFile(join(f.root,'jobs/job/collected.json'),'utf8')).manifestDigest,f.ack.manifestDigest);
});
test('changed remote copy prevents all deletions',async t=>{
  const f=await fixture(t);await writeFile(join(f.stage,'video.mp4'),'changed result!');
  await assert.rejects(f.collect(),/changed/);
  assert.equal(await readFile(join(f.base,'video.mp4'),'utf8'),'verified result');
});
test('collection refuses wrong custody, active jobs, traversal and parent symlinks',async t=>{
  const f=await fixture(t);
  await assert.rejects(collectExecutionOutputs(f.root,f.job,{...f.ack,sourceJobId:'other'},[]));
  await assert.rejects(collectExecutionOutputs(f.root,{...f.job,phase:'rendering'},f.ack,[]));
  await assert.rejects(collectExecutionOutputs(f.root,f.job,{...f.ack,path:'/etc/passwd'},[]));
  const outside=join(f.root,'outside');await mkdir(outside);await writeFile(join(outside,'video.mp4'),'verified result');
  await symlink(outside,join(f.base,'link'));
  for(const name of ['../../outside/video.mp4','link/video.mp4']) {
    const files=[{...f.job.result.files[0],name}];
    await assert.rejects(collectExecutionOutputs(f.root,{...f.job,result:{files}}, {...f.ack,manifestDigest:contentDigest(files)},[]));
  }
  assert.equal(await readFile(join(outside,'video.mp4'),'utf8'),'verified result');
});
