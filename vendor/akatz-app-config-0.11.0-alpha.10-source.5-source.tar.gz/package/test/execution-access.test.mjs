import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, rm, chmod, symlink } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomBytes, createHash } from 'node:crypto';
import { ExecutionAccess, installationDigest, readExecutionToken } from '../dist/execution-access.js';
import { createExecutorServer } from '../src/executor-server.mjs';
import { ExecutorClient } from '../src/executor-client.mjs';

async function fixture(t, restricted=true) {
  const root=await mkdtemp(join(tmpdir(),'execution-access-'));
  const adapter=join(root,'adapter.mjs'), tokenFile=join(root,'token');
  const source="export async function run(){return {files:[]};}";
  await writeFile(adapter,source);
  const token=randomBytes(32).toString('base64url');
  await writeFile(tokenFile,token,{mode:0o600});
  const installation={id:'approved',appId:'h3-workbench',revision:createHash('sha256').update(source).digest('hex'),
    adapter,features:['swap'],probes:[{kind:'file',path:adapter}]};
  const grant={appId:installation.appId,instanceId:'beta-provider',installationId:installation.id,
    installationDigest:installationDigest(installation),features:['swap']};
  const access=new ExecutionAccess({version:1,grants:[grant],maxInputBytes:16},token);
  const service=createExecutorServer({root,dispatch:false,...(restricted?{executionAccess:access}:{})});
  for(const item of [installation,{...installation,id:'operator-only'}]) {
    const plan=service.executor.plan(item);await service.executor.install(plan.id,plan.digest);
  }
  await new Promise(resolve=>service.server.listen(0,'127.0.0.1',resolve));
  const client=new ExecutorClient({kind:'local',port:service.server.address().port,...(restricted?{tokenFile}:{})});
  const input={appId:installation.appId,instanceId:'beta-provider',installationId:installation.id,
    sourceJobId:'test-job',feature:'swap',inputs:{},files:[]};
  t.after(async()=>{await service.close();await rm(root,{recursive:true,force:true});});
  return {service,client,input,root,access,tokenFile,installation};
}

test('execution interface authenticates and fails closed for management routes and route variants',async t=>{
  const {client}=await fixture(t);
  const anonymous=new ExecutorClient({...client.target,tokenFile:undefined});
  await assert.rejects(anonymous.health(),e=>e.status===401);
  const health=await client.health();assert.ok(health.capabilities.includes('execution-only-v1'));
  for(const [method,path] of [
    ['POST','/v1/plans'],['POST','/v1/install'],['PUT','/v1/adapters/'+'a'.repeat(64)],
    ['POST','/v1/recipes'],['POST','/v1/runtime-paths'],['POST','/v1/resources'],
    ['POST','/v1/memory'],['POST','/v1/executors'],['GET','/v1/system'],
    ['GET','/v1/health/extra'],['POST','/v1/jobs/id/cancel/extra'],['GET','/v1/%68ealth'],
    ['POST','/v1/jobs/id/recover'],['POST','/v1/jobs/id/recovery-plan'],
  ]) await assert.rejects(client.request(path,{method,body:method==='GET'?undefined:'{}'}),e=>e.status===404,path);
});

test('fixed installation, feature and provider identity; other jobs are hidden',async t=>{
  const {client,input,service}=await fixture(t);
  assert.deepEqual((await client.readiness('h3-workbench')).map(r=>r.installation.id),['approved']);
  for(const changed of [{installationId:'operator-only'},{appId:'other'},{instanceId:'operator'},{feature:'install'}])
    await assert.rejects(client.submit({...input,...changed}),e=>e.status===403);
  const own=await client.submit(input);
  assert.equal((await client.submit(input)).id,own.id);
  const foreign=await service.executor.submit({...input,instanceId:'operator'});
  assert.deepEqual((await client.json('/v1/jobs')).items.map(j=>j.id),[own.id]);
  for(const suffix of ['', '/files/result.mp4', '/cancel', '/reconcile'])
    await assert.rejects(client.json('/v1/jobs/'+foreign.id+suffix,suffix==='/cancel'||suffix==='/reconcile'?{}:undefined),e=>e.status===404);
  assert.equal((await client.cancel(own.id)).phase,'cancelled');
  const changed=service.executor.installations()[0];
  // Altering an installation under the same ID must not bypass the approval digest.
  const approved=service.executor.installations().find(i=>i.id==='approved');
  service.executor.db.prepare('UPDATE installations SET document=? WHERE id=?').run(JSON.stringify({...approved,configuration:{changed:true}}),'approved');
  await assert.rejects(client.submit({...input,sourceJobId:'changed'}),e=>e.status===403);
  assert.ok(changed);
});

test('input staging has a byte limit and rejects mismatched content',async t=>{
  const {client}=await fixture(t);
  const bytes=Buffer.from('source'), hash=createHash('sha256').update(bytes).digest('hex');
  assert.equal((await client.request('/v1/inputs/'+hash,{method:'PUT',body:bytes})).status,200);
  await assert.rejects(client.request('/v1/inputs/'+'a'.repeat(64),{method:'PUT',body:bytes}));
  const large=Buffer.alloc(17);
  await assert.rejects(client.request('/v1/inputs/'+createHash('sha256').update(large).digest('hex'),{method:'PUT',body:large}));
});

test('local operator interface retains setup API without a beta credential',async t=>{
  const {client,installation}=await fixture(t,false);
  assert.equal((await client.health()).capabilities.includes('execution-only-v1'),false);
  assert.ok((await client.json('/v1/plans',installation)).id);
});

test('credential loader rejects permissive files and symlinks',async t=>{
  const {tokenFile,root}=await fixture(t);
  assert.equal(readExecutionToken(tokenFile).length,43);
  const link=join(root,'token-link');await symlink(tokenFile,link);
  assert.throws(()=>readExecutionToken(link));
  await chmod(tokenFile,0o644);assert.throws(()=>readExecutionToken(tokenFile),/private/);
});
