//! Shared native bootstrap. The SDK supervisor owns all domain/UI services.
use serde::Deserialize;
use serde_json::Value;
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use tauri::{Manager, WebviewUrl, WebviewWindow, WebviewWindowBuilder};
use std::time::{Duration, Instant};

#[derive(Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct AppConfig {
    pub app_id: String,
    pub title: String,
    pub payload_directory: String,
}
struct State { config: AppConfig, payload: PathBuf }

fn require_bootstrap(window: &WebviewWindow) -> Result<(), String> {
    let url = window.url().map_err(|e| e.to_string())?;
    let local = (url.scheme() == "tauri" && url.host_str() == Some("localhost"))
        || (url.scheme() == "http" && url.host_str() == Some("tauri.localhost"));
    if window.label() != "bootstrap" || !local {
        return Err("Native setup is restricted to this app's bundled bootstrap".into());
    }
    Ok(())
}

fn drain_bounded(mut stream: impl Read, limit:usize) -> std::io::Result<Vec<u8>> {
    let mut kept=Vec::new();let mut buffer=[0u8;4096];
    loop{let count=stream.read(&mut buffer)?;if count==0{break;}let retain=count.min((limit+1).saturating_sub(kept.len()));kept.extend_from_slice(&buffer[..retain]);}
    Ok(kept)
}

fn controller(payload: &Path, request: Value) -> Result<Value, String> {
    let executable = payload.join(if cfg!(windows) { "runtime/node/node.exe" } else { "runtime/node/node" });
    let mut child = Command::new(executable)
        .arg(payload.join("desktop/controller.mjs"))
        .current_dir(payload)
        .stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::piped())
        .spawn().map_err(|e| format!("Packaged desktop controller is unavailable: {e}"))?;
    child.stdin.take().ok_or("Controller input is unavailable")?
        .write_all(serde_json::to_string(&request).map_err(|e| e.to_string())?.as_bytes()).map_err(|e| e.to_string())?;
    // Drain both bounded streams concurrently. The fixed controller owns its timeout.
    let stdout = child.stdout.take().ok_or("Controller output is unavailable")?;
    let stderr = child.stderr.take().ok_or("Controller diagnostics are unavailable")?;
    let output = std::thread::spawn(move || drain_bounded(stdout,131072));
    let diagnostics = std::thread::spawn(move || drain_bounded(stderr,16384));
    let deadline=Instant::now()+Duration::from_secs(130);
    let status=loop{if let Some(status)=child.try_wait().map_err(|e|e.to_string())?{break status;}
        if Instant::now()>deadline{let _=child.kill();let _=child.wait();return Err("Desktop controller timed out; inspect the retained startup attempt before retrying".into());}
        std::thread::sleep(Duration::from_millis(100));};
    let bytes = output.join().map_err(|_| "Controller reader failed")?.map_err(|e|e.to_string())?;
    let errors = diagnostics.join().map_err(|_| "Controller diagnostic reader failed")?.map_err(|e|e.to_string())?;
    if bytes.len()>131072 || errors.len()>16384 { return Err("Desktop controller exceeded its diagnostic bound".into()); }
    // SDK review hashes preserve object insertion order. Cargo enables
    // serde_json/preserve_order across both directions of this IPC boundary.
    let result:Value=serde_json::from_slice(&bytes).map_err(|_|format!("Desktop startup failed: {}",String::from_utf8_lossy(&errors)))?;
    if !status.success() || result.get("ok").and_then(Value::as_bool)!=Some(true) {
        return Err(result.get("error").and_then(Value::as_str).unwrap_or("Desktop action failed").into());
    }
    Ok(result["result"].clone())
}

#[tauri::command]
async fn choose_data_folder(window:WebviewWindow)->Result<Option<String>,String>{
    require_bootstrap(&window)?;
    Ok(rfd::AsyncFileDialog::new().set_title("Choose application data folder").pick_folder().await
        .map(|f|f.path().to_string_lossy().into_owned()))
}

#[tauri::command]
async fn desktop_request(window:WebviewWindow,state:tauri::State<'_,State>,request:Value)->Result<Value,String>{
    require_bootstrap(&window)?;
    let opens=matches!(request.get("action").and_then(Value::as_str),Some("confirm"|"open"));
    let payload=state.payload.clone();
    let result=tauri::async_runtime::spawn_blocking(move||controller(&payload,request)).await.map_err(|e|e.to_string())??;
    if let Some(app_id)=result.get("appId").and_then(Value::as_str){
        if app_id!=state.config.app_id{return Err("The payload belongs to a different app".into());}
    }
    if opens {
        let endpoint=result.get("url").and_then(Value::as_str).ok_or("The owned app did not report its address")?;
        let url=url::Url::parse(endpoint).map_err(|e|e.to_string())?;
        if url.scheme()!="http" || url.host_str()!=Some("127.0.0.1") || url.port().is_none()
            || !url.username().is_empty() || url.password().is_some() || url.path()!="/" || url.query().is_some() || url.fragment().is_some(){
            return Err("The owned app reported an invalid local URL".into());
        }
        if let Some(existing)=window.app_handle().get_webview_window("product"){
            existing.show().map_err(|e|e.to_string())?;existing.set_focus().map_err(|e|e.to_string())?;
        }else{
            let origin=url.origin();
            WebviewWindowBuilder::new(window.app_handle(),"product",WebviewUrl::External(url))
                .title(&state.config.title).inner_size(1320.0,900.0).min_inner_size(390.0,640.0)
                .on_navigation(move |target|target.origin()==origin)
                .build().map_err(|e|e.to_string())?;
        }
        // Closing a product window does not stop the supervisor or accepted work.
        window.hide().map_err(|e|e.to_string())?;
    }
    Ok(result)
}

pub fn run(context:tauri::Context<tauri::Wry>,json:&str){
    let config:AppConfig=serde_json::from_str(json).expect("valid packaged desktop identity");
    assert!(!config.app_id.is_empty() && config.payload_directory=="payload");
    tauri::Builder::default().setup(move |app|{
        let payload=app.path().resource_dir()?.join(&config.payload_directory);
        app.manage(State{config:config.clone(),payload});
        Ok(())
    }).invoke_handler(tauri::generate_handler![choose_data_folder,desktop_request])
      .run(context).expect("desktop host could not start");
}
