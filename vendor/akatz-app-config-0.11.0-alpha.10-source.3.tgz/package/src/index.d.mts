export interface ComponentSelection { executable?: string; sourceRoot?: string; workRoot?: string; modelCache?: string }
export interface AppSettings { runtimeRoot?: string; modelCache?: string; components?: Record<string, ComponentSelection>; workspace?: string; environment?: string; dataRoot?: string; serveUrl?: string; comfyUrl?: string; apiUrl?: string }
export interface ConfigOptions { env?: NodeJS.ProcessEnv; platform?: NodeJS.Platform; home?: string }
export interface ResolvedConfig extends AppSettings { appId: string; configPath: string; configured: boolean; environmentRoot: string | null; sources: Record<string, string> }
export function configPath(options?: ConfigOptions): string;
export function readConfig(options?: ConfigOptions): { path: string; config: { schemaVersion: 1; defaults: AppSettings; apps: Record<string, AppSettings> }; exists: boolean };
export function resolveAppConfig(appId: string, defaults?: AppSettings, options?: ConfigOptions): ResolvedConfig;
export function verifyRecipe(path: string): { descriptor: { schemaVersion: 1; id: string; runtime: 'comfygit'; recipe: { path: string; sha256: string } }; recipePath: string; sha256: string };
export function inspectInstallation(config: ResolvedConfig, options?: { command?: string }): Promise<{ workspace: string; modelsDirectory: string; environment: unknown | null; installed: boolean; candidates: string[] }>;
export function appDataRoot(options?: ConfigOptions): string;
export function modelStorageRoot(options?: ConfigOptions & { fallback?: string }): string;

export function ecosystemDataRoot(options?: ConfigOptions): string;
