# Local ecosystem integration

Use `ecosystemPaths(appId)` from `@akatz/app-config/ecosystem` for shared model,
media, cache and tooling paths and isolated app/runtime directories. It honors
existing SDK configuration and explicit environment overrides. Do not derive a
second model root from app data. Resolve paths once per process and preserve the
chosen configuration through an operation.

Use `saveInstallation(value, expected)` only after completing and verifying setup.
The pointer lives in the shared config directory; the runtime and tooling live
under the shared data root. Runtime revisions are app-specific and immutable.
The caller retains old revisions and checks active jobs before any cleanup.

`ensureSharedMedia()` and `ensureSharedExecutor({requiredCapabilities})` from
`@akatz/app-config/local-services` reuse compatible loopback services. On an unused
endpoint they materialize the existing SDK service package at a verified permanent
tooling path and start it. When a systemd user manager is available, each shared
service gets an independent transient unit so app-unit shutdown cannot kill it.
Without a user manager, terminal launches use a detached process. A detached
process survives app exit but cannot survive termination of its entire parent
cgroup; service-hosted deployments need an independent service manager. An app closing does not stop those shared services.
Foreign endpoints, mismatched storage roots, and unknown compatibility fail closed.
Linux process ownership is currently required; Windows/macOS paths do not imply
runtime qualification. No autostart-at-login or automatic service upgrade is added.
Receipts/logs are under `<dataRoot>/services`; inspect ownership and accepted jobs
before operator shutdown. Existing service code is never rewritten in place.

Hugging Face model files use `<modelsRoot>/huggingface/hub`, retaining the upstream
repository/snapshot/blob index. Use an exact repository and commit revision.
Python consumers load `src/shared_hf_cache.py` from this package and hold
`cache_use(cache, repo)` while loading and using the model. Downloads require
`exclusive=True`; reviewed deletion requires `exclusive=True, maintenance=True`.
These nonblocking cross-process leases protect participating apps, not arbitrary
external programs. A busy cache produces `CacheBusy`; preserve the active work.
Never delete `.akatz-locks` as part of model removal. ComfyGit remains responsible
for ComfyUI dependencies and GPU model discovery.

Run `npm ci --ignore-scripts`, `npm run build`, and
`node --test test/ecosystem.test.mjs` in the source archive. Tests start real isolated
media/executor services and stop only their own verified processes.
