/** Native bootstrap protocol. Stdin is metadata; executable paths are package-owned. */
import {readFile} from 'node:fs/promises';
import {dirname,resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {homedir} from 'node:os';
import {planDesktopApp,registerDesktopApp,listDesktopApps} from '@akatz/app-config/desktop-apps';
import {startDesktopApp,stopDesktopApp,readDesktopLog} from '@akatz/app-config/desktop-runtime';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const descriptor=JSON.parse(await readFile(join(root,'akatz-app.json'),'utf8'));
let input='';for await(const chunk of process.stdin){input+=String(chunk);if(input.length>65536)throw Error('Desktop request exceeds its bound');}
try{
  const request=JSON.parse(input),apps=await listDesktopApps(),saved=apps.find(a=>a.appId===descriptor.id);
  let result;
  if(request.action==='inspect')result={appId:descriptor.id,title:descriptor.title,saved:saved||null,
    defaultDataRoot:join(process.env.XDG_DATA_HOME||join(homedir(),'.local/share'),'akatz/apps',descriptor.id)};
  else if(request.action==='plan')result=await planDesktopApp({packageRoot:root,dataRoot:request.dataRoot});
  else if(request.action==='confirm'){
    if(request.plan?.packageRoot!==root||request.plan?.appId!==descriptor.id)throw Error('Registration is for a different packaged app');
    await registerDesktopApp(request.plan,request.digest);
    result=await startDesktopApp(descriptor.id);
  }else if(request.action==='open'){
    if(!saved||saved.packageRoot!==root)throw Error('Review this payload and data folder before opening it');
    result=await startDesktopApp(descriptor.id);
  }else if(request.action==='stop'){
    if(!saved||saved.packageRoot!==root)throw Error('This package does not own the registered application');
    result={stopped:await stopDesktopApp(saved)};
  }else if(request.action==='diagnostics')result={log:await readDesktopLog(descriptor.id,request.attemptId)};
  else throw Error('Unknown desktop action');
  console.log(JSON.stringify({ok:true,result}));
}catch(error){console.log(JSON.stringify({ok:false,error:error.message,...(error.attemptId?{attemptId:error.attemptId}:{})}));process.exitCode=1;}
