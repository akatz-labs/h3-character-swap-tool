import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createServer} from 'node:net';
import {createServer as httpServer} from 'node:http';
import {ecosystemPaths,saveInstallation,readInstallation,huggingFaceSnapshot} from '../dist/ecosystem.js';
import {ensureSharedMedia,ensureSharedExecutor} from '../dist/local-services.js';
import {openAppDatabase} from '../src/storage.mjs';
import {MediaClient} from '../src/media-client.mjs';
import {processAlive} from '../dist/process-identity.js';
const delay=ms=>new Promise(r=>setTimeout(r,ms));
async function free(){const s=createServer();await new Promise(r=>s.listen(0,'127.0.0.1',r));const port=s.address().port;await new Promise(r=>s.close(r));return port;}
async function fixture(t){const home=await mkdtemp(join(tmpdir(),'akatz-ecosystem-')),port=await free();const env={XDG_CONFIG_HOME:join(home,'config'),AKATZ_DATA_ROOT:join(home,'data'),AKATZ_MEDIA_URL:'http://127.0.0.1:'+port};
 t.after(async()=>{for(const kind of ['media','executor']){try{const r=JSON.parse(await readFile(join(home,'data/services',kind+'.json'),'utf8'));if(r.process&&processAlive(r.process)){process.kill(r.process.pid,'SIGTERM');for(let i=0;i<100&&processAlive(r.process);i++)await delay(30);assert(!processAlive(r.process),'test-owned service stopped');}}catch(e){if(e.code!=='ENOENT')throw e;}}await rm(home,{recursive:true,force:true});});return {home,env};}

test('one configured namespace supplies models/media while app data remains separate',async t=>{
 const {home,env}=await fixture(t),a=await ecosystemPaths('alpha',{home,env}),b=await ecosystemPaths('beta',{home,env});
 assert.equal(a.modelsRoot,join(home,'data/models'));assert.equal(a.modelsRoot,b.modelsRoot);assert.equal(a.huggingFaceCache,b.huggingFaceCache);assert.equal(a.mediaRoot,b.mediaRoot);assert.notEqual(a.appRoot,b.appRoot);
 const first=openAppDatabase({appId:'alpha',env}),second=openAppDatabase({appId:'beta',env});try{assert.notEqual(first.identity.instanceId,second.identity.instanceId);assert.notEqual(first.paths.database,second.paths.database);}finally{first.close();second.close();}
 await mkdir(join(home,'config/akatz'),{recursive:true});await writeFile(join(home,'config/akatz/models.json'),JSON.stringify({schemaVersion:1,root:join(home,'existing-models')}));assert.equal((await ecosystemPaths('gamma',{home,env})).modelsRoot,join(home,'existing-models'));
 assert.equal((await ecosystemPaths('gamma',{home,env:{...env,AKATZ_MODELS_ROOT:join(home,'explicit-models')}})).modelsRoot,join(home,'explicit-models'));
 const path=huggingFaceSnapshot(a.huggingFaceCache,'Org/model','a'.repeat(40));assert.equal(path,join(a.modelsRoot,'huggingface/hub/models--Org--model/snapshots','a'.repeat(40)));assert.throws(()=>huggingFaceSnapshot(a.huggingFaceCache,'../escape','a'.repeat(40)));
});

test('platform path policy and storage.json overrides are shared by the model resolver',async t=>{
 const {home,env}=await fixture(t);
 assert.equal((await ecosystemPaths('alpha',{home,env:{},platform:'linux'})).dataRoot,join(home,'.local/share/akatz'));
 assert.equal((await ecosystemPaths('alpha',{home,env:{},platform:'darwin'})).dataRoot,join(home,'Library/Application Support/akatz'));
 assert.equal((await ecosystemPaths('alpha',{home,env:{},platform:'win32'})).dataRoot,join(home,'AppData/Local/akatz'));
 await mkdir(join(home,'config/akatz'),{recursive:true});await writeFile(join(home,'config/akatz/storage.json'),JSON.stringify({schemaVersion:1,root:join(home,'selected-drive')}));
 const selected=await ecosystemPaths('alpha',{home,env:{XDG_CONFIG_HOME:env.XDG_CONFIG_HOME}});assert.equal(selected.modelsRoot,join(home,'selected-drive/models'));assert.equal(selected.mediaRoot,join(home,'selected-drive/media'));
});

test('successful installation pointers preserve explicit roots and reject concurrent selection changes',async t=>{
 const {home,env}=await fixture(t),options={home,env};assert.equal(await readInstallation('alpha',options),null);
 const first={schemaVersion:1,appId:'alpha',root:join(home,'existing-runtime'),modelsRoot:join(home,'existing-models'),revision:'a'.repeat(64),executorPort:8841};
 await saveInstallation(first,null,options);assert.deepEqual(await readInstallation('alpha',options),first);
 await assert.rejects(saveInstallation({...first,revision:'b'.repeat(64)},null,options),/changed/);assert.deepEqual(await readInstallation('alpha',options),first);
});

test('concurrent apps discover one persistent media service and the same catalog',async t=>{
 const {home,env}=await fixture(t),options={home,env};const services=await Promise.all(Array.from({length:3},()=>ensureSharedMedia(options)));
 assert.equal(new Set(services.map(s=>s.id)).size,1);assert.equal(services.filter(s=>!s.reused).length,1);
 const receipt=JSON.parse(await readFile(join(home,'data/services/media.json'),'utf8'));
 if(receipt.unit){assert.match(await readFile('/proc/'+receipt.process.pid+'/cgroup','utf8'),new RegExp(receipt.unit.replaceAll('.','\\.')));assert(!(await readFile('/proc/self/cgroup','utf8')).includes(receipt.unit));}
 const a=new MediaClient(services[0].url),b=new MediaClient(services[1].url);
 for(const id of ['alpha','beta']){await a.registerApp({appId:id,instanceId:id+'-instance',name:id,dataRoot:join(home,'data/apps',id)});await a.registerProject({appId:id,instanceId:id+'-instance',projectId:id+'-project',name:id});}
 const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j5mQAAAAASUVORK5CYII=','base64');
 const item=await a.import(png,{appId:'alpha',instanceId:'alpha-instance',projectId:'alpha-project',sourceKey:'image',name:'Shared image'});
 await b.link(item.id,{appId:'beta',instanceId:'beta-instance',projectId:'beta-project'});
 assert.equal((await b.get(item.id)).hash,item.hash);assert.equal((await b.get(item.id)).links.length,2);assert.equal((await b.apps()).items.length,2);
 assert.equal((await ensureSharedMedia(options)).id,services[0].id);
});

test('shared executor is reused without replacing its durable identity',async t=>{
 const {home,env}=await fixture(t),port=await free(),options={home,env,port};const first=await ensureSharedExecutor(options),second=await ensureSharedExecutor(options);
 assert.equal(first.id,second.id);assert.equal(second.reused,true);assert.equal(first.root,join(home,'data/apps/executor'));
 await assert.rejects(ensureSharedExecutor({...options,requiredCapabilities:['not-implemented']}),/incompatible/);
 assert.equal((await ensureSharedExecutor(options)).id,first.id);
});

test('an occupied foreign endpoint is preserved and never treated as a missing service',async t=>{
 const {home,env}=await fixture(t),port=await free(),server=httpServer((_req,res)=>{res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify({ok:true,apiVersion:99}));});
 await new Promise(r=>server.listen(port,'127.0.0.1',r));t.after(()=>new Promise(r=>server.close(r)));
 await assert.rejects(ensureSharedMedia({home,env:{...env,AKATZ_MEDIA_URL:'http://127.0.0.1:'+port}}),/incompatible/);
 assert(server.listening);
});

test('a stopped shared service restarts with the same catalog identity and rejects another root',async t=>{
 const {home,env}=await fixture(t),options={home,env};
 const first=await ensureSharedMedia(options);
 await assert.rejects(ensureSharedMedia({home,env:{...env,AKATZ_MEDIA_ROOT:join(home,'other-media')}}),/different storage root/);
 assert(first.process&&processAlive(first.process));process.kill(first.process.pid,'SIGTERM');
 for(let i=0;i<100&&processAlive(first.process);i++)await delay(30);
 assert(!processAlive(first.process));
 const restarted=await ensureSharedMedia(options);assert.equal(restarted.id,first.id);assert.equal(restarted.reused,false);
});
