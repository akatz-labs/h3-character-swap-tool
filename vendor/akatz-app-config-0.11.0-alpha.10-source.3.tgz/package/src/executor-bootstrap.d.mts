import type {ExecutorTarget} from './executor-client.mjs';
export interface BootstrapPlan {target:ExecutorTarget;port:number;bundleDigest:string;requiredCapabilities:string[];files:Array<{name:string;body:string}>;description:string;writes:string[];downloads:unknown[];requires:string[];digest:string}
export function bootstrapPlan(target?:ExecutorTarget,options?:{requiredCapabilities?:string[];update?:boolean}):Promise<BootstrapPlan>;
export function bootstrapExecutor(plan:BootstrapPlan,confirmation:string):Promise<{reused:boolean;apiVersion:number;executorId:string;supervision?:string}>;
export function ensureLocalExecutor(target?:ExecutorTarget,options?:{requiredCapabilities?:string[];update?:boolean}):Promise<unknown>;
