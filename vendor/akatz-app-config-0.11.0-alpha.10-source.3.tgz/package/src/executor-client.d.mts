export type ExecutorPhase = 'queued' | 'preparing' | 'rendering' | 'finalizing' | 'completed' | 'failed' | 'cancelled' | 'uncertain';
export interface ExecutorTarget { id?: string; name?: string; kind:'local'|'ssh'; host?:string; port?:number; sshPort?:number }
export interface ExecutorFile { name:string; hash:string; size:number; mime?:string }
export interface ExecutorInstallation { id:string; appId:string; revision:string; adapter:string; features:string[]; environment?:Record<string,string>; configuration?:Record<string,unknown>; probes:Array<{kind:'file'|'http'|'command'|'directory';features?:string[];expectedSize?:number;modelHash?:string;pythonExecutable?:string;command?:string;args?:string[];environment?:Record<string,string>;path?:string;url?:string;name?:string;minimumBytes?:number;sha256?:string;contains?:string}>; runtime?:{comfyUrls:string[];managed?:import('../dist/runtime-sessions.js').ManagedRuntimeDescriptor};setup?:Record<string,unknown> }
export interface ReadinessIssue { code:string; retryable:boolean; message:string; features:string[]; retryAfterMs?:number; requestId?:string; owner?:{pid:number|null;operation:string|null;acquiredAt:string|null} }
export interface InstallationReadiness { installation:ExecutorInstallation; ready:boolean; features:string[]; problems:string[]; issues?:ReadinessIssue[]; checkedAt:string }
export interface ExecutorRegistry { defaultExecutorId:string; selectedExecutorId:string; selectionSource?:'app'|'default'; items:Array<ExecutorTarget & {id:string; name:string; online:boolean; executorId?:string; installations:InstallationReadiness[];error?:string}> }
export interface ExecutorSubmission { appId:string; instanceId:string; sourceJobId:string; installationId:string; executorId?:string; feature:string; inputs:unknown; files:ExecutorFile[] }
export interface ExecutorJob extends ExecutorSubmission {id:string;executorId:string;phase:ExecutorPhase;createdAt:string;updatedAt:string;error?:string;activity?:string;diagnostics?:{files:ExecutorFile[];evidence:unknown};readinessIssues?:ReadinessIssue[];readinessWait?:{firstObservedAt:string;deadlineAt:string;nextAttemptAt:string;attempts:number;lastIssues:ReadinessIssue[];resolvedAt?:string};result?:{files:ExecutorFile[];[key:string]:unknown};installation:ExecutorInstallation}
export function executorOrigin(target:ExecutorTarget):Promise<string>;
export function runtimeOrigin(target:ExecutorTarget,runtimeUrl:string):Promise<string>;
export function closeExecutorConnections():Promise<void>;
export class ExecutorClient {
  constructor(target?:ExecutorTarget);
  target:ExecutorTarget;
  request(path:string,init?:RequestInit & {duplex?:'half'}):Promise<Response>;
  json<T=unknown>(path:string,body?:unknown,method?:string):Promise<T>;
  health():Promise<{apiVersion:number;executorId:string;phase:string;capabilities?:string[]}>;
  memory():Promise<ExecutorMemoryStatus>;
  configureMemory(input:{executorId:string;idleTimeoutSeconds:number|null}):Promise<ExecutorMemoryStatus>;
  releaseMemory(executorId:string):Promise<ExecutorMemoryStatus>;
  registry(appId:string):Promise<ExecutorRegistry>;
  readiness(appId:string):Promise<InstallationReadiness[]>;
  submit(input:ExecutorSubmission):Promise<ExecutorJob>;
  cancelAdmission(input:ExecutorSubmission):Promise<ExecutorJob>;
  cancel(id:string):Promise<ExecutorJob>;
  reconcile(id:string,executorId:string):Promise<ExecutorJob>;
  job(id:string):Promise<ExecutorJob>;
  recoveryPlan(id:string,input:{adapterRevision:string;executorId:string}):Promise<ExecutorRecoveryPlan>;
  recover(id:string,input:{planId:string;digest:string;executorId:string}):Promise<ExecutorJob>;
  upload(source:string,name:string,options?:{signal?:AbortSignal}):Promise<ExecutorFile>;
  download(jobId:string,file:ExecutorFile,destination:string,options?:{signal?:AbortSignal}):Promise<string>;
  wait(id:string,options?:{onPhase?:(job:ExecutorJob)=>void|Promise<void>;signal?:AbortSignal;interval?:number}):Promise<ExecutorJob>;
}

export interface ExecutorRecoveryPlan {kind:'job-recovery';id:string;jobId:string;executorId:string;appId:string;adapterRevision:string;fingerprint:string;action:'retry-not-submitted';description:string;expiresAt:string;digest:string;evidence:{safeToRetry:true;submission:'not-submitted';reason:string;[key:string]:unknown}}

/** Opt-in only. Older adapters retain queued-only cancellation. */
export interface ExecutorInstallation { capabilities?: Array<'cooperative-cancel-v1'|'managed-runtime-v1'|'accepted-attempt-v1'|'staged-resources-v1'> }

export interface ExecutorMemoryStatus {
  executorId:string;
  idleTimeoutSeconds:number|null;
  state:'waiting'|'disabled'|'warm'|'releasing'|'requested'|'error';
  reason:string;
  idleSince:string|null;
  releaseAt:string|null;
  lastRelease:{requestedAt:string;runtimes:string[];outcome:'requested'|'incomplete'}|null;
}
