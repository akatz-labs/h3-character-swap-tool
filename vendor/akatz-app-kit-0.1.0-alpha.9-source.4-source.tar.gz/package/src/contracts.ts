import { z } from 'zod';

export const workerSchema = z.object({
  id: z.string().min(1),
  name: z.string(),
  online: z.boolean(),
  ready: z.boolean(),
  setupRequired: z.boolean(),
  kind: z.string(),
});
export const registrySchema = z.object({
  selectedExecutorId: z.string().nullable(),
  defaultExecutorId: z.string().nullable(),
  executors: z.array(workerSchema),
});
export const resourceJobSchema = z.object({
  id: z.string(),
  kind: z.string(),
  status: z.enum(['queued', 'running', 'succeeded', 'failed', 'cancelled']),
  message: z.string(),
  progress: z.number().min(0).max(1).nullable(),
  error: z.string().nullable(),
  storagePath: z.string().optional(),
  stage: z.string().optional(),
  completedBytes: z.number().nonnegative(),
  totalBytes: z.number().nonnegative().nullable(),
});
export const inventorySchema = z.object({
  capabilities: z.array(z.string()).optional(),
  runtimeState: z
    .enum(['unknown', 'missing', 'stopped', 'starting', 'ready', 'needs-repair'])
    .optional(),
  runtimeActions: z.array(z.enum(['install', 'start', 'repair'])).optional(),
  settings: z.record(z.string(), z.string()).optional(),
  refreshing: z.boolean().optional(),
  storage: z.object({
    path: z.string(),
    freeBytes: z.number().nullable(),
    totalBytes: z.number().nullable(),
    managedBytes: z.number(),
  }),
  summary: z.object({
    ready: z.boolean(),
    requiredInstalled: z.number(),
    requiredTotal: z.number(),
  }),
  models: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      requirement: z.enum(['required', 'optional']),
      state: z.enum(['installed', 'missing', 'changed', 'unindexed']),
      sizeBytes: z.number(),
      relativePath: z.string().optional(),
      removable: z.boolean().optional(),
      locationLabel: z.string().optional(),
      acquisition: z.enum(['manual','download']).optional(),
      sourceNote: z.string().optional(),
    }),
  ),
  features: z.array(
    z.object({ id: z.string(), label: z.string(), ready: z.boolean(), optional: z.boolean() }),
  ),
  runtimes: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      installed: z.boolean(),
      detail: z.string().optional(),
      version: z.string().nullable().optional(),
    }),
  ),
  issues: z.array(z.string()),
});
export const snapshotSchema = z.object({
  executorId: z.string(),
  executorName: z.string(),
  inventory: inventorySchema,
  jobs: z.array(resourceJobSchema),
});
export const progressSchema = z.object({
  executorId: z.string(),
  jobs: z.array(resourceJobSchema),
});
export const reviewSchema = z.object({
  reviewRequired: z.literal(true),
  removal: z.object({resourceId:z.string(),name:z.string(),path:z.string(),sizeBytes:z.number(),reclaimBytes:z.number(),usedByApps:z.array(z.string()),environments:z.array(z.string()),blockers:z.array(z.string()),canUninstall:z.boolean()}).optional(),
  runtimeAction: z.enum(['start', 'repair', 'install']).optional(),
  executorId: z.string(),
  executorName: z.string(),
  resourceIds: z.array(z.string()),
  plan: z.object({
    id: z.string(),
    digest: z.string(),
    description: z.string().optional(),
    writes: z.array(z.string()),
    downloads: z.array(z.object({ name: z.string(), bytes: z.number().nullable().optional() })),
  }),
});
export const resourceResultSchema = z.union([
  reviewSchema,
  resourceJobSchema,
  z.object({ complete: z.literal(true) }),
]);
export type Worker = z.infer<typeof workerSchema>;
export type Registry = z.infer<typeof registrySchema>;
export type ResourceSnapshot = z.infer<typeof snapshotSchema>;
export type ResourceJob = z.infer<typeof resourceJobSchema>;
export type ResourceReview = z.infer<typeof reviewSchema>;
export type ResourceResult = z.infer<typeof resourceResultSchema>;
export type ResourceAction =
  | { kind: 'storage'; path: string }
  | { kind: 'scan' | 'setup-required' | 'setup-runtime' | 'runtime-start' | 'runtime-repair' }
  | { kind: 'settings'; settings: Record<string, string> }
  | { kind: 'download'; resourceIds: string[] }
  | { kind: 'uninstall-plan'; resourceId: string }
  | { kind: 'uninstall-confirm'; review: ResourceReview }
  | { kind: 'setup-confirm'; review: ResourceReview };
export interface ResourceAdapter {
  registry(signal: AbortSignal): Promise<Registry>;
  snapshot(workerId: string, signal: AbortSignal): Promise<ResourceSnapshot>;
  jobs(workerId: string, signal: AbortSignal): Promise<z.infer<typeof progressSchema>>;
  action(workerId: string, action: ResourceAction, attemptId?: string): Promise<ResourceResult>;
  reconcile?(attemptId: string, workerId: string): Promise<ResourceResult | null>;
  unresolved?(workerId: string, signal: AbortSignal): Promise<string | null>;
}
