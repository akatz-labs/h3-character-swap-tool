import { RequestFailure } from './http.js';
import type { FenceStore } from './fences.js';

/** One app-owned mutation channel. Persist before dispatch; never replay unknown acceptance. */
export class MutationGate {
  private pending = false;
  private uncertain = false;
  constructor(
    private readonly fences: FenceStore,
    private readonly key: string,
  ) {}
  isBlocked() {
    return this.pending || this.uncertain || this.fences.has(this.key);
  }
  async run<T>(dispatch: () => Promise<T>): Promise<T> {
    if (this.isBlocked())
      throw new RequestFailure(
        'A previous request is pending or needs reconciliation. No request was sent.',
        false,
      );
    // Storage failure is before dispatch. Do not execute if a crash-safe fence cannot be saved.
    this.fences.add(this.key);
    this.pending = true;
    try {
      const result = await dispatch();
      this.fences.delete(this.key);
      return result;
    } catch (error) {
      if (error instanceof RequestFailure && !error.uncertain) this.fences.delete(this.key);
      else this.uncertain = true;
      throw error;
    } finally {
      this.pending = false;
    }
  }
}
