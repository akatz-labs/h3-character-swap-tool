import {
  useEffect,
  useId,
  useRef,
  useState,
  type KeyboardEvent,
  type ReactNode,
  type RefObject,
} from 'react';
import { RefreshCw } from 'lucide-react';

export type IconName =
  | 'grid'
  | 'sparkles'
  | 'library'
  | 'boxes'
  | 'download'
  | 'upload'
  | 'settings'
  | 'folder'
  | 'search'
  | 'plus'
  | 'pencil'
  | 'alert'
  | 'play'
  | 'refresh'
  | 'reuse'
  | 'image'
  | 'film'
  | 'music'
  | 'heart'
  | 'more'
  | 'trash'
  | 'chevron-down'
  | 'close';

/** Small framework-owned icon vocabulary; apps may supply their own branding. */
export function Icon({ name }: { name: IconName }) {
  if (name === 'refresh') {
    return <RefreshCw className="ak-icon" size={24} strokeWidth={1.7} aria-hidden="true" focusable="false" />;
  }
  const paths: Record<Exclude<IconName, 'refresh'>, ReactNode> = {
    grid: <path d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z" />,
    sparkles: <path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5zM20 2v4M18 4h4" />,
    library: <path d="M3 4h4v16H3zM10 4h4v16h-4zM17 5l4-1 3 15-4 1z" />,
    boxes: (
      <path d="m12 2 7 4-7 4-7-4zM5 6v8l7 4 7-4V6M12 10v8M5 10l-4 3 7 4 4-3M1 13v6l7 4 4-3M19 10l4 3-7 4-4-3M23 13v6l-7 4-4-3" />
    ),
    download: <path d="M12 3v12m-5-5 5 5 5-5M4 15v5h16v-5" />,
    upload: <path d="M12 16V4m-5 5 5-5 5 5M5 14v5h14v-5" />,
    settings: (
      <>
        <path d="M9.5 2h5l.6 3 1.7 1 2.9-.9 2.5 4.3-2.3 2.1v1l2.3 2.1-2.5 4.3-2.9-.9-1.7 1-.6 3h-5l-.6-3-1.7-1-2.9.9-2.5-4.3 2.3-2.1v-1L1.8 9.4l2.5-4.3 2.9.9 1.7-1z" />
        <circle cx="12" cy="12" r="3" />
      </>
    ),
    folder: <path d="M3 6a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v10H3z" />,
    search: (
      <>
        <circle cx="10.5" cy="10.5" r="7" />
        <path d="m16 16 5 5" />
      </>
    ),
    plus: <path d="M12 5v14M5 12h14" />,
    pencil: <path d="m15 4 5 5M3 21l5-1L21 7a2 2 0 0 0-5-5L3 15z" />,
    close: <path d="m6 6 12 12M6 18 18 6" />,
    alert: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v6m0 3h.01" />
      </>
    ),
    play: <path d="m8 4 12 8-12 8z" />,
    reuse: <path d="m2 9 3-3 3 3M5 6h11a4 4 0 0 1 4 4v1m2 4-3 3-3-3m3 3H8a4 4 0 0 1-4-4v-1" />,
    image: (
      <>
        <rect x="3" y="4" width="18" height="16" rx="2" />
        <circle cx="8.5" cy="9" r="1.5" />
        <path d="m21 15-5-5L5 20" />
      </>
    ),
    film: <path d="M3 5h18v14H3zM7 5v14M17 5v14M3 9h4m10 0h4M3 15h4m10 0h4" />,
    music: (
      <path d="M9 18V5l10-2v13M9 9l10-2M6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm10-2a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
    ),
    heart: (
      <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />
    ),
    more: (
      <>
        <circle cx="5" cy="12" r="1" fill="currentColor" stroke="none" />
        <circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" />
        <circle cx="19" cy="12" r="1" fill="currentColor" stroke="none" />
      </>
    ),
    trash: <path d="M3 6h18M8 6V3h8v3m3 0-1 15H6L5 6m5 4v7m4-7v7" />,
    'chevron-down': <path d="m7 10 5 5 5-5" />,
  };
  return (
    <svg
      className="ak-icon"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  );
}

export interface SelectMenuOption {
  value: string;
  label: string;
  disabled?: boolean;
}

/** Themeable single-value select with native-like keyboard behavior. */
export function SelectMenu({
  label,
  value,
  placeholder,
  options,
  onChange,
  displayValue,
  title,
  className = '',
  disabled = false,
}: {
  label: string;
  value: string;
  placeholder: string;
  options: readonly SelectMenuOption[];
  onChange: (value: string) => void;
  displayValue?: string;
  title?: string;
  className?: string;
  disabled?: boolean;
}) {
  const listboxId = useId();
  const root = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const listbox = useRef<HTMLDivElement>(null);
  const optionRefs = useRef<(HTMLDivElement | null)[]>([]);
  const typeahead = useRef('');
  const typeaheadTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const selectedIndex = options.findIndex((option) => option.value === value);
  const firstEnabled = options.findIndex((option) => !option.disabled);
  let lastEnabled = -1;
  for (let index = options.length - 1; index >= 0; index--) {
    if (!options[index]?.disabled) {
      lastEnabled = index;
      break;
    }
  }
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(selectedIndex >= 0 ? selectedIndex : firstEnabled);
  const selected = selectedIndex >= 0 ? options[selectedIndex] : undefined;
  const visibleValue = displayValue ?? selected?.label ?? placeholder;

  useEffect(() => {
    if (!open) return;
    setActiveIndex(selectedIndex >= 0 ? selectedIndex : firstEnabled);
    requestAnimationFrame(() => listbox.current?.focus());
    const closeOutside = (event: PointerEvent) => {
      if (!root.current?.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener('pointerdown', closeOutside);
    return () => document.removeEventListener('pointerdown', closeOutside);
  }, [firstEnabled, open, selectedIndex]);

  useEffect(() => {
    if (disabled) setOpen(false);
  }, [disabled]);

  useEffect(() => {
    if (!open || activeIndex < 0) return;
    optionRefs.current[activeIndex]?.scrollIntoView({ block: 'nearest' });
  }, [activeIndex, open]);

  useEffect(
    () => () => {
      if (typeaheadTimer.current) clearTimeout(typeaheadTimer.current);
    },
    [],
  );

  const close = (restoreFocus = true) => {
    // Restore focus before unmounting the listbox. Deferring this to the next
    // frame can steal focus from a skip link or another control the user has
    // already reached in the meantime.
    if (restoreFocus) trigger.current?.focus();
    setOpen(false);
  };
  const choose = (index: number) => {
    const option = options[index];
    if (!option || option.disabled) return;
    onChange(option.value);
    close();
  };
  const move = (direction: 1 | -1) => {
    if (!options.length) return;
    let index = activeIndex;
    for (let count = 0; count < options.length; count++) {
      index = (index + direction + options.length) % options.length;
      if (!options[index]?.disabled) {
        setActiveIndex(index);
        return;
      }
    }
  };
  const edge = (direction: 1 | -1) => {
    const indices = direction === 1 ? options.keys() : [...options.keys()].reverse();
    for (const index of indices) {
      if (!options[index]?.disabled) {
        setActiveIndex(index);
        return;
      }
    }
  };
  const search = (key: string) => {
    typeahead.current += key.toLocaleLowerCase();
    if (typeaheadTimer.current) clearTimeout(typeaheadTimer.current);
    typeaheadTimer.current = setTimeout(() => {
      typeahead.current = '';
    }, 500);
    for (let offset = 1; offset <= options.length; offset++) {
      const index = (Math.max(activeIndex, -1) + offset) % options.length;
      const option = options[index];
      if (
        option &&
        !option.disabled &&
        option.label.toLocaleLowerCase().startsWith(typeahead.current)
      ) {
        setActiveIndex(index);
        return;
      }
    }
  };
  const handleListKey = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      move(event.key === 'ArrowDown' ? 1 : -1);
    } else if (event.key === 'Home' || event.key === 'End') {
      event.preventDefault();
      edge(event.key === 'Home' ? 1 : -1);
    } else if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      choose(activeIndex);
    } else if (event.key === 'Escape') {
      event.preventDefault();
      close();
    } else if (event.key === 'Tab') {
      close(false);
    } else if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) {
      search(event.key);
    }
  };

  return (
    <div className={`ak-select-menu ${className}`.trim()} ref={root} data-value={value}>
      <button
        ref={trigger}
        type="button"
        className="ak-select-trigger"
        disabled={disabled}
        aria-label={`${label}: ${selected?.label ?? placeholder}`}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={open ? listboxId : undefined}
        onClick={() => setOpen((current) => !current)}
        onKeyDown={(event) => {
          if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
            event.preventDefault();
            setOpen(true);
            setActiveIndex(
              selectedIndex >= 0
                ? selectedIndex
                : event.key === 'ArrowDown'
                  ? firstEnabled
                  : lastEnabled,
            );
          }
        }}
      >
        <span className="ak-select-value" data-truncated={title ? 'true' : undefined} title={title}>
          {visibleValue}
        </span>
        <Icon name="chevron-down" />
      </button>
      {open && (
        <div
          ref={listbox}
          id={listboxId}
          className="ak-select-listbox"
          role="listbox"
          aria-label={label}
          tabIndex={-1}
          aria-activedescendant={activeIndex >= 0 ? `${listboxId}-${activeIndex}` : undefined}
          onKeyDown={handleListKey}
        >
          {options.map((option, index) => (
            <div
              ref={(element) => {
                optionRefs.current[index] = element;
              }}
              id={`${listboxId}-${index}`}
              key={option.value}
              className="ak-select-option"
              role="option"
              aria-selected={option.value === value}
              aria-disabled={option.disabled || undefined}
              data-active={index === activeIndex || undefined}
              title={option.label}
              onMouseMove={() => {
                if (!option.disabled) setActiveIndex(index);
              }}
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => choose(index)}
            >
              {option.label}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/** Native modal semantics provide focus containment and an inert background. */
export function Dialog({
  title,
  description,
  busy = false,
  onClose,
  children,
  initialFocus,
  variant = 'standard',
}: {
  title: string;
  description?: string;
  busy?: boolean;
  onClose: () => void;
  children: ReactNode;
  initialFocus?: RefObject<HTMLElement | null>;
  variant?: 'standard' | 'media' | 'library';
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const backdropPointer = useRef<number | null>(null);
  const titleId = useId(),
    descriptionId = useId();
  useEffect(() => {
    const dialog = ref.current!;
    const previous = document.activeElement;
    dialog.showModal();
    initialFocus?.current?.focus();
    return () => {
      dialog.close();
      if (previous instanceof HTMLElement && previous.isConnected) previous.focus();
    };
  }, [initialFocus]);
  return (
    <dialog
      ref={ref}
      className={`ak-dialog${variant === 'media' ? ' ak-dialog-media' : variant === 'library' ? ' ak-dialog-library' : ''}`}
      aria-labelledby={titleId}
      tabIndex={-1}
      aria-describedby={description ? descriptionId : undefined}
      aria-busy={busy}
      onPointerDown={(event) => {
        const bounds = event.currentTarget.getBoundingClientRect();
        const outside =
          event.clientX < bounds.left ||
          event.clientX > bounds.right ||
          event.clientY < bounds.top ||
          event.clientY > bounds.bottom;
        backdropPointer.current = outside ? event.pointerId : null;
      }}
      onPointerUp={(event) => {
        const bounds = event.currentTarget.getBoundingClientRect();
        const outside =
          event.clientX < bounds.left ||
          event.clientX > bounds.right ||
          event.clientY < bounds.top ||
          event.clientY > bounds.bottom;
        const dismiss = backdropPointer.current === event.pointerId && outside;
        backdropPointer.current = null;
        if (dismiss && !busy) onClose();
      }}
      onPointerCancel={() => {
        backdropPointer.current = null;
      }}
      onKeyDown={(event) => {
        if (event.key !== 'Tab') return;
        const focusable = Array.from(
          event.currentTarget.querySelectorAll<HTMLElement>(
            'button, input, select, textarea, a[href], video[controls], audio[controls], summary, [tabindex]',
          ),
        ).filter(
          (element) =>
            element.tabIndex >= 0 &&
            !element.matches(':disabled') &&
            element.getClientRects().length > 0,
        );
        const first = focusable[0],
          last = focusable.at(-1);
        if (!first || !last) {
          event.preventDefault();
          event.currentTarget.focus();
        } else if (
          event.shiftKey &&
          (document.activeElement === first || document.activeElement === event.currentTarget)
        ) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }}
      onCancel={(event) => {
        event.preventDefault();
        if (!busy) onClose();
      }}
    >
      <div className={variant === 'media' ? 'ak-dialog-media-heading' : 'ak-heading'}>
        <h2 id={titleId}>{title}</h2>
        <button
          type="button"
          className="ak-icon-button"
          aria-label="Close dialog"
          disabled={busy}
          onClick={onClose}
        >
          <Icon name="close" />
        </button>
      </div>
      {description && (
        <p className="ak-muted" id={descriptionId}>
          {description}
        </p>
      )}
      {children}
    </dialog>
  );
}
