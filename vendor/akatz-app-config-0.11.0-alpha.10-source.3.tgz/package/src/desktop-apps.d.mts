import type { AppExecutors } from "./app-executors.mjs";
export interface GenerationPackage {
  schemaVersion: 1;
  appId: string;
  title: string;
  version?: string;
  features: Array<{ id: string; label: string }>;
  settingsFields: Array<{ key: string; label: string; placeholder?: string }>;
  packageRoot: string;
  modulePath: string;
  setupDigest: string;
  module: { path: string; sha256: string };
}
export interface DesktopApp {
  schemaVersion: 1;
  appId: string;
  title: string;
  packageRoot: string;
  url: string;
  version: string | null;
  registeredAt: string;
  launchDigest?: string | null;
  launchSettings?: { dataRoot?: string };
  available: boolean;
  problem?: string;
}
export function desktopRegistryRoot(): string;
export function readGenerationPackage(root: string): Promise<GenerationPackage>;
export function generationManager(
  root: string,
  options?: Record<string, unknown>,
): Promise<{ setup: GenerationPackage; manager: AppExecutors }>;
export function desktopUrl(value: string): string;
export function planDesktopApp(input: {
  packageRoot: string;
  url?: string;
  dataRoot?: string;
}): Promise<Record<string, unknown>>;
export function registerDesktopApp(
  plan: Record<string, unknown>,
  confirmation: string,
): Promise<DesktopApp>;
export function listDesktopApps(): Promise<DesktopApp[]>;
