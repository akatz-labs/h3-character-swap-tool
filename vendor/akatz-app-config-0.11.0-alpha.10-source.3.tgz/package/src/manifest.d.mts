export interface FileReference { path: string; sha256: string }
export interface Component { kind: 'comfygit' | 'python' | 'native'; label?: string; platforms: string[]; dependsOn?: string[]; recipe?: FileReference; python?: string; requirements?: FileReference; source?: { url: string; revision: string }; imports?: string[]; entrypoints?: Record<string, FileReference>; environment?: Record<string,string>; modelSnapshots?: FileReference; executable?: string; versionPrefix?: string; versionArgs?: string[]; bundled?: FileReference; extraIndexUrl?: string }
export interface AppManifest { schemaVersion: 2; id: string; title?: string; components: Record<string,Component>; features: Record<string,{label?: string; requires: string[]}>; validation?: unknown }
export interface LoadedManifest { descriptor: AppManifest; root: string; path: string; order: string[]; sha256: string }
export function digest(value: string | Buffer): string;
export function portablePath(root: string, path: string): string;
export function verifyFile(root: string, ref: FileReference): string;
export function readAppManifest(path: string): LoadedManifest;
