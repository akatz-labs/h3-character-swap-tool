import { readFile } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import { posix, win32 } from 'node:path';
import { z } from 'zod';
import { snapshotSchema, reviewSchema } from './contracts.js';

export interface WorkerClient {
  json<T = unknown>(path: string, body?: unknown): Promise<T>;
}
const installationSchema = z.object({
  id: z.string(),
  appId: z.string(),
  revision: z.string(),
  adapter: z.string(),
  configuration: z.record(z.string(), z.unknown()).optional(),
  probes: z.array(z.record(z.string(), z.unknown())),
  features: z.array(z.string()),
  capabilities: z.array(z.string()).optional(),
  runtime: z.record(z.string(), z.unknown()).optional(),
  environment: z.record(z.string(), z.string()).optional(),
});
const readinessSchema = z.array(
  z.object({
    installation: installationSchema,
    ready: z.boolean(),
    setupJobId: z.string().optional(),
  }),
);
const runtimeDetails = z.object({
  runtime: z.object({
    environment: z.string().nullable().optional(),
    workspace: z.string().nullable().optional(),
  }),
  settings: z.record(z.string(), z.string()),
});
export async function managedRuntime(client: WorkerClient, appId: string, source: unknown) {
  const snapshot = snapshotSchema.parse(source);
  const details = z.object({ inventory: runtimeDetails }).parse(source).inventory;
  const readiness = readinessSchema.parse(
    await client.json('/v1/installations?appId=' + encodeURIComponent(appId)),
  );
  const workspace = details.settings.workspace || details.runtime.workspace;
  const environment = details.runtime.environment;
  const saved = readiness.find(
    (item) =>
      !item.setupJobId &&
      item.installation.appId === appId &&
      item.installation.configuration?.workspace === workspace &&
      item.installation.configuration?.environment === environment,
  )?.installation;
  const cg = details.settings.cgExecutable || saved?.configuration?.cgExecutable;
  const python = details.settings.pythonExecutable || saved?.configuration?.pythonExecutable;
  const canStart = Boolean(
    saved &&
      workspace &&
      environment &&
      typeof cg === 'string' &&
      cg &&
      typeof python === 'string' &&
      python &&
      (!details.settings.comfyUrl || details.settings.comfyUrl === saved.configuration?.comfyUrl) &&
      (!details.settings.serveUrl || details.settings.serveUrl === saved.configuration?.serveUrl),
  );
  const components = snapshot.inventory.runtimes;
  const runtimeState = snapshot.jobs.some(
    (job) => job.kind === 'runtime' && ['queued', 'running'].includes(job.status),
  )
    ? 'starting'
    : components.length > 0 && components.every((item) => item.installed)
      ? 'ready'
      : environment && components.some((item) => item.id === 'comfyui' && !item.installed)
        ? 'stopped'
        : !environment && components.every((item) => !item.installed)
          ? 'missing'
          : 'needs-repair';
  return {
    snapshot: snapshotSchema.parse({
      ...snapshot,
      inventory: {
        ...snapshot.inventory,
        runtimeState,
        runtimeActions:
          runtimeState === 'stopped'
            ? canStart
              ? ['start']
              : []
            : runtimeState === 'missing'
              ? ['install']
              : runtimeState === 'needs-repair'
                ? ['repair']
                : [],
      },
    }),
    saved,
    workspace,
    environment,
    cg,
    python,
    canStart,
  };
}

/** Splat Smith's start-only plan structure, without any product-specific recipe or adapter. */
export async function startRuntimePlan(client: WorkerClient, appId: string, source: unknown) {
  const current = await managedRuntime(client, appId, source);
  if (!current.canStart || !current.saved)
    throw new Error(
      'No matching saved runtime and executables. Review Advanced worker setup; existing services were preserved.',
    );
  const config = current.saved.configuration ?? {};
  const comfyUrl = z.string().url().parse(config.comfyUrl),
    serveUrl = z.string().url().parse(config.serveUrl);
  const system = z
    .object({ platform: z.enum(['linux', 'win32']) })
    .parse(await client.json('/v1/system'));
  const sourceBytes = await readFile(new URL('./start-worker-runtime.py', import.meta.url));
  const files = [
    {
      name: 'pyproject.toml',
      body: Buffer.from('[project]\nname = "akatz-runtime-start"\nversion = "0.1.0"\n').toString(
        'base64',
      ),
    },
    { name: 'start-worker-runtime.py', body: sourceBytes.toString('base64') },
  ];
  // Executor canonical JSON sorts object keys (body precedes name).
  const canonicalFiles = files.map((file) => ({ body: file.body, name: file.name }));
  const staged = z.object({ directory: z.string() }).parse(
    await client.json('/v1/recipes', {
      files,
      digest: createHash('sha256').update(JSON.stringify(canonicalFiles)).digest('hex'),
    }),
  );
  const join = system.platform === 'win32' ? win32.join : posix.join;
  const setup = {
    description:
      'Start the saved runtime. No packages or models are installed; existing services are preserved.',
    writes: ['Runtime process logs'],
    downloads: [],
    services: [],
    commands: [
      {
        label: 'Starting runtime',
        command: current.python,
        args: [
          join(staged.directory, 'start-worker-runtime.py'),
          current.workspace,
          current.environment,
          current.cg,
          comfyUrl,
          serveUrl,
        ],
      },
    ],
  };
  const plan = reviewSchema.shape.plan.parse(
    await client.json('/v1/plans', {
      ...current.saved,
      id: appId + '-start-' + randomUUID(),
      setup,
      configuration: {
        ...config,
        runtimeAction: 'start',
        workspace: current.workspace,
        environment: current.environment,
        cgExecutable: current.cg,
        pythonExecutable: current.python,
      },
    }),
  );
  return {
    reviewRequired: true,
    runtimeAction: 'start',
    executorId: current.snapshot.executorId,
    executorName: current.snapshot.executorName,
    resourceIds: [],
    plan,
  };
}
