import type { z } from 'zod';

export class RequestFailure extends Error {
  constructor(
    message: string,
    readonly uncertain: boolean,
  ) {
    super(message);
  }
}

/** No mutation retries. A missing/invalid receipt or server error may hide acceptance. */
export class JsonClient {
  constructor(
    private readonly base = '',
    private readonly transport: typeof fetch = fetch,
  ) {}
  async request<T>(
    path: string,
    schema: z.ZodType<T>,
    init: RequestInit = {},
    timeoutMs = 30000,
  ): Promise<T> {
    const mutation = init.method !== undefined && !['GET', 'HEAD'].includes(init.method);
    try {
      const headers = new Headers(init.headers);
      if (typeof init.body === 'string') headers.set('Content-Type', 'application/json');
      const timeout = AbortSignal.timeout(timeoutMs);
      const signal = init.signal ? AbortSignal.any([init.signal, timeout]) : timeout;
      // Native browser fetch requires the Window/Worker global receiver, not this client.
      const response = await this.transport.call(globalThis, this.base + path, {
        ...init,
        headers,
        signal,
      });
      const data: unknown = await response.json();
      if (!response.ok) {
        const message =
          typeof data === 'object' &&
          data !== null &&
          'message' in data &&
          typeof data.message === 'string'
            ? data.message
            : `Request failed (${response.status})`;
        throw new RequestFailure(message, mutation && response.status >= 500);
      }
      return schema.parse(data);
    } catch (error) {
      if (error instanceof RequestFailure) throw error;
      throw new RequestFailure(error instanceof Error ? error.message : 'Request failed', mutation);
    }
  }
}
