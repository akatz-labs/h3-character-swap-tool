"""Pure H3 timeline contracts shared by workflows and app planners."""

WINDOWS = tuple(range(22, 363, 17))

HISTORY = (0, 1, *range(18, 342, 17))

WINDOW_POLICY = "adaptive-target-v1"

def validate_settings(window_frames, history_frames):
    window, history = int(window_frames), int(history_frames)
    if window not in WINDOWS:
        raise ValueError("Window must be 22, 39, 56, ... 362 frames (17n+5).")
    if history not in HISTORY:
        raise ValueError("History must be 0, 1, or 18, 35, 52, ... (17n+1).")
    if history >= window:
        raise ValueError("History must be smaller than the generation window.")
    return window, history

def plan_windows(count, window_frames=124, history_frames=18):
    window, history = validate_settings(window_frames, history_frames)
    if count < 1:
        raise ValueError("Source video has no frames.")
    # History precedes the target; only its boundary frame is regenerated.
    # Do not move the tail backwards and resample an already accepted prefix.
    result, covered = [], 0
    while covered < count:
        effective_history = history if result else 0
        start = covered - (1 if effective_history else 0)
        needed = min(count - start, window)
        # The first target has no history, even when the configured history is long.
        size = next(v for v in WINDOWS if v >= needed and v > effective_history)
        end = min(count, start + size)
        result.append({"index": len(result), "source_start": start, "source_end_exclusive": end,
            "window_frames": size, "padded_tail_frames": size - (end - start),
            "history_frames": effective_history,
            "history_start": start - effective_history + 1 if effective_history else None,
            "history_end_exclusive": start + 1 if effective_history else None,
            "discarded_overlap": covered - start, "delivered_frames": end - covered})
        covered = end
    return result

WINDOW_SIZES = tuple(range(22, 363, 17))

def validate_window_size(value) -> int:
    frames = int(value)
    if frames not in WINDOW_SIZES:
        raise ValueError("Window size must be 22, 39, 56, ... 362 frames (17n + 5)")
    return frames

def window_starts(count: int, window_frames: int = 22) -> list[int]:
    window_frames = validate_window_size(window_frames)
    if count < 1:
        raise ValueError("Source video has no frames")
    starts = [0]
    stride = window_frames - 1
    while starts[-1] + window_frames < count:
        candidate = min(starts[-1] + stride, count - window_frames)
        # An 18-frame history needs a boundary at frame 17 or later.
        # Retain the original 22-frame scheduling behavior for short tails.
        starts.append(max(stride, candidate))
    return starts

def plan_segment(source_frames, history_frames=0):
    """An explicit app segment whose source includes its supplied history."""
    if type(source_frames) is not int or type(history_frames) is not int or history_frames not in HISTORY:
        raise ValueError("Invalid segment frame counts")
    target = source_frames-history_frames
    needed = target+bool(history_frames)
    sizes = [v for v in WINDOWS if v >= needed and v > history_frames]
    if target < 1 or not sizes:
        raise ValueError("The explicit segment must fit a single diffusion pass")
    h, size = history_frames, sizes[0]
    return [{"index": 0, "source_start": h-1 if h else 0,
             "source_end_exclusive": source_frames, "window_frames": size,
             "padded_tail_frames": size-needed, "history_frames": h,
             "history_start": 0 if h else None, "history_end_exclusive": h if h else None,
             "discarded_overlap": int(bool(h)), "delivered_frames": target}]
