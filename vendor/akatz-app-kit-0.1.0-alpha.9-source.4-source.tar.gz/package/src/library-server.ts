import type { IncomingMessage, ServerResponse } from 'node:http';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { spawn } from 'node:child_process';
import { z } from 'zod';
import {
  libraryItemSchema,
  libraryPageSchema,
  libraryQuerySchema,
  libraryAppSchema,
  libraryProjectSchema,
  matchesLibraryScope,
} from './library.js';

const videoFormats: Readonly<Record<string, string>> = {
  'video/mp4': 'mov',
  'video/quicktime': 'mov',
  'video/webm': 'matroska',
  'video/x-matroska': 'matroska',
};

/** One CPU-decoded poster, never a browser video per card or a whole-file buffer.
 * The URL is constructed below from the trusted loopback service and a UUID.
 * Fixed demuxers exclude playlists and their nested network/file references.
 */
async function videoThumbnail(url: URL, format: string, signal: AbortSignal): Promise<Uint8Array> {
  const boundedSignal = AbortSignal.any([signal, AbortSignal.timeout(15000)]);
  boundedSignal.throwIfAborted();
  return new Promise((resolve, reject) => {
    const process = spawn(
      'ffmpeg',
      [
        '-nostdin',
        '-hide_banner',
        '-loglevel',
        'error',
        '-protocol_whitelist',
        'http,tcp',
        '-rw_timeout',
        '10000000',
        '-threads',
        '1',
        '-f',
        format,
        '-i',
        url.href,
        '-map',
        '0:v:0',
        '-frames:v',
        '1',
        '-an',
        '-filter_threads',
        '1',
        '-vf',
        'scale=480:320:force_original_aspect_ratio=decrease',
        '-threads',
        '1',
        '-c:v',
        'libwebp',
        '-quality',
        '72',
        '-f',
        'image2pipe',
        'pipe:1',
      ],
      { stdio: ['ignore', 'pipe', 'ignore'] },
    );
    const chunks: Buffer[] = [];
    let size = 0;
    let oversized = false;
    const abort = () => process.kill('SIGKILL');
    boundedSignal.addEventListener('abort', abort, { once: true });
    if (boundedSignal.aborted) abort();
    process.stdout.on('data', (bytes: Buffer) => {
      size += bytes.length;
      if (size > 512 * 1024) {
        oversized = true;
        abort();
      } else chunks.push(bytes);
    });
    process.on('error', () => {
      boundedSignal.removeEventListener('abort', abort);
      reject(new Error('Video thumbnail requires the host ffmpeg executable.'));
    });
    process.on('close', (code) => {
      boundedSignal.removeEventListener('abort', abort);
      if (boundedSignal.aborted || oversized || code !== 0 || !size)
        reject(new Error('Video thumbnail is unavailable.'));
      else resolve(Buffer.concat(chunks));
    });
  });
}

/** Read-only facade over the existing media service. No catalog or blob store of its own. */
export function libraryMiddleware(options: {
  origin: string;
  thumbnail: (bytes: Uint8Array) => Promise<Uint8Array>;
  trustedHosts?: readonly string[];
  trustedOrigins?: readonly string[];
}) {
  const origin = new URL(options.origin);
  if (
    origin.protocol !== 'http:' ||
    !['localhost', '127.0.0.1', '[::1]'].includes(origin.hostname) ||
    origin.username ||
    origin.password
  )
    throw new Error('Library requires the configured loopback media service.');
  const thumbnails = new Map<string, Uint8Array>();
  let cachedBytes = 0;
  let thumbnailWorkers = 0;
  const waiting: (() => void)[] = [];
  async function thumbnailSlot<T>(operation: () => Promise<T>): Promise<T> {
    if (thumbnailWorkers >= 2) await new Promise<void>((resolve) => waiting.push(resolve));
    else thumbnailWorkers++;
    try {
      return await operation();
    } finally {
      const next = waiting.shift();
      if (next) next();
      else thumbnailWorkers--;
    }
  }
  const upstream = async (
    path: string,
    signal: AbortSignal,
    headers?: HeadersInit,
    method = 'GET',
  ) => {
    const response = await fetch(new URL('/v1' + path, origin), {
      signal,
      method,
      ...(headers ? { headers } : {}),
    });
    if (!response.ok && response.status !== 416)
      throw new Error(`Shared Library is unavailable (${response.status}).`);
    return response;
  };
  return async (request: IncomingMessage, response: ServerResponse, next: () => void) => {
    if (!request.url?.startsWith('/kit-media/')) return next();
    const controller = new AbortController();
    response.on('close', () => controller.abort());
    const signal = AbortSignal.any([controller.signal, AbortSignal.timeout(30000)]);
    const json = (data: unknown, status = 200) => {
      response.writeHead(status, {
        'content-type': 'application/json',
        'cache-control': 'no-store',
      });
      response.end(JSON.stringify(data));
    };
    try {
      const host = request.headers.host;
      if (
        !host ||
        (!/^(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/.test(host) &&
          !options.trustedHosts?.includes(host) && !options.trustedOrigins?.some(o=>new URL(o).host===host)) ||
        !['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(request.socket.remoteAddress ?? '') ||
        (request.headers.origin && request.headers.origin !== 'http://' + host &&
          !options.trustedOrigins?.some(o=>new URL(o).host===host&&o===request.headers.origin))
      )
        return json({ message: 'Library requires same-origin loopback access.' }, 403);
      if (!['GET', 'HEAD'].includes(request.method ?? ''))
        return json({ message: 'The library browser is read-only.' }, 405);
      const url = new URL(request.url, 'http://' + host);
      if (url.pathname === '/kit-media/registry') {
        const [apps, projects] = await Promise.all(
          ['/apps', '/projects'].map(async (path) => (await upstream(path, signal)).json()),
        );
        // Strip dataRoot and all other host-only registration fields.
        return json({
          apps: z.object({ items: z.array(libraryAppSchema) }).parse(apps).items,
          projects: z.object({ items: z.array(libraryProjectSchema) }).parse(projects).items,
        });
      }
      if (url.pathname === '/kit-media/items') {
        const query = libraryQuerySchema.parse(Object.fromEntries(url.searchParams));
        let offset = query.offset;
        // v1 does not filter by project/instance. Scan bounded pages without dropping
        // matches or returning a false terminal cursor. Include linked associations.
        for (let page = 0; page < 5; page++) {
          const result = libraryPageSchema.parse(
            await (
              await upstream(
                '/media?' +
                  new URLSearchParams({
                    offset: String(offset),
                    limit: '48',
                    ...(query.q ? { q: query.q } : {}),
                  }),
                signal,
              )
            ).json(),
          );
          if (result.nextOffset !== null && result.nextOffset <= offset)
            throw new Error('Library returned an invalid page cursor.');
          const items = result.items.filter(
            (item) => !item.trashedAt && matchesLibraryScope(item, query),
          );
          if (items.length || result.nextOffset === null || page === 4)
            return json({ items, nextOffset: result.nextOffset });
          offset = result.nextOffset;
        }
      }
      const match = /^\/kit-media\/items\/([a-f0-9-]+)\/(file|thumbnail)$/.exec(url.pathname);
      if (!match) return json({ message: 'Library route not found.' }, 404);
      const id = z.string().uuid().parse(match[1]);
      if (match[2] === 'thumbnail') {
        const item = libraryItemSchema.parse(await (await upstream('/media/' + id, signal)).json());
        const videoFormat = videoFormats[item.mime];
        if (
          !item.available ||
          item.trashedAt ||
          (!videoFormat &&
            (!['image/png', 'image/jpeg', 'image/webp'].includes(item.mime) ||
              item.size > 25 * 1024 ** 2))
        )
          return json({ message: 'No thumbnail available.' }, 404);
        const key = item.libraryId + ':' + id;
        let bytes = thumbnails.get(key);
        if (!bytes) {
          bytes = await thumbnailSlot(async () => {
            signal.throwIfAborted();
            const cached = thumbnails.get(key);
            if (cached) return cached;
            const encodeImage = async () => {
              const source = await upstream('/media/' + id + '/file', signal);
              const chunks: Uint8Array[] = [];
              let length = 0;
              if (!source.body) throw new Error('Image is unavailable.');
              for await (const chunk of source.body as unknown as AsyncIterable<Uint8Array>) {
                length += chunk.length;
                if (length > 25 * 1024 ** 2) throw new Error('Image exceeds preview limit.');
                chunks.push(chunk);
              }
              return options.thumbnail(Buffer.concat(chunks));
            };
            const encoded = videoFormat
              ? await videoThumbnail(
                  new URL('/v1/media/' + id + '/file', origin),
                  videoFormat,
                  signal,
                )
              : await encodeImage();
            if (encoded.length <= 512 * 1024) {
              while (cachedBytes + encoded.length > 8 * 1024 ** 2 && thumbnails.size) {
                const first = thumbnails.keys().next().value!;
                cachedBytes -= thumbnails.get(first)!.length;
                thumbnails.delete(first);
              }
              thumbnails.set(key, encoded);
              cachedBytes += encoded.length;
            }
            return encoded;
          });
        }
        response.writeHead(200, {
          'content-type': 'image/webp',
          'content-length': bytes.length,
          'cache-control': 'private, max-age=3600',
          'x-content-type-options': 'nosniff',
        });
        return response.end(request.method === 'HEAD' ? undefined : bytes);
      }
      const result = await upstream(
        '/media/' + id + '/file',
        signal,
        request.headers.range ? { range: request.headers.range } : {},
        request.method,
      );
      response.statusCode = result.status;
      for (const header of [
        'content-type',
        'content-length',
        'content-range',
        'accept-ranges',
        'cache-control',
        'etag',
        'content-disposition',
      ]) {
        const value = result.headers.get(header);
        if (value) response.setHeader(header, value);
      }
      response.setHeader('x-content-type-options', 'nosniff');
      if (request.method === 'HEAD' || !result.body) return response.end();
      await pipeline(
        Readable.fromWeb(result.body as Parameters<typeof Readable.fromWeb>[0]),
        response,
      );
    } catch (error) {
      if (controller.signal.aborted) return;
      if (response.headersSent) response.destroy();
      else
        json(
          {
            message:
              error instanceof z.ZodError
                ? 'Invalid library response or request.'
                : error instanceof Error
                  ? error.message
                  : 'Shared Library is unavailable.',
          },
          503,
        );
    }
  };
}
