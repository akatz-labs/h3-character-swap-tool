'use client';
import React, {useCallback,useEffect,useRef,useState} from 'react';

export const executorPhaseLabel = phase => ({queued:'Queued',preparing:'Preparing',rendering:'Rendering',finalizing:'Finalizing',completed:'Completed',failed:'Failed',cancelled:'Cancelled',uncertain:'Needs reconciliation'}[phase] || phase);

export function ExecutorControl({request,feature,settingsFields=[],onSelection,manageOnly=false}) {
  const [registry,setRegistry]=useState(null),[error,setError]=useState(''),[busy,setBusy]=useState(false),[open,setOpen]=useState(false),[plan,setPlan]=useState(null);
  const [connection,setConnection]=useState({id:'',name:'',host:''}),[settings,setSettings]=useState({});
  const dialog=useRef(null),offered=useRef(false),callback=useRef(onSelection);callback.current=onSelection;
  const eligible=(registry?.items || []).filter(item=>item.online && (manageOnly || item.installations.some(value=>value.ready && value.features.includes(feature))));
  const selected=eligible.find(item=>item.id===(manageOnly?registry?.defaultExecutorId:registry?.selectedExecutorId));
  const refresh=useCallback(async()=>{
    try{const result=await request('list');setRegistry(result);setError('');
      const choices=result.items.filter(item=>item.online && (manageOnly || item.installations.some(value=>value.ready && value.features.includes(feature))));
      const chosen=choices.find(item=>item.id===(manageOnly?result.defaultExecutorId:result.selectedExecutorId));callback.current?.(chosen?.id || null);
      if(!manageOnly&&!choices.length&&!offered.current){offered.current=true;setOpen(true);}
    }catch(error){setError(error.message);callback.current?.(null);}
  },[request,feature,manageOnly]);
  useEffect(()=>{void refresh();const timer=setInterval(()=>void refresh(),15000);return()=>clearInterval(timer);},[refresh]);
  useEffect(()=>{if(open&&!dialog.current?.open)dialog.current?.showModal();else if(!open&&dialog.current?.open)dialog.current.close();},[open]);
  async function perform(action,input) {
    setBusy(true);setError('');try{const result=await request(action,input);return result;}catch(error){setError(error.message);return null;}finally{setBusy(false);}
  }
  async function select(id){if(await perform(manageOnly?'default':'select',{executorId:id}))await refresh();}
  async function reviewInstall(id){const result=await perform('install-plan',{executorId:id,settings:settings[id] || {}});if(result)setPlan({...result,kind:'install'});}
  async function confirm(){if(await perform(plan.kind==='connect'?'connect-confirm':'install-confirm',{id:plan.id,digest:plan.digest})){setPlan(null);await refresh();}}
  return <div className="akatz-executors">
    <style>{`.akatz-executors{display:flex;gap:8px;align-items:center;font:inherit;font-size:12px;color:inherit}.akatz-executors button,.akatz-executors select,.akatz-executors input{font:inherit;color:inherit;border:1px solid color-mix(in srgb,currentColor 20%,transparent);background:transparent;border-radius:7px;padding:7px 10px}.akatz-executors button{cursor:pointer}.akatz-executors button:disabled{opacity:.5;cursor:default}.akatz-executors select{max-width:180px}.akatz-executors option{color:#171b24;background:#fff}.akatz-executors dialog{color:#e9edf5;background:#151923;border:1px solid #394253;border-radius:14px;width:min(680px,calc(100vw - 32px));max-height:85vh;margin:auto;padding:24px;box-shadow:0 20px 70px #0008}.akatz-executors dialog::backdrop{background:#0008}.akatz-executors h2{font-size:20px;margin:0}.akatz-executors h3{font-size:14px;margin:0}.akatz-executors p{line-height:1.6;margin:10px 0;color:#aeb8c8}.akatz-executors .ae-heading,.akatz-executors .ae-row{display:flex;align-items:center;justify-content:space-between;gap:12px}.akatz-executors .ae-card{padding:16px;border:1px solid #343e50;border-radius:10px;margin-top:12px}.akatz-executors .ae-card small{display:block;color:#aeb8c8;margin-top:4px}.akatz-executors .ae-fields{display:grid;gap:10px;margin:12px 0}.akatz-executors label{display:grid;gap:5px}.akatz-executors input{min-width:0;width:100%;box-sizing:border-box}.akatz-executors .ae-error{color:#ffb5ad}.akatz-executors .ae-primary{background:#4663df;border-color:#627bed;color:white}.akatz-executors details{margin-top:12px}.akatz-executors summary{cursor:pointer;color:#b5c4ea}.akatz-executors .ae-plan{border-color:#748bdf;background:#202b43}.akatz-executors .ae-plan li{overflow-wrap:anywhere;margin:6px 0}.akatz-executors .ae-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:14px}.akatz-executors .ae-connection{border-top:1px solid #343e50;margin-top:20px;padding-top:18px}.akatz-executors .ae-badge{font-size:11px;border:1px solid #465474;padding:3px 7px;border-radius:20px;white-space:nowrap}`}</style>
    <select aria-label="Generation executor" value={selected?.id || ''} disabled={!eligible.length||busy} onChange={event=>void select(event.target.value)}>
      {!selected&&<option value="">{registry?'Choose a ready machine':'Loading machines…'}</option>}
      {eligible.map(item=><option key={item.id} value={item.id}>{item.name}</option>)}
    </select>
    <button type="button" onClick={()=>setOpen(true)}>Resources</button>
    <dialog ref={dialog} onCancel={()=>setOpen(false)} onClose={()=>setOpen(false)} aria-label="Executors and app resources">
      <div className="ae-heading"><h2>Executors & resources</h2><button type="button" aria-label="Close resources" onClick={()=>setOpen(false)}>✕</button></div>
      <p>Choose where this app generates. Machines and the default are shared across your Akatz apps; each app remembers its own selection.</p>
      {!manageOnly&&!eligible.length&&registry&&<p>No executor is ready for this feature. Install its resources on a connected machine, or add a machine below.</p>}
      {error&&<p className="ae-error" role="alert">{error}</p>}
      <button type="button" disabled={busy} onClick={()=>void refresh()}>Refresh readiness</button>
      {(registry?.items || []).map(item=><section className="ae-card" key={item.id}>
        <div className="ae-row"><div><h3>{item.name}</h3><small>{item.online?'Connected':'Offline'}{item.kind==='local'?' · This machine':''}</small></div>{registry.defaultExecutorId===item.id?<span className="ae-badge">Global default</span>:<button disabled={busy} onClick={async()=>{if(await perform('default',{executorId:item.id}))await refresh();}}>Make default</button>}</div>
        {item.error&&<p>{item.error}</p>}
        {item.installations.map(value=><div key={value.installation.id}><p>{value.features.length?'Ready: '+value.features.map(name=>name.replaceAll('-',' ')).join(', '):'Resources need attention'}</p>{value.problems.length>0&&<details><summary>Readiness details</summary><ul>{value.problems.map(problem=><li key={problem}>{problem}</li>)}</ul></details>}</div>)}
        {!item.installations.length&&<p>{manageOnly?"No app resources are registered here yet. Open an app to set up its resources.":"This app’s resources are not installed here."}</p>}
        {!manageOnly&&<details><summary>Runtime settings</summary><div className="ae-fields"><label>Setup mode<select value={settings[item.id]?.installMode || "existing"} onChange={event=>setSettings(current=>({...current,[item.id]:{...current[item.id],installMode:event.target.value}}))}><option value="existing">Reuse installed resources</option><option value="new">Install a new runtime</option></select></label>{settingsFields.map(field=><label key={field.key}>{field.label}<input value={settings[item.id]?.[field.key] || ''} placeholder={field.placeholder || ''} onChange={event=>setSettings(current=>({...current,[item.id]:{...current[item.id],[field.key]:event.target.value}}))}/></label>)}</div></details>}
        {!manageOnly&&<div className="ae-actions"><button disabled={busy||!item.online} onClick={()=>void reviewInstall(item.id)}>Review app setup</button></div>}
      </section>)}
      <section className="ae-connection"><h3>Add another machine</h3><p>Connect using an SSH host or alias available to this computer. Executor setup and app resource installation are separate steps.</p>
        <div className="ae-fields"><label>Name<input value={connection.name} onChange={event=>setConnection(current=>({...current,name:event.target.value,id:event.target.value.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')}))}/></label><label>SSH host<input value={connection.host} placeholder="user@workstation" onChange={event=>setConnection(current=>({...current,host:event.target.value}))}/></label></div>
        <button disabled={busy||!connection.name.trim()||!connection.host.trim()} onClick={async()=>{const value=await perform('connect-plan',connection);if(value)setPlan({...value,kind:'connect'});}}>Review connection setup</button>
      </section>
      {plan&&<section className="ae-card ae-plan" aria-label="Review setup plan"><h3>{plan.kind==='connect'?'Connect executor':'Set up app resources'}</h3><p>{plan.description}</p><ul>{(plan.requires || []).map(value=><li key={value}>Requires: {value}</li>)}{(plan.writes || []).map(value=><li key={value}>Writes: {value}</li>)}{(plan.downloads || []).map((value,index)=><li key={index}>Download: {typeof value==='string'?value:JSON.stringify(value)}</li>)}</ul>{plan.installation&&<p>Features: {plan.installation.features.join(', ')}. Configuration is fixed for this installation.</p>}<div className="ae-actions"><button disabled={busy} onClick={()=>setPlan(null)}>Cancel</button><button className="ae-primary" disabled={busy} onClick={()=>void confirm()}>{busy?'Setting up…':'Confirm setup'}</button></div></section>}
    </dialog>
  </div>;
}
