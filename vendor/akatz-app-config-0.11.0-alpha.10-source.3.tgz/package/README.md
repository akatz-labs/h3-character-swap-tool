# Akatz app configuration

A small configuration and component runtime above ComfyGit, used by the Splat
Smith, Asset Studio and ModelGen Node servers. The original configuration/discovery API
remains read-only. The v2 runtime adds explicit setup and execution for independent
Python and native tools alongside a ComfyGit environment. ComfyGit continues to
own ComfyUI recipes, dependencies and model storage.

Set `AKATZ_CONFIG` to an absolute JSON path, or create `akatz/apps.json` under
Linux `$XDG_CONFIG_HOME` (default `~/.config`), macOS `~/Library/Application Support`,
or Windows `%APPDATA%`. Missing default files preserve the app's existing defaults.
An explicitly selected missing or invalid file fails with an actionable error.

```json
{
  "schemaVersion": 1,
  "defaults": { "workspace": "/absolute/path/to/comfygit" },
  "apps": {
    "splat-smith": { "environment": "splat-smith", "serveUrl": "http://127.0.0.1:8213", "comfyUrl": "http://127.0.0.1:8210" },
    "asset-studio": { "environment": "trellis2-game-assets", "serveUrl": "http://127.0.0.1:8822", "apiUrl": "http://127.0.0.1:8824" }
  }
}
```

Replace the example workspace with an existing installation. Paths in the file
must be absolute. `dataRoot` is optional and app-specific; never share app state.
Model storage is discovered from `cg inventory --json`, not repeated in this file.
Precedence: explicit environment variables, app entry, shared defaults, app defaults.
Supported overrides: `COMFYGIT_HOME`, `COMFYGIT_ENVIRONMENT`, `STUDIO_DATA_ROOT`,
`COMFYGIT_SERVE_URL`, `COMFY_BASE_URL`, `ASSET_STUDIO_API_URL`.
Splat Smith desktop launcher settings remain explicit overrides. Connecting both
Node servers through this file is validated; desktop UI configuration and native
Windows/macOS runtime certification are subsequent work.

Run `node scripts/inspect.mjs APP_ID /path/to/akatz-app.json` with `cg` on PATH.
This verifies the recipe SHA-256 and reads installed environments/model storage.
A missing selection returns candidates instead of selecting or creating one.
Inspection is not proof of generation readiness or a GPU capability claim.
Each app's `akatz-app.json` references its recipe without duplicating model lists.
Endpoints in this configuration API are explicit operator choices. Its discovery
functions do not start services or coordinate execution. The separate executor
API below owns reviewed setup and GPU scheduling.
Keep credentials in the existing credential manager, not this file.

The initial distribution is vendored source with content hashes, avoiding an
unpublished npm dependency or sibling-checkout requirement. Update via
`node scripts/vendor.mjs DESTINATION`; verify via the same command with `--check`.
Consumers must bundle/copy the vendored module in their normal release build.
`npm test` covers precedence, invalid configuration, discovery, and recipe drift.
The shared repository deliberately remains unscoped; no new Console project was created.

## Composite applications

Use `AppRuntime` from `@akatz/app-config/runtime` with a v2 `akatz-app.json`.
See [the component contract](docs/component-contract.md). Asset Studio is the
working consumer: ComfyGit mesh generation, a small Python thumbnail environment,
a separate CPU ARDY environment, and a selected Blender executable. Feature
requirements determine availability independently.

```js
import { resolveAppConfig } from '@akatz/app-config';
import { AppRuntime } from '@akatz/app-config/runtime';
const runtime = new AppRuntime('./akatz-app.json', resolveAppConfig('my-app'));
try {
  console.log(await runtime.plan());
  await runtime.install('thumbnails'); // Explicitly creates an owned Python venv.
  await runtime.run('thumbnails', 'render', [inputPath, outputPath], {
    timeout: 120000, signal: abortController.signal,
  });
} finally { await runtime.close(); }
```

Portable descriptors reference SHA-256 checked files and immutable source/model
revisions. They contain no installation paths. Local `apps.APP_ID` settings accept
`runtimeRoot`, `modelCache` and `components.COMPONENT_ID` overrides for absolute
`executable`, `sourceRoot`, `workRoot` and `modelCache` paths. Component overrides
are app-specific. `dataRoot` can move without moving installed tools. Python
environments default to the native user data directory under
`akatz/runtimes/APP_ID/COMPONENT_ID/IDENTITY/`.

`install()` requires `uv` and, for source components, Git. It installs exact locked
dependencies and a non-editable source build into a new owned directory. External
interpreters are read-only. Failure removes only that attempt's new directory;
existing incomplete installs are preserved and require inspection or a new root.
Changing a component identity selects a fresh directory; old installs remain.
`acquireModels()` separately downloads pinned snapshots with the component's `hf`
CLI. Existing HF authentication and access are required. Readiness checks required
snapshot file presence and size; it does not hash all model bytes.

Native tools support a selected executable/version or a digest-checked bundled
binary. Archive acquisition, OS installers, updates and uninstall are not provided.
Neither runtime API starts ComfyUI or acquires compute leases. Applications retain
their queues, output schemas and GPU scheduling policy. ComfyGit components check
the selected service's environment identity and execution health; they do not
attest that a running service was built from the exact descriptor recipe.

Linux x64 Python/native execution is exercised by Asset Studio. The shared path
rules support other operating systems, but its current components deliberately
declare only Linux x64. A cross-platform distributable installer remains future
work. Splat Smith uses the updated reader through the compatible v1 configuration
API, so both applications can share a file containing v2 component selections.

## Launcher execution targets

The `./targets` export adds read-only local/SSH inspection for the launcher. Select
an existing workspace and its ComfyGit Python interpreter, then call
`inspectTarget(target, recipes)`. Recipes are portable manifest text plus SHA-256.
The adapter uses core import analysis and current inventory to return per-app
reuse, verification, download and missing-source counts with known model sizes.
It never downloads or changes the selected model folder. SSH targets currently
support Linux paths and normal OpenSSH host aliases/authentication. The launcher
consumes v0.3; existing v0.2 app integrations remain valid.

See [Image to 3D adoption assessment](docs/image3d-adoption-plan.md) for the current consumer boundaries and the proposed package, media-library and durable-job migration. The assessment is historical; the active contracts and reference consumer guide describe the implemented exports.

## Shared media and the reference consumers (0.5)

See [the reference consumer guide](docs/reference-consumer.md) and
[media API contract](docs/media-contract.md) for package adoption, a persistent
library service, the runnable producer example, and Image to 3D's durable output
and batch integration. The API version is independent from the package version.

## Local application storage

`@akatz/app-config/storage` supplies common data paths, durable app identity,
SQLite migrations/backups and hash-addressed app objects. The independent media
service supplies app/project discovery and shared originals. See
[the storage contract](docs/storage-contract.md) and [media API](docs/media-contract.md).
Set `AKATZ_DATA_ROOT` or `storage.json` beside `apps.json` with
`{"schemaVersion":1,"root":"/absolute/path/to/data"}` for a common root.
Existing explicit app/media roots remain authoritative; relocation requires verified migration.
Cloud synchronization and physical garbage collection are not implemented.

## Shared executors (v0.6)

ModelGen, Image-to-3D and the launcher can use `AppExecutors` from
`@akatz/app-config/app-executors`. The optional React `ExecutorControl` lives at
`@akatz/app-config/executor-ui`. Apps work without the launcher: opening Resources
sets up or reuses this user's local executor, and a reviewed SSH connection sets
up the same service on another machine. Node.js 22.16+ and existing SSH access are
prerequisites. Linux user services supervise the executor; other platforms use a
detached process and have not passed app-runtime validation.

The local service owns a shared machine registry, global default, remembered app
selections, installation plans, readiness and durable jobs. Each app supplies its
pinned adapter and resource plan. Setup verifies adapters, runtime ownership,
workflow availability and every declared model's ComfyGit content identity.
Unpinned required models block setup. This is ComfyGit's sampled model identity,
not a full-file SHA-256 claim. Input/output transfers do use full SHA-256.

One FIFO queue per executor serializes complete GPU operations across apps;
separate machines run independently. Jobs freeze selection and input identity at
acceptance. Closing an app leaves accepted work running. On restart the app
collects the same retained outputs. A lost runtime response fences the queue as
`uncertain`; v0.6 does not implement automatic retry, in-flight cancellation, or
an operator reconciliation UI.

Setup and generation are distinct. The shipped Image-to-3D installer uses
ComfyGit to create a separate environment and acquire missing models. ModelGen
can adopt the established normal/Fast runtimes; its unpublished development nodes
and missing model acquisition sources still block a fresh installation. New
Comfy runtimes currently remain detached after the installer exits; automatic
runtime restart after host reboot and removal/update lifecycle are follow-ups.
CPU animation, Blender and thumbnails continue using their existing component
APIs and are not remote GPU executor features.

See [the normative contract](docs/executor-contract.md) and
[the milestone evidence and limits](docs/executor-milestone.md).

## Desktop apps and machine status (v0.7)

`@akatz/app-config/desktop-apps` provides reviewed registration and discovery of
existing local app folders/opening URLs, independently of GPU readiness. It also
loads app-owned, digest-verified generation setup packages for the launcher or
standalone app. Registration files live beside shared configuration under
`desktop-apps/`; they contain local metadata, not model bytes or project data.

`GET /v1/status` reports the executor's measured GPU/storage, declared model files,
and active operations. `AppExecutors.operation('preferences')` reads selection
scope; `use-default` clears an app override and `rename` updates a machine label.
Unavailable selected machines no longer silently fall back to another worker.
Viewing a machine is a client UI concern and never changes shared preferences.

## Managed desktop startup (v0.8)

`@akatz/app-config/desktop-runtime` starts a registered app's verified
`desktop/launch.json` entrypoint and waits for its UI and API health checks.
Concurrent Open requests share one loopback address. Closing the launcher does
not close apps or executor jobs; a later Open recovers an exited app stack.
Startup errors retain a bounded diagnostic log. Foreign services on the chosen
port are left alone. App data paths are explicit registration settings.

These are built local checkouts. Applications must provide their own production
build and startup module; this is not an installer or an update manager.
See [the desktop contract](docs/desktop-contract.md).

## Verified executor recovery (v0.9)

The executor advertises `job-recovery-v1` in `/v1/health`. For an uncertain job,
`POST /v1/jobs/:id/recovery-plan` takes its `executorId` and an uploaded
`adapterRevision`. The app-owned module must export `recoveryAppId` and
`inspectRecovery(context)` and prove `submission: 'not-submitted'` with
`safeToRetry: true`. Empty queues alone are insufficient evidence.

`POST /v1/jobs/:id/recover` confirms the returned `planId`, `digest` and
`executorId`. Confirmation verifies the evidence again, archives the old attempt,
and requeues the same immutable request in its original FIFO position. Repeat
confirmation is idempotent. Interrupted transitions stay fenced and can resume
with the same plan. This intentionally does not force-clear ambiguous work,
replace an accepted adapter, or retry a request that may already have rendered.

## Developing with ComfyGit source

ComfyGit CLI, core and Studio remain separate from this Node package. The shared
layer invokes their Python interpreter or HTTP service; it does not embed
Python in the Node process.

On each development **executor host**, sync the ComfyGit monorepo with
`uv sync --frozen --all-packages`. Set `AKATZ_COMFYGIT_DEV_ROOT` to that checkout,
or create the host-local `akatz/comfygit-development.json` under the OS user
configuration directory:

```json
{"schemaVersion":1,"enabled":true,"sourceRoot":"/absolute/path/to/comfygit"}
```

`GET /v1/system` reports `comfygitDevelopment` with the selected interpreter,
CLI and all three package versions. A missing/stale/non-editable installation
fails explicitly. App setup and model-index bridges select that interpreter
instead of bootstrapping bundled wheels. Recipes, models and existing runtime
processes are preserved. A remote executor needs its own source checkout and
opt-in; client paths are never sent to it as development configuration.

New Python commands see edited source immediately. Dependency changes require
another `uv sync`; running Python services retain loaded modules until their
normal safe restart. Node source changes likewise require watch mode or a
restart. Built desktop payloads do not become editable when source is linked.
Set `AKATZ_COMFYGIT_MODE=release` to ignore development selection.

Applications retain content-hashed shared-package archives and locked wheel
manifests for reproducible installs. Their `release:check` refuses a development
link and verifies each ComfyGit wheel against the exact version on PyPI.
`toolchain:refresh` downloads only that declared version's published wheels,
verifies hashes, then updates the manifest. It fails if that version is not yet
published; it never chooses an older release or silently tracks latest. Run a
clean install/test after refreshing. Environment recipes and native/model pins
remain independent.
