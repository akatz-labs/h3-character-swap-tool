/** Store before dispatch. Browser/app adapters supply durable storage, never secret data. */
export interface FenceStore {
  has(key: string): boolean;
  add(key: string): void;
  delete(key: string): void;
  getAttempt?(key: string): string | null;
  setAttempt?(key: string, id: string): void;
}
export function memoryFences(): FenceStore {
  const values = new Map<string, string | null>();
  return {
    has: (key) => values.has(key),
    add: (key) => {
      if (!values.has(key)) values.set(key, null);
    },
    delete: (key) => {
      values.delete(key);
    },
    getAttempt: (key) => values.get(key) ?? null,
    setAttempt: (key, id) => {
      values.set(key, id);
    },
  };
}
export function storageFences(
  storage: Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>,
  namespace: string,
): FenceStore {
  return {
    has: (key) => storage.getItem(`${namespace}.${encodeURIComponent(key)}`) !== null,
    add: (key) => storage.setItem(`${namespace}.${encodeURIComponent(key)}`, 'unreconciled'),
    delete: (key) => storage.removeItem(`${namespace}.${encodeURIComponent(key)}`),
    getAttempt: (key) => {
      const value = storage.getItem(`${namespace}.${encodeURIComponent(key)}`);
      return value && value !== 'unreconciled' ? value : null;
    },
    setAttempt: (key, id) => storage.setItem(`${namespace}.${encodeURIComponent(key)}`, id),
  };
}
