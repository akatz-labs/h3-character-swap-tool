import type { ChildProcess } from 'node:child_process';
import type { AppSettings, ComponentSelection } from './index.mjs';
import type { LoadedManifest, Component } from './manifest.mjs';
export interface ComponentReadiness { id: string; label: string; kind: Component['kind']; status: 'ready' | 'missing' | 'unsupported' | 'blocked' | 'incompatible' | 'broken'; reasons: string[]; executable?: string; ownership?: 'managed' | 'external'; version?: string; installation?: unknown }
export interface CommandOptions { cwd?: string; env?: Record<string,string>; timeout?: number; signal?: AbortSignal; onOutput?: (text: string) => void; onStart?: (child: ChildProcess) => void }
export interface ComponentLocation { id: string; component: Component; identity: string; managed: string; receiptPath: string; executable: string | null; sourceRoot: string | null; workRoot: string; modelCache: string; ownership: 'managed' | 'external' }
export class AppRuntime {
 constructor(path: string, config?: AppSettings & { appId?: string }, options?: { defaults?: Record<string,ComponentSelection>; commands?: { uv?: string; git?: string; cg?: string }; comfygitTargets?: Record<string,AppSettings> });
 manifest: LoadedManifest;
 runtimeRoot: string;
 component(id: string): Component;
 location(id: string): ComponentLocation;
 inspect(id: string): Promise<ComponentReadiness>;
 plan(): Promise<{ appId: string; descriptorSha256: string; platform: string; runtimeRoot: string; components: ComponentReadiness[]; features: { id: string; label: string; available: boolean; requires: string[] }[] }>;
 run(id: string, entrypoint: string, args?: string[], options?: CommandOptions): Promise<{ code: number; output: string }>;
 executeFile(command: string, args: string[], options?: CommandOptions): Promise<{ code: number; output: string }>;
 install(id: string, options?: Pick<CommandOptions,'signal'|'onOutput'>): Promise<ComponentReadiness>;
 acquireModels(id: string, options?: CommandOptions): Promise<ComponentReadiness>;
 close(): Promise<void>;
}
