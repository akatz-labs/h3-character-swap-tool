import type { Server } from 'node:http';
import type { ConfigOptions } from './index.mjs';
export const MEDIA_API_VERSION: 1;
export const MAX_MEDIA_BYTES: number;
export function mediaConfig(options?: ConfigOptions): Promise<{ root: string; url: string }>;
export function inspectMedia(bytes: Buffer): { mime: string; extension: string };
export function inspectMediaFile(file: string): Promise<{ mime: string; extension: string }>;
export function createMediaService(options?: { root?: string }): Promise<{ server: Server; root: string; libraryId: string; close(): Promise<void> }>;
