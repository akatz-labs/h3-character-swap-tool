export interface ModelResource {
  id:string; name:string; group:string; requirement:'required'|'optional'; relativePath:string; sizeBytes:number;
  sha256:string; shortHash:string; url:string; sourceUrl?:string; stages:string[];
  path:string; state:'installed'|'missing'|'changed'|'unindexed'; verified:boolean; integrity:'sha256'|'comfygit-index'|null;
}
export interface ResourceFeature {id:string;label:string;models:string[];optional:boolean;ready:boolean;missingModels:string[];missingNodes:string[];workflowReady:boolean;}
export interface ModelResourceInventory {
  refreshing?:boolean;
  capabilities?:string[];appId:string;title:string;description?:string;observedAt:string;
  storage:{path:string;workspace:string;indexPath:string;freeBytes:number|null;totalBytes:number|null;managedBytes:number};
  models:ModelResource[];features:ResourceFeature[];
  optionalPacks:Array<{id:string;label:string;description:string;features:string[]}>;
  runtimes:Array<{id:string;name:string;installed:boolean;version?:string|null;required:boolean;detail:string}>;
  summary:{ready:boolean;requiredInstalled:number;requiredTotal:number;missingRequiredBytes:number};
  runtime:{comfyUrl:string|null;serveUrl:string|null;environment:string|null;workspace:string};settings:Record<string,string>;issues:string[];
}
export interface ModelResourceJob {
  id:string;appId:string;kind:string;resourceIds:string[];status:'queued'|'running'|'succeeded'|'failed'|'cancelled';
  progress:number;completedBytes:number;totalBytes:number|null;message:string;error:string|null;createdAt:string;updatedAt:string;
  installationJobId?:string;
  storagePath?:string;stage?:'queued'|'preparing'|'indexing'|'refreshing'|'complete';completedFiles?:number;totalFiles?:number|null;currentFile?:string;
}
export class ModelResources {
  constructor(executor:unknown,options?:{runBridge?:Function;fetchImpl?:typeof fetch});
  ready:Promise<void>;
  register(input:unknown):Promise<unknown>;
  inventory(appId:string):Promise<ModelResourceInventory>;
  listJobs(appId:string):ModelResourceJob[];
  configure(appId:string,input:Record<string,string>):Promise<ModelResourceInventory>;
  uninstallPlan(appId:string,resourceId:string):Promise<ModelUninstallPlan>;
  uninstall(appId:string,plan:{planId:string;digest:string;confirm:string}):Promise<ModelResourceJob>;
  scan(appId:string):Promise<ModelResourceJob>;
  download(appId:string,resourceIds:string[]):Promise<ModelResourceJob>;
  cancel(appId:string,jobId:string):Promise<ModelResourceJob>;
  setStorage(appId:string,path:string):Promise<ModelResourceJob>;
  setup(appId:string,plan:{planId:string;digest:string;resourceIds?:string[]}):Promise<ModelResourceJob>;
  close():Promise<void>;
}

export interface ModelUninstallPlan {id:string;digest:string;expiresAt:string;resourceId:string;name:string;path:string;sizeBytes:number;reclaimBytes:number;usedByApps:string[];stages:string[];environments:unknown[];blockers:string[];canUninstall:boolean;}
