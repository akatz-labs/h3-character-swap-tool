import { useEffect, useState } from 'react';
import {
  connectionInputSchema,
  type ConnectionPlan,
  type SetupPreferences,
  type setupClient,
} from './setup.js';
import { activeJob, type ResourceController, type ResourceState } from './resources.js';

/** Adapted from Splat Smith FirstRunSetup: worker cards → reviewed connect → indexed storage. */
export function WorkerSetup({
  state,
  controller,
  api,
  onContinue,
  onBrowse,
}: {
  state: ResourceState;
  controller: ResourceController;
  api: ReturnType<typeof setupClient>;
  onContinue: (page: 'projects' | 'resources') => void;
  onBrowse: () => void;
}) {
  const [preferences, setPreferences] = useState<SetupPreferences | null>(null);
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  const [adding, setAdding] = useState(false),
    [plan, setPlan] = useState<ConnectionPlan | null>(null);
  const [name, setName] = useState(''),
    [host, setHost] = useState(''),
    [port, setPort] = useState('22');
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [connectionAttempt, setConnectionAttempt] = useState<string | null>(() =>
    localStorage.getItem('akatz-kit.connection-attempt'),
  );
  useEffect(() => {
    let live = true;
    void api
      .preferences()
      .then((value) => {
        if (live) setPreferences(value);
      })
      .catch((error) => {
        if (live) setError(String(error));
      });
    return () => {
      live = false;
    };
  }, [api]);
  const worker = state.registry?.executors.find((item) => item.id === state.workerId);
  const inventory = state.snapshot?.inventory;
  const storageJob = state.snapshot?.jobs.find((job) => job.kind === 'storage' && activeJob(job));
  const path = state.workerId
    ? (drafts[state.workerId] ??
      (preferences?.workerId === state.workerId ? preferences.modelPath : null) ??
      inventory?.storage.path ??
      '')
    : '';
  const locked = busy || state.pending || state.uncertain || Boolean(storageJob);
  async function run(operation: () => Promise<void>) {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      await operation();
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Setup unavailable');
    } finally {
      setBusy(false);
    }
  }
  async function connected(workerId: string) {
    // Clear accepted mutation BEFORE any follow-up read (Splat Smith's recovery rule).
    localStorage.removeItem('akatz-kit.connection-attempt');
    setConnectionAttempt(null);
    setAdding(false);
    setPlan(null);
    setName('');
    setHost('');
    await controller.refresh();
    setPreferences(await api.save({ workerId }));
    controller.select(workerId);
  }
  return (
    <section className="ak-setup ak-panel">
      <p className="ak-eyebrow">Worker setup</p>
      <h1>Choose where generation runs</h1>
      <p className="ak-muted">
        Projects stay on this computer. Models, runtimes, and GPU work belong to the selected
        worker.
      </p>
      {(!state.registry ||
        state.registry.executors.some((item) => item.kind === 'local' && !item.online)) && (
        <section className="ak-panel">
          <h2>Local worker service</h2>
          <p>
            Start or update the shared worker service on this computer. This does not install GPU
            models or runtimes.
          </p>
          <button
            disabled={busy || Boolean(connectionAttempt)}
            onClick={() =>
              void run(async () => {
                const id = crypto.randomUUID();
                localStorage.setItem('akatz-kit.connection-attempt', id);
                setConnectionAttempt(id);
                const result = await api.bootstrap(id);
                await connected(result.workerId);
              })
            }
          >
            Start local worker service
          </button>
        </section>
      )}
      {adding ? (
        <section className="ak-panel">
          <button
            disabled={busy}
            onClick={() => {
              setAdding(false);
              setPlan(null);
            }}
          >
            Back to workers
          </button>
          <h2>{plan ? 'Review connection' : 'Connect another computer'}</h2>
          {plan ? (
            <>
              <p>{plan.description}</p>
              <p>
                <strong>Target:</strong> {plan.target.name} · {plan.target.host}:
                {plan.target.sshPort}
              </p>
              <div className="ak-setup-columns">
                <div>
                  <h3>Requirements</h3>
                  <ul>
                    {plan.requires.map((value) => (
                      <li key={value}>{value}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3>Writes</h3>
                  <ul>
                    {plan.writes.map((value) => (
                      <li key={value}>{value}</li>
                    ))}
                  </ul>
                </div>
              </div>
              <button disabled={busy || Boolean(connectionAttempt)} onClick={() => setPlan(null)}>
                Change details
              </button>
              <button
                className="ak-primary"
                disabled={busy || Boolean(connectionAttempt)}
                onClick={() =>
                  void run(async () => {
                    const id = crypto.randomUUID();
                    localStorage.setItem('akatz-kit.connection-attempt', id);
                    setConnectionAttempt(id);
                    const result = await api.connect(plan, id);
                    await connected(result.workerId);
                  })
                }
              >
                Confirm connection
              </button>
            </>
          ) : (
            <form
              onSubmit={(event) => {
                event.preventDefault();
                void run(async () => {
                  setPlan(
                    await api.plan(
                      connectionInputSchema.parse({
                        id: 'worker-' + crypto.randomUUID(),
                        name,
                        host,
                        sshPort: Number(port),
                        kind: 'ssh',
                      }),
                    ),
                  );
                });
              }}
            >
              <div className="ak-setup-columns">
                <label>
                  Worker name
                  <input
                    required
                    value={name}
                    onChange={(event) => setName(event.target.value)}
                    placeholder="Studio GPU"
                  />
                </label>
                <label>
                  SSH host
                  <input
                    required
                    value={host}
                    onChange={(event) => setHost(event.target.value)}
                    placeholder="user@gpu-machine"
                  />
                </label>
              </div>
              <details>
                <summary>Advanced connection settings</summary>
                <label>
                  SSH port
                  <input
                    type="number"
                    min={1}
                    max={65535}
                    value={port}
                    onChange={(event) => setPort(event.target.value)}
                  />
                </label>
              </details>
              <p className="ak-muted">
                Uses the app host’s existing SSH configuration. Review requirements and writes
                before installation. No passwords or private keys are entered here.
              </p>
              <button className="ak-primary" disabled={busy || Boolean(connectionAttempt)}>
                Review connection
              </button>
            </form>
          )}
        </section>
      ) : (
        <>
          <div className="ak-worker-cards">
            {state.registry?.executors.map((item) => (
              <button
                className="ak-worker-card"
                aria-pressed={item.id === state.workerId}
                key={item.id}
                disabled={locked}
                onClick={() =>
                  void run(async () => {
                    setPreferences(await api.save({ workerId: item.id }));
                    controller.select(item.id);
                  })
                }
              >
                <strong>{item.name}</strong>
                <span>{item.kind === 'local' ? 'This computer' : 'Remote worker'}</span>
                <span
                  className={item.online ? (item.ready ? 'ak-good' : 'ak-warning') : 'ak-muted'}
                >
                  {item.online ? (item.ready ? 'Ready' : 'Connected · Setup needed') : 'Offline'}
                </span>
              </button>
            ))}
            <button
              className="ak-worker-card ak-connect-card"
              disabled={locked}
              onClick={() => setAdding(true)}
            >
              ＋ Connect another computer
            </button>
          </div>
          <section className="ak-panel">
            <h2>Model storage on {worker?.name ?? 'selected worker'}</h2>
            <form
              className="ak-inline"
              onSubmit={(event) => {
                event.preventDefault();
                void run(async () => {
                  if (!state.workerId) return;
                  setPreferences(
                    await api.save({ workerId: state.workerId, modelPath: path.trim() }),
                  );
                  await controller.act({ kind: 'storage', path: path.trim() });
                });
              }}
            >
              <label className="ak-grow">
                <span className="ak-sr">Model storage location</span>
                <input
                  value={path}
                  disabled={locked || !inventory}
                  onChange={(event) => {
                    if (state.workerId)
                      setDrafts({ ...drafts, [state.workerId]: event.target.value });
                  }}
                />
              </label>
              <button
                className="ak-primary"
                disabled={
                  locked || !inventory || !path.trim() || path.trim() === inventory.storage.path
                }
              >
                Use location
              </button>
            </form>
            <p className="ak-muted">
              Compatible apps share model files on this worker. Runtime tools use its
              application-data location. Changing this path indexes files; it does not move or
              delete them.
            </p>
            {(state.pendingKind === 'storage' || storageJob) && (
              <div role="status">
                <p>{storageJob?.message ?? 'Starting indexing…'}</p>
                <progress
                  aria-label="Indexing model storage"
                  max={1}
                  {...(storageJob?.progress != null ? { value: storageJob.progress } : {})}
                />
              </div>
            )}
          </section>
          <div className="ak-inline">
            <button disabled={busy} onClick={onBrowse}>
              Browse without setup
            </button>
            <button
              className="ak-primary"
              disabled={
                locked ||
                !worker?.online ||
                !inventory ||
                Boolean(state.error) ||
                path.trim() !== inventory.storage.path ||
                state.snapshot?.jobs.some(activeJob)
              }
              onClick={() =>
                void run(async () => {
                  if (!state.workerId) return;
                  const next = await api.save({ workerId: state.workerId, complete: true });
                  setPreferences(next);
                  onContinue(inventory?.summary.ready ? 'projects' : 'resources');
                })
              }
            >
              Continue
            </button>
          </div>
        </>
      )}
      {connectionAttempt && (
        <div className="ak-notice">
          <p>The connection may still be running. Check its receipt; do not submit it again.</p>
          <button
            disabled={busy}
            onClick={() =>
              void run(async () => {
                const receipt = await api.attempt(connectionAttempt);
                if (receipt.status === 'rejected') {
                  localStorage.removeItem('akatz-kit.connection-attempt');
                  setConnectionAttempt(null);
                  setPlan(null);
                  throw new Error(
                    receipt.error ??
                      'Connection was rejected. Review corrected details before trying again.',
                  );
                }
                if (receipt.status !== 'completed')
                  throw new Error(
                    'Connection is ' +
                      receipt.status +
                      '. Original attempt preserved; no installation repeated.',
                  );
                await connected(receipt.workerId);
              })
            }
          >
            Check connection receipt
          </button>
        </div>
      )}
      {state.uncertain && (
        <button disabled={state.pending} onClick={() => void controller.reconcile()}>
          Check resource action receipt
        </button>
      )}
      {busy && <p role="status">Updating setup…</p>}
      {(error || state.actionError || state.error) && (
        <p className="ak-notice" role="alert">
          {error || state.actionError || state.error}
        </p>
      )}
      <p className="ak-muted">
        Local app-data location is managed by the existing host. Native location selection comes
        with the desktop host; it is separate from worker model storage.
      </p>
    </section>
  );
}
