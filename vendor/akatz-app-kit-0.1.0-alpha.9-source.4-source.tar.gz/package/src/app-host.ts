/** One browser origin for compiled UI, shared controllers, and an app-owned API.
 * Process supervision and worker admission remain with their existing owners.
 */
import {createServer, request as requestHttp, type IncomingMessage, type ServerResponse} from 'node:http';
import {createReadStream} from 'node:fs';
import {realpath, stat} from 'node:fs/promises';
import {resolve, relative, extname, isAbsolute} from 'node:path';
import {z} from 'zod';

export const appHostIdentitySchema = z.object({
  appId: z.string().regex(/^[a-z0-9][a-z0-9-]*$/),
  instanceId: z.string().min(1).max(160),
  revision: z.string().regex(/^[a-f0-9]{64}$/),
}).strict();
export type AppHostIdentity = z.infer<typeof appHostIdentitySchema>;
type Middleware = (request: IncomingMessage, response: ServerResponse, next: () => void) => void | Promise<void>;
export interface AppHostOptions {
  identity: AppHostIdentity;
  assetsDirectory: string;
  trustedOrigins?: readonly string[];
  middleware?: readonly Middleware[];
  domain?: {origin: string; prefixes: readonly string[]; healthPath: string; verifyHealth: (value: unknown) => boolean; websocket?: boolean};
}
const local = new Set(['127.0.0.1','::1','::ffff:127.0.0.1']);
const types: Record<string, string> = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8',
  '.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.woff2':'font/woff2','.mp4':'video/mp4'};
function safeOrigin(value: string): URL {
  const url = new URL(value);
  if (url.protocol !== 'http:' || !['127.0.0.1','localhost','[::1]'].includes(url.hostname) || !url.port || url.username || url.password || url.pathname !== '/' || url.search || url.hash) throw new Error('App domain service requires an explicit HTTP loopback origin');
  return url;
}
export function appHostRequestAllowed(request: IncomingMessage, trustedOrigins: readonly string[] = []): boolean {
  const documentNavigation=['GET','HEAD'].includes(request.method||'GET')&&request.headers['sec-fetch-mode']==='navigate'&&request.headers['sec-fetch-dest']==='document';
  if (!local.has(request.socket.remoteAddress || '') || (request.headers['sec-fetch-site'] === 'cross-site'&&!documentNavigation)) return false;
  const host = request.headers.host;
  if (!host) return false;
  const trusted = trustedOrigins.map(o => new URL(o));
  if (!/^(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/.test(host) && !trusted.some(o => o.host === host)) return false;
  const origin = request.headers.origin;
  if (origin && origin !== 'http://' + host && !trusted.some(o => o.host === host && o.origin === origin)) return false;
  if (!['GET','HEAD','OPTIONS'].includes(request.method || 'GET') && !origin && request.headers['x-akatz-host'] !== '1' && request.headers['x-akatz-kit'] !== '1') return false;
  return true;
}
export function createAppHost(options: AppHostOptions) {
  const identity = appHostIdentitySchema.parse(options.identity), assets = resolve(options.assetsDirectory);
  const trusted = (options.trustedOrigins || []).map(o => {
    const url = new URL(o);
    if (!['http:','https:'].includes(url.protocol) || url.username || url.password || url.origin !== o) throw new Error('Trusted origins must be exact origins');
    return o;
  });
  const domain = options.domain ? {...options.domain, url: safeOrigin(options.domain.origin)} : null;
  if (domain?.prefixes.some(p => !/^\/[a-z0-9][a-z0-9/_-]*$/.test(p))) throw new Error('Domain routes require explicit prefixes');
  const domainRoute = (path: string): boolean => Boolean(domain?.prefixes.some(p => path === p || path.startsWith(p + '/')));
  const send = (response: ServerResponse, status: number, value: unknown): void => {
    response.writeHead(status, {'content-type':'application/json','cache-control':'no-store'}); response.end(JSON.stringify(value));
  };
  async function health(): Promise<boolean> {
    if (!domain) return true;
    try {
      const response = await fetch(new URL(domain.healthPath, domain.url), {signal:AbortSignal.timeout(2000),redirect:'error'});
      return response.ok && domain.verifyHealth(await response.json());
    } catch {return false;}
  }
  function proxy(request: IncomingMessage, response: ServerResponse): void {
    if (!domain) return send(response,404,{message:'Domain service is not configured'});
    const upstream = requestHttp({hostname:domain.url.hostname,port:domain.url.port,method:request.method,path:request.url,
      headers:{...request.headers}}, result => {
      const headers = {...result.headers};
      if (headers.location?.startsWith(domain.url.origin)) headers.location = headers.location.slice(domain.url.origin.length) || '/';
      response.writeHead(result.statusCode || 502,headers);result.pipe(response);
    });
    upstream.on('error',()=>{if(!response.headersSent)send(response,502,{message:'The app service is unavailable; accepted worker jobs remain inspectable'});else response.destroy();});
    request.on('aborted',()=>upstream.destroy());response.on('close',()=>{if(!response.writableFinished)upstream.destroy();});request.pipe(upstream);
  }
  async function assetsResponse(request: IncomingMessage, response: ServerResponse, path: string): Promise<void> {
    if (!['GET','HEAD'].includes(request.method || 'GET')) return send(response,405,{message:'Asset method is not supported'});
    const decoded = decodeURIComponent(path);
    if (decoded.includes('\\') || decoded.split('/').some(p=>p.startsWith('.'))) return send(response,404,{message:'Asset not found'});
    let candidate = resolve(assets, '.' + decoded);
    let info = await stat(candidate).catch(()=>null);
    if (!info?.isFile() && !extname(decoded)) {candidate=resolve(assets,'index.html');info=await stat(candidate).catch(()=>null);}
    if (!info?.isFile()) return send(response,404,{message:'Asset not found'});
    const target = await realpath(candidate), root = await realpath(assets), rel = relative(root,target);
    if (!rel || rel.startsWith('..') || isAbsolute(rel)) return send(response,404,{message:'Asset not found'});
    let start=0,end=info.size-1,status=200;
    if (request.headers.range) {
      const range=/^bytes=(\d*)-(\d*)$/.exec(request.headers.range);
      if (!range || (!range[1]&&!range[2])) {response.writeHead(416,{'content-range':'bytes */'+info.size});response.end();return;}
      start=range[1]?Number(range[1]):Math.max(0,info.size-Number(range[2]));end=range[1]&&range[2]?Number(range[2]):end;
      end=Math.min(end,info.size-1);
      if (!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start>end||start<0) {response.writeHead(416,{'content-range':'bytes */'+info.size});response.end();return;}
      status=206;
    }
    response.writeHead(status,{'content-type':types[extname(target)]||'application/octet-stream','content-length':Math.max(0,end-start+1),'accept-ranges':'bytes',
      'cache-control':extname(target)==='.html'?'no-store':'public, max-age=120',...(status===206?{'content-range':`bytes ${start}-${end}/${info.size}`}:{})});
    if(request.method==='HEAD'||info.size===0){response.end();return;}
    const stream=createReadStream(target,{start,end});stream.on('error',()=>response.destroy());response.on('close',()=>stream.destroy());stream.pipe(response);
  }
  const upgraded = new Set<import('node:stream').Duplex>();
  const server=createServer(async(request,response)=>{
    try {
      if(!appHostRequestAllowed(request,trusted))return send(response,403,{message:'Use the app’s configured address and same origin'});
      const path=new URL(request.url || '/','http://127.0.0.1').pathname;
      if(path==='/__akatz/app-host'){const ready=await health();return send(response,ready?200:503,{...identity,phase:ready?'ready':'domain-unavailable'});}
      let index=0;
      const next=():void=>{
        const middleware=options.middleware?.[index++];
        if(middleware){Promise.resolve(middleware(request,response,next)).catch(()=>{if(!response.headersSent)send(response,503,{message:'Shared app service is unavailable'});else response.destroy();});return;}
        if(domainRoute(path))proxy(request,response);
        else void assetsResponse(request,response,path).catch(()=>{if(!response.headersSent)send(response,404,{message:'Asset not found'});else response.destroy();});
      };
      next();
    } catch {if(!response.headersSent)send(response,400,{message:'Invalid app request'});else response.destroy();}
  });
  server.on('upgrade',(request,socket,head)=>{
    const path=new URL(request.url || '/','http://127.0.0.1').pathname;
    if(!domain?.websocket||!domainRoute(path)||!appHostRequestAllowed(request,trusted)){socket.destroy();return;}
    const upstream=requestHttp({hostname:domain.url.hostname,port:domain.url.port,path:request.url,headers:{...request.headers}});
    upstream.on('upgrade',(result,remote,initial)=>{
      upgraded.add(socket);upgraded.add(remote);
      socket.on('close',()=>upgraded.delete(socket));remote.on('close',()=>upgraded.delete(remote));
      socket.write('HTTP/1.1 101 Switching Protocols\r\n'+Object.entries(result.headers).map(([k,v])=>k+': '+String(v)).join('\r\n')+'\r\n\r\n');
      if(initial.length)socket.write(initial);if(head.length)remote.write(head);remote.pipe(socket).pipe(remote);
      remote.on('error',()=>socket.destroy());socket.on('error',()=>remote.destroy());socket.on('close',()=>remote.destroy());
    });
    upstream.on('response',()=>socket.destroy());upstream.on('error',()=>socket.destroy());upstream.end();
  });
  return {server,identity,health,async listen(port=0):Promise<string>{
    await new Promise<void>((done,fail)=>{server.once('error',fail);server.listen(port,'127.0.0.1',()=>{server.removeListener('error',fail);done();});});
    const address=server.address();if(!address||typeof address==='string')throw new Error('App host has no listening address');
    return 'http://127.0.0.1:'+address.port;
  },async close():Promise<void>{for(const socket of upgraded)socket.destroy();server.closeAllConnections();await new Promise<void>((done,fail)=>server.close(e=>e?fail(e):done()));}};
}
