import type {ReactElement} from 'react';
export function executorPhaseLabel(phase:string):string;
export function ExecutorControl(props:{request:(action:string,input?:Record<string,unknown>)=>Promise<any>;feature:string;manageOnly?:boolean;settingsFields?:Array<{key:string;label:string;placeholder?:string}>;onSelection?:(id:string|null)=>void}):ReactElement;
