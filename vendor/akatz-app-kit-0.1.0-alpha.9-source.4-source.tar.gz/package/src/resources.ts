import type {
  Registry,
  ResourceAction,
  ResourceAdapter,
  ResourceJob,
  ResourceReview,
  ResourceSnapshot,
} from './contracts.js';
import { RequestFailure } from './http.js';
import { memoryFences, type FenceStore } from './fences.js';

export interface ResourceState {
  registry: Registry | null;
  workerId: string | null;
  snapshot: ResourceSnapshot | null;
  loading: boolean;
  error: string;
  pending: boolean;
  uncertain: boolean;
  actionError: string;
  review: ResourceReview | null;
  pendingKind: ResourceAction['kind'] | null;
}
const initial = (): ResourceState => ({
  registry: null,
  workerId: null,
  snapshot: null,
  loading: false,
  error: '',
  pending: false,
  uncertain: false,
  actionError: '',
  review: null,
  pendingKind: null,
});
export const activeJob = (job: { status: string }) =>
  job.status === 'queued' || job.status === 'running';
function mergeJobs(observed: ResourceJob[], previous: ResourceJob[]) {
  // A just-accepted job may not appear in the next inventory yet. Keep its receipt
  // until the server supplies a terminal observation, rather than enabling a repeat.
  return [
    ...observed,
    ...previous.filter((job) => activeJob(job) && !observed.some((next) => next.id === job.id)),
  ];
}

/** Instance per app host. Worker identity guards every async read and mutation receipt. */
export class ResourceController {
  private state = initial();
  private listeners = new Set<() => void>();
  private epoch = 0;
  private request: AbortController | null = null;
  constructor(
    private readonly adapter: ResourceAdapter,
    private readonly fences: FenceStore = memoryFences(),
  ) {}
  getSnapshot = () => this.state;
  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  private update(patch: Partial<ResourceState>) {
    this.state = { ...this.state, ...patch };
    for (const listener of this.listeners) listener();
  }
  select(workerId: string) {
    if (!this.state.registry?.executors.some((worker) => worker.id === workerId))
      throw new Error('Unknown worker');
    if (this.state.pending) throw new Error('Wait for the current action receipt');
    this.epoch++;
    this.request?.abort();
    this.request = null;
    this.update({
      workerId,
      snapshot: null,
      review: null,
      actionError: '',
      error: '',
      uncertain: this.fences.has(workerId),
    });
    void this.refresh();
  }
  stop() {
    this.epoch++;
    this.request?.abort();
    this.request = null;
  }
  async refresh() {
    if (this.request || this.state.pending) return;
    const request = new AbortController();
    this.request = request;
    const ticket = ++this.epoch;
    const current = () => ticket === this.epoch;
    this.update({ loading: true });
    try {
      const registry = await this.adapter.registry(request.signal);
      if (!current()) return;
      const workerId =
        this.state.workerId ?? registry.selectedExecutorId ?? registry.defaultExecutorId;
      this.update({ registry, workerId, uncertain: workerId ? this.fences.has(workerId) : false });
      const worker = registry.executors.find((item) => item.id === workerId);
      if (!workerId || !worker)
        throw new Error('No worker registered. Open Worker setup to connect a worker.');
      if (this.adapter.unresolved) {
        const attemptId = await this.adapter.unresolved(workerId, request.signal);
        if (!current()) return;
        if (attemptId) {
          this.fences.add(workerId);
          this.fences.setAttempt?.(workerId, attemptId);
          this.update({ uncertain: true });
        }
      }
      if (!worker.online)
        throw new Error(`${worker.name} is offline. Saved projects and outputs remain available.`);
      const progress = await this.adapter.jobs(workerId, request.signal);
      if (!current()) return;
      if (progress.executorId !== workerId)
        throw new Error('Worker identity mismatch in progress response');
      const previous = this.state.snapshot;
      const jobs = mergeJobs(progress.jobs, previous?.jobs ?? []);
      if (previous) this.update({ snapshot: { ...previous, jobs } });
      if (previous && jobs.some((job) => job.kind === 'storage' && activeJob(job))) {
        this.update({ error: '' });
        return;
      }
      const snapshot = await this.adapter.snapshot(workerId, request.signal);
      if (!current()) return;
      if (snapshot.executorId !== workerId)
        throw new Error('Worker identity mismatch in resource response');
      this.update({
        snapshot: { ...snapshot, jobs: mergeJobs(snapshot.jobs, jobs) },
        error: '',
        // Discard start reviews retained by an older UI or recovered receipt.
        // A status refresh must not execute their plans as a side effect.
        ...(this.state.review?.runtimeAction === 'start' ? { review: null } : {}),
      });
    } catch (error) {
      if (current())
        this.update({ error: error instanceof Error ? error.message : 'Resources unavailable' });
    } finally {
      if (current()) {
        this.request = null;
        this.update({ loading: false });
      }
    }
  }
  dismissReview() {
    if (!this.state.pending) this.update({ review: null });
  }
  async reconcile() {
    const workerId = this.state.workerId;
    if (!workerId || this.state.pending) return;
    const id = this.fences.getAttempt?.(workerId);
    if (!id || !this.adapter.reconcile) {
      this.update({
        actionError:
          'This older attempt has no saved receipt identity. It cannot be safely cleared automatically.',
      });
      return;
    }
    this.update({ pending: true, actionError: '' });
    try {
      const result = await this.adapter.reconcile(id, workerId);
      if (!result)
        throw new Error(
          'The server cannot yet prove the outcome. No action was repeated; the safety block remains.',
        );
      if ('reviewRequired' in result) {
        if (result.executorId !== workerId) throw new Error('Receipt belongs to another worker');
        this.update({ review: result.runtimeAction === 'start' ? null : result });
      } else if ('id' in result && this.state.snapshot) {
        this.update({
          snapshot: {
            ...this.state.snapshot,
            jobs: [result, ...this.state.snapshot.jobs.filter((job) => job.id !== result.id)],
          },
        });
      }
      this.fences.delete(workerId);
      this.update({ uncertain: false });
    } catch (error) {
      if (error instanceof RequestFailure && !error.uncertain) {
        this.fences.delete(workerId);
        this.update({ uncertain: false });
      }
      this.update({ actionError: error instanceof Error ? error.message : 'Receipt unavailable' });
    } finally {
      this.update({ pending: false });
      void this.refresh();
    }
  }
  async act(action: ResourceAction) {
    const workerId = this.state.workerId;
    if (!workerId || this.state.pending || this.fences.has(workerId)) return;
    if ((action.kind === 'setup-confirm' || action.kind === 'uninstall-confirm') && action.review.executorId !== workerId)
      throw new Error('Review belongs to another worker');
    if (
      (action.kind === 'setup-confirm' || action.kind === 'uninstall-confirm') &&
      (action.review.plan.id !== this.state.review?.plan.id ||
        action.review.plan.digest !== this.state.review?.plan.digest)
    )
      throw new Error('Review is stale. Request a fresh plan.');
    if (this.state.error || !this.state.snapshot || this.state.snapshot.jobs.some(activeJob))
      return;
    // Fence prior to dispatch; an app/window crash must not enable a blind repeat.
    const attemptId = crypto.randomUUID();
    try {
      this.fences.add(workerId);
      this.fences.setAttempt?.(workerId, attemptId);
    } catch {
      this.update({ actionError: 'Cannot persist action safety state. No request was sent.' });
      return;
    }
    this.epoch++;
    this.request?.abort();
    this.request = null;
    this.update({ pending: true, pendingKind: action.kind, actionError: '' });
    try {
      let result = await this.adapter.action(workerId, action, attemptId);
      if (this.state.workerId !== workerId) return;
      if (action.kind === 'runtime-start' && 'reviewRequired' in result) {
        // The Start click authorizes only this worker's no-download start plan.
        // Keep the pending guard across both requests and journal confirmation
        // separately so a lost receipt can never trigger a second start.
        if (
          result.executorId !== workerId ||
          result.runtimeAction !== 'start' ||
          result.plan.downloads.length ||
          result.resourceIds.length
        )
          throw new RequestFailure('Worker did not return a start-only runtime plan.', false);
        const confirmationId = crypto.randomUUID();
        this.fences.setAttempt?.(workerId, confirmationId);
        this.update({ review: null });
        result = await this.adapter.action(
          workerId,
          { kind: 'setup-confirm', review: result },
          confirmationId,
        );
        if (this.state.workerId !== workerId) return;
      }
      if ('reviewRequired' in result) {
        if (result.executorId !== workerId)
          throw new RequestFailure('Setup review returned another worker', true);
        this.update({ review: result });
      } else {
        if ('id' in result && this.state.snapshot)
          this.update({
            snapshot: {
              ...this.state.snapshot,
              jobs: [result, ...this.state.snapshot.jobs.filter((job) => job.id !== result.id)],
            },
          });
        this.update({ review: null });
      }
      this.fences.delete(workerId);
    } catch (error) {
      const uncertain = !(error instanceof RequestFailure) || error.uncertain;
      if (!uncertain) this.fences.delete(workerId);
      this.update({
        uncertain,
        actionError: `${error instanceof Error ? error.message : 'Action failed'}${uncertain ? ' — acceptance is unknown. Check the saved receipt before taking another action. Nothing will be retried automatically.' : ''}`,
      });
    } finally {
      this.update({ pending: false, pendingKind: null });
      void this.refresh();
    }
  }
}
