import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { lstat, realpath, unlink, writeFile, rename } from 'node:fs/promises';
import { join, resolve, relative, isAbsolute, extname } from 'node:path';
import { identifier, record, hash, integer, text } from './session-contracts.js';
import { contentDigest } from './execution-access.js';

const media = new Set(['.mp4','.mkv','.mov','.webm','.png','.jpg','.jpeg','.wav','.flac']);
/** The authenticated provider acknowledges custody; caller-supplied paths are forbidden. */
export async function collectExecutionOutputs(root: string, value: unknown, acknowledgement: unknown, collectionRoots: string[]): Promise<{removedFiles: number}> {
  const job = record(value), receipt = record(acknowledgement), jobId = identifier(job.id);
  if (Object.keys(receipt).some(k => !['sourceJobId','manifestDigest'].includes(k)) || job.phase !== 'completed' ||
      receipt.sourceJobId !== job.sourceJobId) throw new Error('Completed job custody acknowledgement required');
  const result = record(job.result);
  if (!Array.isArray(result.files) || contentDigest(result.files) !== hash(receipt.manifestDigest))
    throw new Error('Collected output manifest differs');
  const files = result.files.map(value => {
    const f = record(value);
    return {name:text(f.name,'artifact name'),hash:hash(f.hash),size:integer(f.size,'artifact size')};
  });
  const directory = join(root,'jobs',jobId), removals: string[] = [];
  for (const base of [join(directory,'outputs'), ...collectionRoots.map(base=>join(base,jobId))]) {
    for (const file of files) {
      if (!media.has(extname(file.name).toLowerCase())) continue;
      const path = resolve(base,file.name), rel = relative(base,path);
      if (!rel || isAbsolute(file.name) || rel === '..' || rel.startsWith('../')) throw new Error('Output escapes collection root');
      const stat = await lstat(path).catch((error: NodeJS.ErrnoException) => {if(error.code==='ENOENT')return null;throw error;});
      if (!stat) continue;
      if (!stat.isFile() || stat.size !== file.size || await realpath(path) !== path) throw new Error('Output changed or contains a symlink');
      const digest = createHash('sha256');
      for await (const bytes of createReadStream(path)) digest.update(bytes);
      if (digest.digest('hex') !== file.hash) throw new Error('Output integrity changed');
      removals.push(path);
    }
  }
  // Validate every retained copy before removing any. Replays tolerate missing files.
  for (const path of removals) await unlink(path);
  const pending = join(directory,'collected.json.pending');
  await writeFile(pending,JSON.stringify({...receipt,collectedAt:new Date().toISOString()}),{mode:0o600});
  await rename(pending,join(directory,'collected.json'));
  return {removedFiles:removals.length};
}
