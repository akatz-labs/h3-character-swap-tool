import { z } from 'zod';
import type { JsonClient } from './http.js';

export const setupPreferencesSchema = z.object({
  workerId: z.string().nullable(),
  completed: z.boolean(),
  modelPath: z.string().nullable(),
  storageJobId: z.string().nullable(),
});
export type SetupPreferences = z.infer<typeof setupPreferencesSchema>;
export const connectionInputSchema = z
  .object({
    id: z.string().regex(/^[a-z0-9][a-z0-9-]*$/),
    name: z.string().trim().min(1).max(100),
    host: z
      .string()
      .trim()
      .min(1)
      .max(253)
      .regex(/^[a-zA-Z0-9_][a-zA-Z0-9_.@:-]*$/),
    sshPort: z.number().int().min(1).max(65535),
    kind: z.literal('ssh'),
  })
  .strict();
export const connectionPlanSchema = z.object({
  id: z.string().min(1),
  digest: z.string().min(1),
  description: z.string(),
  writes: z.array(z.string()),
  requires: z.array(z.string()),
  target: z.object({ id: z.string(), name: z.string(), host: z.string(), sshPort: z.number() }),
});
export type ConnectionPlan = z.infer<typeof connectionPlanSchema>;
export const attemptSchema = z.object({
  id: z.string(),
  workerId: z.string(),
  status: z.enum(['running', 'completed', 'rejected', 'uncertain']),
  result: z.unknown().optional(),
  error: z.string().optional(),
});
export function setupClient(http: JsonClient) {
  const post = <T>(path: string, schema: z.ZodType<T>, body: unknown) =>
    http.request(
      '/kit-api/' + path,
      schema,
      { method: 'POST', body: JSON.stringify(body), headers: { 'x-akatz-kit': '1' } },
      180000,
    );
  return {
    preferences: () => http.request('/kit-api/setup', setupPreferencesSchema),
    save: (input: { workerId?: string; modelPath?: string; complete?: boolean }) =>
      post('setup', setupPreferencesSchema, input),
    plan: (input: z.infer<typeof connectionInputSchema>) =>
      post('connection/plan', connectionPlanSchema, input),
    connect: (plan: ConnectionPlan, attemptId: string) =>
      post('connection/confirm', z.object({ complete: z.literal(true), workerId: z.string() }), {
        id: plan.id,
        digest: plan.digest,
        workerId: plan.target.id,
        attemptId,
      }),
    attempt: (id: string) =>
      http.request('/kit-api/attempts/' + encodeURIComponent(id), attemptSchema),
    bootstrap: (attemptId: string) =>
      post('bootstrap', z.object({ complete: z.literal(true), workerId: z.literal('local') }), {
        attemptId,
      }),
  };
}
