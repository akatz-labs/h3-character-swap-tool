import type {ReactNode} from 'react';
import type {ModelResource,ModelResourceInventory,ModelResourceJob} from './model-resources.mjs';
export function formatResourceBytes(bytes:number|null):string;
export function filterModelResources(models:ModelResource[],filter:string,query:string):ModelResource[];
export function ModelResourcesPage(props:{inventory:ModelResourceInventory|null;jobs?:ModelResourceJob[];loading?:boolean;error?:string;onAction:(action:string,input?:Record<string,unknown>)=>Promise<unknown>;onRefresh?:()=>void;children?:ReactNode;showOptionalPacks?:boolean;simpleModelActions?:boolean}):ReactNode;
export function StorageProgress(props:{job?:ModelResourceJob|null;pending?:boolean}):ReactNode;
