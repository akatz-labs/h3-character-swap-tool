import type { Server } from "node:http";
import type {
  ExecutorInstallation,
  ExecutorJob,
  ExecutorTarget,
  InstallationReadiness,
} from "./executor-client.mjs";
export function createExecutorServer(options?: { root?: string; dispatch?: boolean }): {
  server: Server;
  executor: {
    identity: string;
    root: string;
    register(target: ExecutorTarget & { id: string; name: string }): ExecutorTarget;
    preference(key: string, value?: string | null): string | null;
    selection(appId: string): {
      defaultExecutorId: string;
      selectedExecutorId: string;
      selectionSource: "app" | "default";
    };
    jobs(): ExecutorJob[];
    plan(installation: ExecutorInstallation): { id: string; digest: string };
    install(id: string, digest: string): Promise<unknown>;
    readiness(appId?: string): Promise<InstallationReadiness[]>;
  };
  close(): Promise<void>;
};
